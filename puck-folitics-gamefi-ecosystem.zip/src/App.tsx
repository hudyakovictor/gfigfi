import { useState } from "react";
import { GameProvider, useGame } from "./lib/useGame";
import CommandBar from "./components/CommandBar";
import MarqueeTicker from "./components/MarqueeTicker";
import SideNav from "./components/SideNav";
import LiveTicker from "./components/LiveTicker";
import NodeView from "./components/views/NodeView";
import FoldView from "./components/views/FoldView";
import MarketsView from "./components/views/MarketsView";
import IntelView from "./components/views/IntelView";
import FactionsView from "./components/views/FactionsView";
import VaultView from "./components/views/VaultView";
import MasksView from "./components/views/MasksView";
import type { ViewId } from "./lib/types";
import { SEASON_BY_ID } from "./lib/gameData";
import { MOOD_COLOR } from "./components/ui";
import { timeAgo } from "./lib/format";

const VIEW_META: Record<ViewId, { title: string; sub: string }> = {
  node: { title: "Operator Node", sub: "Command your node. Read the world. Move first." },
  fold: { title: "The Fold", sub: "Seven regions. One broken timeline. Reality negotiates itself." },
  markets: { title: "Markets", sub: "Real prices wired into a satirical economy." },
  intel: { title: "Intel", sub: "World shocks & transmissions. The news writes itself." },
  factions: { title: "Factions", sub: "Four forces. Endlessly compatible genres." },
  vault: { title: "Vault", sub: "Functional assets. Utility over JPEGs." },
  masks: { title: "Masks", sub: "The archetypes that move the markets." },
};

function ViewHeader({ view }: { view: ViewId }) {
  const { mood, seasonId, activeShock, mode, liveConnected, lastUpdate } = useGame();
  const meta = VIEW_META[view];
  const mb = MOOD_COLOR(mood);
  const season = SEASON_BY_ID[seasonId];
  return (
    <div className="flex items-end justify-between gap-3 mb-3">
      <div className="min-w-0">
        <div className="chip text-ink-dim">OPERATOR CONSOLE ▸ {view.toUpperCase()}</div>
        <h1 className="font-display font-bold text-xl sm:text-2xl text-ink tracking-tight leading-tight">{meta.title}</h1>
        <p className="text-[12px] text-ink-dim">{meta.sub}</p>
      </div>
      <div className="hidden sm:flex flex-col items-end gap-1 shrink-0">
        <div className="flex items-center gap-2">
          <span className="chip flex items-center gap-1" style={{ color: season.color }}>{season.emoji} {season.name}</span>
          <span className="chip flex items-center gap-1" style={{ color: mb.color }}>◎ MOOD {Math.round(mood)}</span>
        </div>
        <div className="flex items-center gap-2">
          {activeShock
            ? <span className="chip blink" style={{ color: "#ff2d95" }}>● {activeShock.name}</span>
            : <span className="chip text-ink-dim">○ no active shock</span>}
          <span className="chip" style={{ color: mode === "live" ? (liveConnected ? "#00ff9c" : "#ffb020") : "#9b6bff" }}>
            {mode === "live" ? (liveConnected ? "● LIVE" : "● SIM-FB") : "◈ SIM"} · {timeAgo(lastUpdate)}
          </span>
        </div>
      </div>
    </div>
  );
}

function Shell() {
  const [view, setView] = useState<ViewId>("node");
  return (
    <div className="app-bg h-screen flex flex-col overflow-hidden text-ink">
      <div className="scanlines" />
      <CommandBar />
      <MarqueeTicker />
      <div className="flex-1 flex min-h-0">
        <SideNav view={view} setView={setView} />
        <main className="flex-1 min-w-0 overflow-y-auto scroll-thin">
          <div className="px-3 sm:px-4 py-3 max-w-[1500px] mx-auto">
            <ViewHeader view={view} />
            {view === "node" && <NodeView />}
            {view === "fold" && <FoldView />}
            {view === "markets" && <MarketsView />}
            {view === "intel" && <IntelView />}
            {view === "factions" && <FactionsView />}
            {view === "vault" && <VaultView />}
            {view === "masks" && <MasksView />}
            <footer className="mt-5 mb-2 text-center">
              <p className="text-[10px] text-ink-dim/70 font-mono">
                PUCK FOLITICS // THE FOLD — a living GameFi civilization. Rule the world. Build the system. Own the future.
              </p>
              <p className="text-[9px] text-ink-dim/50 font-mono mt-1">
                Not financial advice. Probably not even advice. All archetypes are fictional. Any resemblance to billionaires is entirely intentional but legally coincidental.
              </p>
            </footer>
          </div>
        </main>
        <LiveTicker />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <GameProvider>
      <Shell />
    </GameProvider>
  );
}
