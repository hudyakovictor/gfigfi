export const fmtUsd = (n: number | undefined | null, max = 2): string => {
  if (n == null || !isFinite(n)) return "—";
  if (n >= 1000) return "$" + n.toLocaleString("en-US", { maximumFractionDigits: 0 });
  if (n >= 1) return "$" + n.toLocaleString("en-US", { maximumFractionDigits: max });
  // tiny prices — show more precision
  const digits = n >= 0.01 ? 4 : n >= 0.0001 ? 6 : 8;
  return "$" + n.toLocaleString("en-US", { maximumFractionDigits: digits });
};

export const fmtPct = (n: number | undefined | null): string => {
  if (n == null || !isFinite(n)) return "—";
  const s = n >= 0 ? "+" : "";
  return s + n.toFixed(2) + "%";
};

export const fmtCompact = (n: number | undefined | null): string => {
  if (n == null || !isFinite(n)) return "—";
  if (n >= 1e12) return "$" + (n / 1e12).toFixed(2) + "T";
  if (n >= 1e9) return "$" + (n / 1e9).toFixed(2) + "B";
  if (n >= 1e6) return "$" + (n / 1e6).toFixed(2) + "M";
  if (n >= 1e3) return "$" + (n / 1e3).toFixed(1) + "K";
  return "$" + n.toFixed(0);
};

export const fmtNum = (n: number, digits = 0): string =>
  n.toLocaleString("en-US", { maximumFractionDigits: digits });

export const timeAgo = (ts: number): string => {
  const s = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (s < 60) return s + "s";
  const m = Math.floor(s / 60);
  if (m < 60) return m + "m";
  const h = Math.floor(m / 60);
  if (h < 24) return h + "h";
  return Math.floor(h / 24) + "d";
};

export const clamp = (n: number, min: number, max: number): number =>
  Math.min(max, Math.max(min, n));

export const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

export const uid = (): string =>
  Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-3);
