import type {
  Coin,
  Faction,
  Region,
  Shock,
  GameAsset,
  Mask,
  Season,
  Transmission,
} from "./types";

/* ============================================================================
   PUCK FOLITICS — THE FOLD
   Everything here is an archetype, not a copy. Real refs stay deniable.
   ========================================================================== */

export const TAGLINE = "Rule the world. Build the system. Own the future.";
export const SUBTAG =
  "A living GameFi civilization where reality bends to whoever yells loudest.";

/* ----------------------------------------------------------------------------
   THE BASKET — real coins, Fold names. Live data is layered onto these.
---------------------------------------------------------------------------- */
export const COINS: Coin[] = [
  {
    id: "bitcoin", symbol: "BTC", name: "Bitcoin", foldName: "The Big Orange Oracle",
    tagline: "Digital gold. Heavy, slow, refuses to die. Calms the whole Fold when it naps.",
    color: "#f7931a", emoji: "🟠", category: "blue",
    price: 67234.12, change24h: 1.8, sparkline: [],
  },
  {
    id: "ethereum", symbol: "ETH", name: "Ethereum", foldName: "Vita's Experiment",
    tagline: "A world computer that occasionally bills you for a small house.",
    color: "#8a92ff", emoji: "🔷", category: "l1",
    price: 3284.5, change24h: 2.4, sparkline: [],
  },
  {
    id: "tether", symbol: "USDT", name: "Tether", foldName: "Madame Peg's Promise",
    tagline: "Allegedly $1. The entire world calibrates to her mood swings.",
    color: "#26a17b", emoji: "💵", category: "stable",
    price: 1.0, change24h: 0.01, sparkline: [],
  },
  {
    id: "binancecoin", symbol: "BNB", name: "BNB", foldName: "CzarnCoin",
    tagline: "Liquidity's favorite off-ramp. Speaks softly, carries a big order book.",
    color: "#f0b90b", emoji: "🟡", category: "blue",
    price: 589.3, change24h: -0.6, sparkline: [],
  },
  {
    id: "solana", symbol: "SOL", name: "Solana", foldName: "SOLana Splitter",
    tagline: "Fast, cheap, and every full moon it briefly forgets how to be a chain.",
    color: "#14f195", emoji: "🌅", category: "l1",
    price: 168.4, change24h: 5.2, sparkline: [],
  },
  {
    id: "ripple", symbol: "XRP", name: "XRP", foldName: "The Ripple Cop",
    tagline: "Fought the law. The law is taking notes. Still here somehow.",
    color: "#27a2db", emoji: "🌀", category: "blue",
    price: 0.62, change24h: -1.1, sparkline: [],
  },
  {
    id: "dogecoin", symbol: "DOGE", name: "Dogecoin", foldName: "The Original Shibe",
    tagline: "A joke that became an economy. Now it has a department.",
    color: "#c2a633", emoji: "🐕", category: "meme",
    price: 0.152, change24h: 8.4, sparkline: [],
  },
  {
    id: "pepe", symbol: "PEPE", name: "Pepe", foldName: "Frog of the Fold",
    tagline: "No team. No roadmap. Perfectly symmetrical vibes. Up 400%.",
    color: "#3aa647", emoji: "🐸", category: "meme",
    price: 0.0000124, change24h: 14.6, sparkline: [],
  },
  {
    id: "shiba-inu", symbol: "SHIB", name: "Shiba Inu", foldName: "The Pup",
    tagline: "Held by millions who can't afford a sandwich. Spiritually important.",
    color: "#f25a2c", emoji: "🌭", category: "meme",
    price: 0.0000248, change24h: 4.1, sparkline: [],
  },
  {
    id: "chainlink", symbol: "LINK", name: "Chainlink", foldName: "Chain of Oracles",
    tagline: "Tells smart contracts the weather. Mostly accurate. Mostly.",
    color: "#2a5ada", emoji: "🔗", category: "defi",
    price: 17.8, change24h: 3.0, sparkline: [],
  },
  {
    id: "cardano", symbol: "ADA", name: "Cardano", foldName: "The Peer-Reviewed Dream",
    tagline: "Will ship the future right after 412 more academic papers.",
    color: "#0d6efd", emoji: "📐", category: "l1",
    price: 0.58, change24h: -2.0, sparkline: [],
  },
  {
    id: "avalanche-2", symbol: "AVAX", name: "Avalanche", foldName: "The Whitepaper Peak",
    tagline: "Subnets, hype, and a logo that looks expensive.",
    color: "#e84142", emoji: "🔺", category: "l1",
    price: 41.2, change24h: 1.2, sparkline: [],
  },
];

export const COIN_BY_ID: Record<string, Coin> = Object.fromEntries(
  COINS.map((c) => [c.id, c])
);

/* ----------------------------------------------------------------------------
   THE FOUR FORCES — the engine of every compatible genre.
---------------------------------------------------------------------------- */
export const FACTIONS: Faction[] = [
  {
    id: "builders", name: "Builders", color: "#00ff9c", emoji: "🔧",
    motto: "Ship it. Patch it later. Patch the patch never.",
    blurb:
      "They actually make the thing. Forge protocols, raise cities, run the machines. Universally ignored until something breaks, at which point they are suddenly everyone's best friend.",
    playstyle: "Production · Infrastructure · Long yield",
  },
  {
    id: "speculators", name: "Speculators", color: "#ffb020", emoji: "📈",
    motto: "Number go up, or so help me.",
    blurb:
      "Provide 'liquidity' (gamble). Chase every wave, mint every meme, exit at the first sign of a real emotion. The economy's accelerator and its panic button.",
    playstyle: "Arbitrage · Memetics · Velocity",
  },
  {
    id: "archivists", name: "Archivists", color: "#29e7ff", emoji: "📚",
    motto: "We've already seen this movie. It doesn't end well.",
    blurb:
      "Memory of the Fold. Excavate old rugs, decode dead schemes, turn yesterday's crashes into tomorrow's alpha. Insufferable at parties. Worth their weight in gold during Crackdown.",
    playstyle: "Intel · Pattern-recognition · Defense",
  },
  {
    id: "raiders", name: "Raiders", color: "#ff2d95", emoji: "🪓",
    motto: "Code is law. A loophole is opportunity.",
    blurb:
      "Hunt the cracks before the good guys patch them. Morally flexible, technically relentless. The Fold's immune system and its most wanted, depending on the week.",
    playstyle: "Exploit-hunting · Raids · Gray leverage",
  },
];

export const FACTION_BY_ID: Record<string, Faction> = Object.fromEntries(
  FACTIONS.map((f) => [f.id, f])
);

/* ----------------------------------------------------------------------------
   THE FOLD — modular regions, each its own economy & social meta-game.
---------------------------------------------------------------------------- */
export const REGIONS: Region[] = [
  {
    id: "citadel", name: "Citadel of Leverage", faction: "speculators", color: "#ffb020", emoji: "🏙️",
    tagline: "100x is a starting position.",
    desc: "Sky-piercing towers of derivatives and dressed-up degens. Where the elite bet against each other and call it 'hedging'.",
    crafts: ["Perp Modules", "Liquidation Maps", "Cope Receipts"],
    threats: ["Cascade liquidations", "Sudden 'maintenance'"],
    x: 68, y: 30,
  },
  {
    id: "ashen", name: "Ashen Chain", faction: "archivists", color: "#ff6a3d", emoji: "🔥",
    tagline: "Graveyard of rugs past. Invest in souvenirs, not futures.",
    desc: "A scorched plain of dead collections, abandoned discords, and rug-pull temples. The Archivists mine it for hard lessons and rare relics.",
    crafts: ["Crash Relics", "Forensic Maps", "Cautionary NFTs"],
    threats: ["Ghost protocols", "Reanimated scams"],
    x: 24, y: 64,
  },
  {
    id: "bridges", name: "Port of Bridges", faction: "raiders", color: "#29e7ff", emoji: "🌉",
    tagline: "Cross-chain capital welcome. Bring a firewall and a prayer.",
    desc: "The nerve hub between worlds. Capital flows fast, faster than the guards can patch it. A paradise for logistics — and for raiders.",
    crafts: ["Route Licenses", "Relay Beacons", "Bridge Insurance"],
    threats: ["9-figure exploits", "Stuck transit"],
    x: 50, y: 50,
  },
  {
    id: "reef", name: "JPEG Reef", faction: "speculators", color: "#ff2d95", emoji: "🖼️",
    tagline: "Status measured in floor price. Utility strictly forbidden.",
    desc: "An archipelago of galleries, flexers and pixelated aristocrats. Where a cartoon ape is a down payment on a yacht.",
    crafts: ["Status Banners", "Auction Lots", "Vibe Certificates"],
    threats: ["Floor collapse", "Royalty disputes"],
    x: 82, y: 62,
  },
  {
    id: "vaultstep", name: "Vaultstep Basin", faction: "builders", color: "#00ff9c", emoji: "🏦",
    tagline: "Set-and-forget yield. Sometimes you forget. Sometimes it forgets you.",
    desc: "Terraced farms of automated strategy. Beautiful when it works, catastrophic when the curve doesn't. The Builders' bread and butter.",
    crafts: ["Yield Vaults", "Strategy Blueprints", "Impermanent Patience"],
    threats: ["Curve de-pegs", "TVL vampire attacks"],
    x: 30, y: 30,
  },
  {
    id: "fault", name: "Miner's Fault", faction: "builders", color: "#c6ff00", emoji: "⛏️",
    tagline: "Where hashes become heat, and heat becomes politics.",
    desc: "An industrial rift of ASICs, energy wars and hashing power. The literal foundation — and the loudest political football in the Fold.",
    crafts: ["Hash Licenses", "Energy Contracts", "Block Sieves"],
    threats: ["Mining bans", "Energy rationing"],
    x: 16, y: 38,
  },
  {
    id: "forum", name: "Forum Zero", faction: "builders", color: "#9b6bff", emoji: "📡",
    tagline: "Where agendas are born, narratives minted, reality negotiated.",
    desc: "The political-media core. Politicians, pundits and 'thought leaders' broadcast here, and the entire Fold re-prices in real time.",
    crafts: ["Rumor Maps", "Narrative Bonds", "Momentum Seals"],
    threats: ["Presidential statements", "Influencer verdicts"],
    x: 50, y: 16,
  },
];

export const REGION_BY_ID: Record<string, Region> = Object.fromEntries(
  REGIONS.map((r) => [r.id, r])
);

/* ----------------------------------------------------------------------------
   SEASONS — driven by live market mood.
---------------------------------------------------------------------------- */
export const SEASONS: Season[] = [
  {
    id: "bull", name: "Bull Season", emoji: "🐂",
    tagline: "Money printer go brrr edition.",
    desc: "The Fold gets louder, brighter and more dangerous socially. Meme markets multiply, cities rise too fast, false prophets go viral. Speculators feast; everyone else pays rent.",
    color: "#00ff9c",
  },
  {
    id: "bear", name: "Bear Season", emoji: "🐻",
    tagline: "The Rekt Renaissance.",
    desc: "Efficiency, infrastructure and reputation suddenly matter. Tourists wash out; strategy and diplomacy get deep. The quiet, grinding season that separates operators from tourists.",
    color: "#29e7ff",
  },
  {
    id: "rotation", name: "Rotation Season", emoji: "🌀",
    tagline: "The Great Reshuffle.",
    desc: "Capital and attention migrate between sectors overnight. 'Useless' crafts and dead regions abruptly become critical. Adapt or be rekt by the meta.",
    color: "#9b6bff",
  },
  {
    id: "crackdown", name: "Crackdown Season", emoji: "⚖️",
    tagline: "Regulators said hi.",
    desc: "Pressure, panic, subpoenas and exposed vulnerabilities. Winners are the transparent, the reserved and the well-allianced. The season reputations are forged in.",
    color: "#ff2d95",
  },
];

export const SEASON_BY_ID: Record<string, Season> = Object.fromEntries(
  SEASONS.map((s) => [s.id, s])
);

/* ----------------------------------------------------------------------------
   SCRIPTED WORLD SHOCKS — probabilistic windows, three impact tiers each.
---------------------------------------------------------------------------- */
export const SHOCKS: Shock[] = [
  {
    id: "exchange-freeze", name: "Exchange Freeze", emoji: "🧊",
    tagline: "Withdrawals? Pray.",
    atmospheric: "A Citadel's lights flicker, then go dark. 'Scheduled maintenance.' Nobody believes it. Nobody can leave.",
    systemic: "Contract reliability collapses. Logistics cost surges. Anyone over-leveraged at that venue is now a passenger.",
    social: "Bank-run panic spreads by the minute. The trustworthy exchanges print 'proof-of-reserves' in a panic. Nobody reads it.",
    effects: [
      { label: "Logistics cost", delta: "+40%" },
      { label: "Contract reliability", delta: "-50%" },
      { label: "NPC panic", delta: "+35%" },
      { label: "Insurance claims", delta: "+220%" },
    ],
    triggers: ["A top venue halts withdrawals", "Audit leaks", "Founder 'takes a vacation'"],
    severity: "apocalyptic", duration: "6–48h",
  },
  {
    id: "stable-fracture", name: "Stable Fracture", emoji: "💔",
    tagline: "Madame Peg is sweating.",
    atmospheric: "The 'always $1' coin is currently $0.94 and the high priestess of stability is blinking very fast.",
    systemic: "Every yield curve recalibrates. Vaults built on that peg start sweating through their aprons.",
    social: "Half the Fold pretends it's fine. The other half is already at the exit. Classic.",
    effects: [
      { label: "Peg stability", delta: "-62%" },
      { label: "Yield reliability", delta: "-30%" },
      { label: "Banking panic", delta: "+60%" },
      { label: "Depeg arbitrage", delta: "+180%" },
    ],
    triggers: ["USDT/USDC wobbles", "Reserve rumors", "Redemption halt"],
    severity: "major", duration: "2–12h",
  },
  {
    id: "bridge-breach", name: "Bridge Breach", emoji: "💥",
    tagline: "Nine-figure hole. Architect unavailable.",
    atmospheric: "A Port of Bridges span now has a crater in its balance sheet. Smoke is coming out of the relay towers.",
    systemic: "Cross-chain transit freezes. Raid probability goes vertical. Insurance vaults empty fast.",
    social: "The Fold collectively asks 'not again?' The answer is, again. Yes.",
    effects: [
      { label: "Raid probability", delta: "+80%" },
      { label: "Transit throughput", delta: "-70%" },
      { label: "Insurance payouts", delta: "+300%" },
      { label: "Security demand", delta: "+140%" },
    ],
    triggers: ["Bridge drained", "Validator compromise", "Upgrade gone wrong"],
    severity: "apocalyptic", duration: "4–24h",
  },
  {
    id: "meme-fever", name: "Meme Fever", emoji: "🤒",
    tagline: "No team. No website. Market cap: $400M.",
    atmospheric: "A token with a raccoon logo and zero utility just printed a half-billion valuation. The Fold is deliriously proud.",
    systemic: "Meme sector inflates. Speculator velocity spikes. Serious protocols lose attention to a cartoon.",
    social: "Cab drivers become degen analysts. Your aunt asks which frog. This is fine 🔥.",
    effects: [
      { label: "Meme sector cap", delta: "+210%" },
      { label: "Speculator velocity", delta: "+90%" },
      { label: "Serious-protocol inflows", delta: "-40%" },
      { label: "Vibes", delta: "+500%" },
    ],
    triggers: ["A new mascot moons", "Influencer retweet", "Frog season"],
    severity: "major", duration: "1–7d",
  },
  {
    id: "fork-dispute", name: "Fork Dispute", emoji: "🍴",
    tagline: "Two chains. Both claim to be real. Neither is.",
    atmospheric: "A community has split. Each half insists it is the true continuation. Both are slightly worse than the original.",
    systemic: "Liquidity fragments across two chains. Reputations get reassigned. Bridges get awkward.",
    social: "Choosing a side becomes a public loyalty test. Neutrality is suspicious. Excellent.",
    effects: [
      { label: "Liquidity fragmentation", delta: "+55%" },
      { label: "Reputation volatility", delta: "+40%" },
      { label: "Diplomacy cost", delta: "+30%" },
    ],
    triggers: ["Chain governance deadlock", "Founder drama", "Ideological schism"],
    severity: "minor", duration: "3–14d",
  },
  {
    id: "whale-awakening", name: "Whale Awakening", emoji: "🐋",
    tagline: "Something with eight commas just moved.",
    atmospheric: "An ancient wallet, dormant since the genesis cycles, just blinked. Everyone is being very calm about it.",
    systemic: "Order books thin. Volatility expands in both directions. Liquidity providers get nervous.",
    social: "On-chain sleuths narrate the wallet's biography in real time. Most of it is wrong.",
    effects: [
      { label: "Volatility", delta: "+70%" },
      { label: "Order-book depth", delta: "-35%" },
      { label: "Sleuth activity", delta: "+400%" },
    ],
    triggers: ["Satoshi-era wallet moves", "Exchange inflow spike", "OTC desk rumor"],
    severity: "major", duration: "2–8h",
  },
  {
    id: "presidential-statement", name: "Presidential Statement", emoji: "📢",
    tagline: "He posted. The market moved first.",
    atmospheric: "Don Trumpoid has typed. The Fold reorganizes before he finishes the sentence. ALL CAPS, naturally.",
    systemic: "Narrative-sensitive sectors re-price instantly. Logistics reroute toward the new 'official' theme.",
    social: "Forum Zero becomes a stampede. Half the players agree, half are furious, all of them trade.",
    effects: [
      { label: "Narrative momentum", delta: "+120%" },
      { label: "Volatility", delta: "+45%" },
      { label: "Forum Zero chaos", delta: "+90%" },
    ],
    triggers: ["ALL-CAPS post", "Policy leak", "Rally announcement"],
    severity: "major", duration: "1–3d",
  },
  {
    id: "influencer-trial", name: "Influencer Trial", emoji: "⚖️",
    tagline: "'Financial guru' now explaining crypto to a judge.",
    atmospheric: "A beloved 'alpha caller' is in a courtroom, defining 'rug pull' under oath. The judge is taking notes.",
    systemic: "Promoted tokens de-list themselves. Paid-shilling demand collapses. Trust rebases.",
    social: "The Fold watches the livestream like sport. Old screenshots become evidence. Glorious.",
    effects: [
      { label: "Shill demand", delta: "-70%" },
      { label: "Trust index", delta: "+25%" },
      { label: "Archivist clout", delta: "+150%" },
    ],
    triggers: ["Indictment", "Subpoena wave", "Pump-and-dump exposed"],
    severity: "minor", duration: "1–30d",
  },
  {
    id: "jpeg-mania", name: "JPEG Mania", emoji: "🐵",
    tagline: "Floor up 300%. Utility optional.",
    atmospheric: "Pixelated cartoons are trading for car money. The Reef is throwing a party and didn't invite utility.",
    systemic: "Floor prices decouple from reason. Royalty markets overheat. Status economy inflates.",
    social: "Flexing intensifies. Rent is paid in apes. Someone explains 'right-click save' unironically.",
    effects: [
      { label: "Floor prices", delta: "+300%" },
      { label: "Status inflation", delta: "+120%" },
      { label: "Utility relevance", delta: "-80%" },
    ],
    triggers: ["Blue-chip mint", "Celebrity adoption", "Collection collab"],
    severity: "major", duration: "1–4w",
  },
  {
    id: "airdrop-exodus", name: "Airdrop Exodus", emoji: "🪂",
    tagline: "Free money. Servers on fire. People happy.",
    atmospheric: "A protocol is airdropping. The claim page is a battlefield. Everyone is suddenly a long-time believer.",
    systemic: "Network fees spike. Liquidity rotates to the new token. Farming behavior goes parabolic.",
    social: "'Loyal community members' materialize from thin air. Sybils outnumber humans 9:1.",
    effects: [
      { label: "Network fees", delta: "+250%" },
      { label: "New-token liquidity", delta: "+180%" },
      { label: "Sybil population", delta: "+900%" },
    ],
    triggers: ["Token launch", "Snapshot revealed", "Claim window opens"],
    severity: "minor", duration: "12–72h",
  },
  {
    id: "mining-ban", name: "Mining Ban", emoji: "⛔",
    tagline: "A nation decided energy is better spent elsewhere.",
    atmospheric: "ASICs weep. A government has decreed that hashes are no longer a public good. Miners migrate like birds.",
    systemic: "Hash rate relocates. Energy contracts re-price. Block times wobble.",
    social: "Miner's Fault goes political. Sovereignty vs. stability arguments rage for weeks.",
    effects: [
      { label: "Local hash rate", delta: "-60%" },
      { label: "Energy cost", delta: "+45%" },
      { label: "Political tension", delta: "+80%" },
    ],
    triggers: ["Regulatory decree", "Grid emergency", "Carbon mandate"],
    severity: "major", duration: "1–6m",
  },
  {
    id: "protocol-resurrection", name: "Protocol Resurrection", emoji: "🧟",
    tagline: "Declared dead 6 months ago. Now #3. Necromancy confirmed.",
    atmospheric: "A chain everyone buried has clawed out of the grave and is somehow top-three again.",
    systemic: "Abandoned infrastructure suddenly has demand. Dead relics re-value violently.",
    social: "The Archivists look smug. The skeptics delete old tweets. The cycle continues, as it must.",
    effects: [
      { label: "Dead-chain activity", delta: "+600%" },
      { label: "Relic value", delta: "+250%" },
      { label: "Archivist smugness", delta: "MAX" },
    ],
    triggers: ["Surprise upgrade", "Narrative flip", "Forgotten incentive"],
    severity: "major", duration: "2–8w",
  },
];

export const SHOCK_BY_ID: Record<string, Shock> = Object.fromEntries(
  SHOCKS.map((s) => [s.id, s])
);

/* ----------------------------------------------------------------------------
   MASKS — recognizable industry archetypes. No real IP. Total coincidence.
---------------------------------------------------------------------------- */
export const MASKS: Mask[] = [
  {
    id: "sato-shee", name: "Sato Shee", ref: "The Genesis Ghost", emoji: "🌑",
    title: "Architect of Genesis",
    blurb: "Started the entire Fold, then vanished without a trace. Last seen: nowhere. Political views: unknown. Identity: a fountain of conspiracy.",
    quote: "If you don't believe it or don't get it, I don't have time to convince you, sorry.",
    quest: "Trace the Genesis Signature across all seven regions.",
    color: "#8a92ff",
  },
  {
    id: "vita-lick", name: "Vita Lick", ref: "The Earnest Architect", emoji: "🧠",
    title: "Philosopher-King of Layers",
    blurb: "Wants to reorganize civilization using quadruple-layer rollups and a roadmap measured in geological epochs. Earnest. Brilliant. Possibly too earnest.",
    quote: "We can definitely solve this with one more abstraction layer. Probably.",
    quest: "Optimize a 3-layer node into a 7-layer paradox.",
    color: "#8a92ff",
  },
  {
    id: "don-trumpoid", name: "Don Trumpoid", ref: "Volatility Incarnate", emoji: "🏯",
    title: "Media-Mogul of Forum Zero",
    blurb: "A gold-skyscraper demagogue who moves entire sectors with a single ALL-CAPS sentence. Market and mood obey him before he finishes typing.",
    quote: "THE BEST SEASON. MANY PEOPLE ARE SAYING IT. BELIEVE ME.",
    quest: "Survive a Presidential Statement without re-pricing your entire vault.",
    color: "#ffb020",
  },
  {
    id: "elon-flux", name: "Elon Flux", ref: "The Techno-Jester", emoji: "🚀",
    title: "Rocket-Fixated Meme Lord",
    blurb: "A techno-trickster with a meme cannon and an obsession with pointy vehicles. Can ignite or incinerate a sector with a single dog emoji.",
    quote: "🚀🚀🚀 (context: none required)",
    quest: "Catch a meme-storm he launches from low orbit.",
    color: "#e84142",
  },
  {
    id: "sam-mirrorman", name: "Sam Mirrorman", ref: "The Illusionist", emoji: "🪞",
    title: "Fallen Emperor of Mirrors",
    blurb: "Built an empire of mirrors and effective-altruism theater. It reflected very little of substance. Then, spectacularly, it shattered.",
    quote: "We were doing it for the world. The world is still waiting on its funds.",
    quest: "Reconstruct the missing balance sheet from the Ashen Chain.",
    color: "#29e7ff",
  },
  {
    id: "czarn-chancellor", name: "Czarn Chancellor", ref: "The Liquidity Master", emoji: "🟡",
    title: "Keeper of the Off-Ramp",
    blurb: "Soft-spoken sovereign of deep order books and clean exit ramps. Speaks rarely; when he does, liquidity politely rearranges itself.",
    quote: "Funds are SAFU. We define SAFU internally. It's fine.",
    quest: "Negotiate a private off-ramp license during a Freeze.",
    color: "#f0b90b",
  },
  {
    id: "madame-peg", name: "Madame Peg", ref: "Priestess of the $1", emoji: "💵",
    title: "Oracle of Stability",
    blurb: "The entire Fold calibrates to her mood. When she holds $1, peace reigns. When she twitches, empires tremble and arbitrage desks overheat.",
    quote: "It is one dollar. It has always been one dollar. Please stop checking.",
    quest: "Hold the peg through a Stable Fracture without flinching.",
    color: "#26a17b",
  },
  {
    id: "justin-spiral", name: "Justin Spiral", ref: "The Relentless Promoter", emoji: "🌀",
    title: "Ambassador of Everything",
    blurb: "Will attach his name to any protocol, anywhere, at any time, with relentless enthusiasm. The Fold's most omnipresent hype vortex.",
    quote: "We are partnering. We are always partnering. What is the partnership? Later.",
    quest: "Decline three of his partnership offers without making an enemy.",
    color: "#27a2db",
  },
];

/* ----------------------------------------------------------------------------
   FUNCTIONAL ASSETS — utility, not JPEGs-for-JPEGs'-sake.
---------------------------------------------------------------------------- */
export const ASSETS: GameAsset[] = [
  { id: "a1", name: "Rumor Map: Forum Zero", type: "Intel Module", rarity: "rare", emoji: "🗺️",
    fn: "+15% signal accuracy in political regions.", flavor: "Tracks which lie is currently trending. Refreshed every block.",
    qty: 2, tokenized: true },
  { id: "a2", name: "Exit Ramp License", type: "Route License", rarity: "epic", emoji: "🛫",
    fn: "Priority withdrawal when the next Citadel enters 'maintenance'.", flavor: "Printed by Czarn's office. Smells faintly of jurisdiction.",
    qty: 1, tokenized: true },
  { id: "a3", name: "JPEG Relic — The Dogegg", type: "Crash Trophy", rarity: "legendary", emoji: "🥚",
    fn: "+status. Bragging rights. No utility. Iconic.", flavor: "A pixelated egg everyone laughed at. It's now worth a sedan.",
    qty: 1, tokenized: true },
  { id: "a4", name: "Defensive Oracle v3", type: "Security Contract", rarity: "rare", emoji: "🛡️",
    fn: "-30% raid success against your node.", flavor: "Watches your vault for exploits. Mostly. When it's awake.",
    qty: 3, tokenized: true },
  { id: "a5", name: "Reputation Seal", type: "Identity Asset", rarity: "epic", emoji: "🎖️",
    fn: "Unlocks high-trust contracts & guild roles.", flavor: "Forged in Crackdown. Cannot be bought, only earned. Allegedly.",
    qty: 1, tokenized: true },
  { id: "a6", name: "Event Blueprint: Airdrop Exodus", type: "Creator Asset", rarity: "epic", emoji: "📐",
    fn: "Lets you author a limited-time world event.", flavor: "Creator tools let the world grow itself. This one prints chaos.",
    qty: 1, tokenized: true },
  { id: "a7", name: "Block Sieve", type: "Node Module", rarity: "common", emoji: "⛏️",
    fn: "+8% material yield from mining ops.", flavor: "Sifts hash dust into something useful. Grindy but honest.",
    qty: 6, tokenized: false },
  { id: "a8", name: "Media Drone Mk-II", type: "Social Asset", rarity: "rare", emoji: "📡",
    fn: "+20% narrative influence spread.", flavor: "Broadcasts your take to the Fold whether they asked or not.",
    qty: 2, tokenized: false },
  { id: "a9", name: "Diplomatic Pass", type: "Governance Asset", rarity: "rare", emoji: "🪪",
    fn: "Vote weight in cross-faction councils.", flavor: "Lets you sit at tables you didn't build. Power move.",
    qty: 1, tokenized: true },
  { id: "a10", name: "Insurance Vault Stake", type: "DeFi Position", rarity: "epic", emoji: "🏦",
    fn: "Earns premiums; pays out on Bridge Breach.", flavor: "You're betting the world breaks. Statistically, you're right.",
    qty: 1, tokenized: true },
  { id: "a11", name: "Genesis Signature Shard", type: "Cycle Artifact", rarity: "mythic", emoji: "🌑",
    fn: "??? — Unlocks an unknown seasonal path.", flavor: "A fragment of the very first block. The Archivists won't stop staring.",
    qty: 1, tokenized: true },
  { id: "a12", name: "Cope Receipt", type: "Trophy", rarity: "common", emoji: "🧾",
    fn: "No function. Pure emotional support.", flavor: "Documents a trade you 'totally meant to hold'. We see you.",
    qty: 9, tokenized: false },
];

export const RARITY_COLOR: Record<string, string> = {
  common: "#8a96a3",
  rare: "#29e7ff",
  epic: "#9b6bff",
  legendary: "#ffb020",
  mythic: "#ff2d95",
};

/* ----------------------------------------------------------------------------
   WORLD MOOD bands (0–100). Mirrors Fear & Greed, with Fold commentary.
---------------------------------------------------------------------------- */
export const MOOD_BANDS: { max: number; label: string; vibe: string; color: string }[] = [
  { max: 24, label: "MAXIMUM CAPITULATION", vibe: "Everyone's posting their Ls. Bottom is near. So is the next one.", color: "#ff4d4d" },
  { max: 44, label: "BRUISED BUT BREEDING", vibe: "Fear. The tourists are gone. The operators are loading quietly.", color: "#ff6a3d" },
  { max: 55, label: "SCHRÖDINGER'S MARKET", vibe: "Could go either way. It has, historically, done both. Painfully.", color: "#ffb020" },
  { max: 75, label: "GREASED & GLAZING", vibe: "Greed. Charts are green, group chats are loud, leverage is high.", color: "#c6ff00" },
  { max: 100, label: "ULTRAGREEN DELUSION", vibe: "Your cab driver is a degen. This is the top. Or the start. Nobody knows.", color: "#00ff9c" },
];

/* ----------------------------------------------------------------------------
   Transmission library — evergreen satirical signals. Data-driven ones are
   injected at runtime based on live price moves.
---------------------------------------------------------------------------- */
export const TRANSMISSION_SEED: Omit<Transmission, "id" | "ts">[] = [
  { source: "FORUM ZERO", text: "Don Trumpoid considering a 'strategic meme reserve'. Floor prices undecided.", tone: "hype" },
  { source: "ASHEN CHAIN", text: "Archivists unearthed a 2021 whitepaper. It aged like milk. Worth studying.", tone: "info" },
  { source: "CITADEL", text: "Leverage at record highs. Funding rates suggest someone is about to learn a lesson.", tone: "warn" },
  { source: "PORT OF BRIDGES", text: "New bridge launched. Audited by 'trust me bro'. TVL already $40M.", tone: "raid" },
  { source: "VAULTSTEP", text: "A 312% APR vault appeared. The contract is 9 lines long. This is fine.", tone: "warn" },
  { source: "JPEG REEF", text: "Floor up 80% on a collection with no roadmap. Utility remains legally optional.", tone: "hype" },
  { source: "MINER'S FAULT", text: "Hash rate migrated overnight. Two regions are now arguing about electricity.", tone: "reg" },
  { source: "WHALE WATCH", text: "An ancient wallet blinked after 7 years of silence. The Fold is being calm. Badly.", tone: "alpha" },
  { source: "ANON OPERATOR", text: "Accidentally bought the wrong token. It's up 900%. I am a genius now.", tone: "hype" },
  { source: "REG DESK", text: "New 'framework' announced. It clarifies nothing but sounds important.", tone: "reg" },
  { source: "PEG TEMPLE", text: "Madame Peg held $1 today. The high priestess is displeased you checked.", tone: "info" },
  { source: "RAIDER NET", text: "Found a re-entrancy bug. Reported it. (That's the official story.)", tone: "raid" },
  { source: "DEGEN COUNCIL", text: "Consensus reached: 'probably a bottom'. The Council has been wrong before.", tone: "fud" },
  { source: "AI OVERSEER", text: "Anti-cheat flagged 14,000 sybil accounts. They all claim to be 'real people'.", tone: "info" },
  { source: "FORUM ZERO", text: "An influencer defined 'rug pull' on stream. Chat clipped it as a confession.", tone: "hype" },
];

/* Satirical one-liners cycled in the top ticker. */
export const TICKER_LINES: string[] = [
  "⚡ LIVE MARKET FEED WIRING THE WORLD STATE — THE FOLD IS AWAKE",
  "🔪 NOT FINANCIAL ADVICE. DEFINITELY NOT. PROBABLY NOT.",
  "🪦 PAST PERFORMANCE DOES NOT GUARANTEE FUTURE REKT",
  "🤡 WEAPONIZED NARRATIVES NOW IN SEASON",
  "📈 'THIS TIME IT'S DIFFERENT' — SAID EVERY CYCLE, EVERY TIME",
  "🛡️ DYOR: DO YOUR OWN REKT",
  "🐋 WHALE ACTIVITY: PARANOID BUT VALID",
  "🧊 WITHDRAWALS ENABLED (FOR NOW)",
  "⚖️ REGULATION: 'COMING SOON' SINCE 2013",
  "🐸 THE FROG REMAINS UNBOTHERED. THE FROG IS ALWAYS UP.",
];
