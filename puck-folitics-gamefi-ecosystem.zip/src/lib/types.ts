export type ViewId =
  | "node"
  | "fold"
  | "markets"
  | "intel"
  | "factions"
  | "vault"
  | "masks";

export type FactionId = "builders" | "speculators" | "archivists" | "raiders";

export type Rarity = "common" | "rare" | "epic" | "legendary" | "mythic";

export type Tone =
  | "info"
  | "warn"
  | "hype"
  | "fud"
  | "raid"
  | "alpha"
  | "reg";

export interface Coin {
  id: string; // coingecko id
  symbol: string;
  name: string;
  foldName: string;
  tagline: string;
  color: string;
  emoji: string;
  category: "blue" | "defi" | "meme" | "stable" | "l1" | "ai";
  // runtime (live) fields:
  price: number;
  change24h: number;
  sparkline: number[];
  marketCap?: number;
}

export interface Faction {
  id: FactionId;
  name: string;
  color: string;
  emoji: string;
  motto: string;
  blurb: string;
  playstyle: string;
}

export interface Region {
  id: string;
  name: string;
  faction: FactionId;
  color: string;
  emoji: string;
  tagline: string;
  desc: string;
  crafts: string[];
  threats: string[];
  x: number; // map position %
  y: number;
}

export type Severity = "minor" | "major" | "apocalyptic";

export interface Shock {
  id: string;
  name: string;
  emoji: string;
  tagline: string;
  atmospheric: string;
  systemic: string;
  social: string;
  effects: { label: string; delta: string }[];
  triggers: string[];
  severity: Severity;
  duration: string;
}

export interface GameAsset {
  id: string;
  name: string;
  type: string;
  rarity: Rarity;
  emoji: string;
  fn: string;
  flavor: string;
  qty: number;
  tokenized: boolean;
}

export interface Mask {
  id: string;
  name: string;
  ref: string;
  emoji: string;
  title: string;
  blurb: string;
  quote: string;
  quest: string;
  color: string;
}

export interface Transmission {
  id: string;
  source: string;
  text: string;
  tone: Tone;
  ts: number;
}

export type SeasonId = "bull" | "bear" | "rotation" | "crackdown";

export interface Season {
  id: SeasonId;
  name: string;
  emoji: string;
  tagline: string;
  desc: string;
  color: string;
}
