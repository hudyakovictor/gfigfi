import {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
  type ReactNode,
} from "react";
import type { Coin, FactionId, Shock, Transmission, Tone } from "./types";
import {
  COINS,
  SHOCK_BY_ID,
  MOOD_BANDS,
  TRANSMISSION_SEED,
  COIN_BY_ID,
  SHOCKS,
} from "./gameData";
import { clamp, pick, uid } from "./format";

/* ============================================================================
   THE FOLD ENGINE
   - LIVE mode: anchors the world to REAL markets (CoinGecko + Fear & Greed),
     while a light simulation keeps it breathing between snapshots.
   - SIM mode: fully fictional drift — the world stays alive offline.
   Real market moves get re-cast as world mood, season, shocks & transmissions.
   ========================================================================== */

type Mode = "live" | "sim";

export interface Resources {
  energy: number;
  maxEnergy: number;
  materials: number;
  signal: number;
  security: number;
  influence: number;
  fold: number;
}

export interface NodeState {
  name: string;
  type: string;
  specialization: string;
  tier: number;
  rankIndex: number;
  rank: string;
  rankProgress: number; // 0..100 within current rank
}

export interface ActionResult {
  ok: boolean;
  msg: string;
  tone?: Tone;
}

export const SPECIALIZATIONS = [
  { id: "production", name: "Production", icon: "🏭", desc: "Forge materials & infrastructure. Slow, honest, profitable in Bear." },
  { id: "recon", name: "Recon / Intel", icon: "🛰️", desc: "Scan signals, read the crowd, sell the truth. Thrives on chaos." },
  { id: "logistics", name: "Logistics", icon: "🚚", desc: "Move capital across bridges & routes. Gets paid when others panic." },
  { id: "media", name: "Media Influence", icon: "📺", desc: "Manufacture narrative. Mint momentum. Become the news." },
  { id: "security", name: "Security Ops", icon: "🛡️", desc: "Sell protection & insurance. Hated until needed — then priceless." },
  { id: "arbitrage", name: "Arbitrage", icon: "⚖️", desc: "Exploit spreads & depegs. Pure edge. Zero loyalty." },
  { id: "craft", name: "Craft / Creator", icon: "🛠️", desc: "Build modules, blueprints & events. Expand the world itself." },
  { id: "diplomacy", name: "Diplomacy", icon: "🤝", desc: "Broker alliances & treaties. Win without fighting." },
];

const RANKS = ["Drift Scrub", "Node Runner", "Sector Operator", "Citadel Insider", "Fold Architect", "Timeline Sovereign"];

const GAINER_LINES = [
  "the crowd has decided this is the future. The crowd is often wrong, but very loudly.",
  "someone's cousin just became a portfolio manager overnight. Conviction: maximum.",
  "fundamentals unchanged. Vibes: immaculate. Allocation: possibly your rent.",
  "this was on nobody's radar yesterday. It is on everybody's radar now.",
  "a whale sneezed upward. The ripple is already a tsunami.",
  "the whitepaper is still 3 lines long. The market cap is not.",
];
const LOSER_LINES = [
  "the 'strong hands' are quietly sweating through their keyboards.",
  "it was a 'healthy pullback'. It is becoming a 'structural reassessment'.",
  "the group chat went from 'WAGMI' to 'any good lawyers?' in twelve minutes.",
  "leverage is being taught a lesson. The lesson is not cheap.",
  "buyers are 'waiting for a better entry'. The entry keeps relocating.",
];

interface GameApi {
  mode: Mode;
  setMode: (m: Mode) => void;
  liveConnected: boolean;
  loading: boolean;
  coins: Coin[];
  fng: number | null;
  mood: number;
  vol: number;
  seasonId: string;
  activeShock: Shock | null;
  shockRemaining: number;
  resources: Resources;
  node: NodeState;
  factionRep: Record<FactionId, number>;
  transmissions: Transmission[];
  block: number;
  lastUpdate: number;
  foldPrice: number;
  scanSignals: () => ActionResult;
  deployModule: () => ActionResult;
  forgeAlliance: (f: FactionId) => ActionResult;
  hedgeCataclysm: () => ActionResult;
  arbitrage: () => ActionResult;
  lockInfluence: () => ActionResult;
  setSpecialization: (id: string) => void;
}

const Ctx = createContext<GameApi | null>(null);
const COIN_IDS = COINS.map((c) => c.id).join(",");

function downsample(arr: number[], n: number): number[] {
  if (!arr || arr.length === 0) return [];
  if (arr.length <= n) return arr.slice();
  const out: number[] = [];
  const stride = arr.length / n;
  for (let i = 0; i < n; i++) out.push(arr[Math.floor(i * stride)]);
  return out;
}

function genSpark(price: number, n = 34): number[] {
  const out: number[] = [];
  let p = price * (0.97 + Math.random() * 0.02);
  for (let i = 0; i < n; i++) {
    p *= 1 + (Math.random() - 0.5) * 0.012;
    out.push(p);
  }
  out[out.length - 1] = price;
  return out;
}

function weightedAvgChange(coins: Coin[]): number {
  const w = (c: Coin) => (c.id === "bitcoin" ? 3 : c.category === "meme" ? 0.5 : 1);
  let num = 0, den = 0;
  for (const c of coins) {
    const ww = w(c);
    num += (c.change24h ?? 0) * ww;
    den += ww;
  }
  return den ? num / den : 0;
}

function computeMood(coins: Coin[], fng: number | null): number {
  if (fng != null && isFinite(fng)) return clamp(fng, 1, 99);
  const avg = weightedAvgChange(coins);
  return clamp(50 + avg * 5.4, 3, 97);
}

function computeVol(coins: Coin[]): number {
  const ch = coins.map((c) => Math.abs(c.change24h ?? 0));
  return ch.reduce((a, b) => a + b, 0) / (ch.length || 1);
}

function seasonFor(mood: number, vol: number): string {
  if (mood >= 60) return "bull";
  if (mood <= 34) return "bear";
  if (vol >= 4.2) return "crackdown";
  return "rotation";
}

function evaluateShock(coins: Coin[], mood: number): Shock | null {
  const byId = (id: string) => coins.find((c) => c.id === id) || COIN_BY_ID[id];
  const btc = byId("bitcoin");
  const usdt = byId("tether");
  const memes = (["dogecoin", "pepe", "shiba-inu"].map(byId).filter(Boolean) as Coin[]);
  const topMeme = memes.reduce((a, b) => (Math.abs(b.change24h) > Math.abs(a.change24h) ? b : a), memes[0]);
  const vol = computeVol(coins);

  if (Math.abs((usdt?.price ?? 1) - 1) > 0.006 || (usdt?.change24h ?? 0) < -0.25)
    return SHOCK_BY_ID["stable-fracture"];
  if ((btc?.change24h ?? 0) <= -4.2) return pick([SHOCK_BY_ID["exchange-freeze"], SHOCK_BY_ID["whale-awakening"]]);
  if (topMeme && topMeme.change24h >= 13) return mood >= 55 ? SHOCK_BY_ID["jpeg-mania"] : SHOCK_BY_ID["meme-fever"];
  if (mood >= 72) return pick([SHOCK_BY_ID["meme-fever"], SHOCK_BY_ID["jpeg-mania"]]);
  if (mood <= 26) return pick([SHOCK_BY_ID["exchange-freeze"], SHOCK_BY_ID["whale-awakening"]]);
  if (vol >= 5.2) return pick([SHOCK_BY_ID["bridge-breach"], SHOCK_BY_ID["fork-dispute"]]);
  if (mood <= 42 && vol <= 3) return pick([SHOCK_BY_ID["influencer-trial"], SHOCK_BY_ID["mining-ban"]]);
  return null;
}

function shockNarrative(shock: Shock): Transmission {
  const tone: Tone = shock.severity === "apocalyptic" ? "raid" : shock.severity === "major" ? "warn" : "info";
  return {
    id: uid(),
    source: "WORLD SHOCK",
    text: `${shock.emoji} ${shock.name.toUpperCase()} — ${shock.tagline}`,
    tone,
    ts: Date.now(),
  };
}

const initCoins = (): Coin[] => COINS.map((c) => ({ ...c, sparkline: genSpark(c.price) }));
const initResources: Resources = {
  energy: 64, maxEnergy: 100, materials: 128, signal: 22, security: 46, influence: 95, fold: 1240,
};

export function GameProvider({ children }: { children: ReactNode }) {
  const [mode, setMode] = useState<Mode>("live");
  const [liveConnected, setLiveConnected] = useState(false);
  const [loading, setLoading] = useState(true);
  const [coins, setCoins] = useState<Coin[]>(initCoins);
  const [fng, setFng] = useState<number | null>(null);
  const [activeShock, setActiveShock] = useState<Shock | null>(null);
  const [shockRemaining, setShockRemaining] = useState(0);
  const [block, setBlock] = useState(8392014);
  const [transmissions, setTransmissions] = useState<Transmission[]>(() =>
    TRANSMISSION_SEED.slice(0, 6).map((t) => ({ ...t, id: uid(), ts: Date.now() - Math.random() * 600000 }))
  );
  const [resources, setResources] = useState<Resources>(initResources);
  const [node, setNode] = useState<NodeState>({
    name: "Node 0x7F // Vaultstep Relay",
    type: "Data-Port Node",
    specialization: "recon",
    tier: 2,
    rankIndex: 1,
    rank: RANKS[1],
    rankProgress: 18,
  });
  const [factionRep, setFactionRep] = useState<Record<FactionId, number>>({
    builders: 42, speculators: 58, archivists: 71, raiders: 24,
  });
  const [lastUpdate, setLastUpdate] = useState(Date.now());

  const coinsRef = useRef(coins);
  const moodRef = useRef(50);
  const activeShockRef = useRef<Shock | null>(null);
  const seedCounterRef = useRef(0);
  const linkedOnce = useRef(false);
  const baseChange = useRef<Record<string, number>>(
    Object.fromEntries(COINS.map((c) => [c.id, c.change24h]))
  );

  const mood = useMemo(() => computeMood(coins, fng), [coins, fng]);
  const vol = useMemo(() => computeVol(coins), [coins]);
  const seasonId = useMemo(() => seasonFor(mood, vol), [mood, vol]);
  const foldPrice = useMemo(() => clamp(0.18 + mood / 95, 0.12, 2.4), [mood]);

  useEffect(() => { coinsRef.current = coins; }, [coins]);
  useEffect(() => { moodRef.current = mood; }, [mood]);
  useEffect(() => { activeShockRef.current = activeShock; }, [activeShock]);

  const pushTransmission = useCallback(
    (t: Omit<Transmission, "id" | "ts"> & { id?: string; ts?: number }) => {
      setTransmissions((prev) => {
        const entry: Transmission = {
          id: t.id ?? uid(), source: t.source, text: t.text, tone: t.tone, ts: t.ts ?? Date.now(),
        };
        return [entry, ...prev].slice(0, 60);
      });
    },
    []
  );

  /* ---------------- LIVE MARKET FETCH (CoinGecko + Fear & Greed) ----------- */
  const fetchLive = useCallback(async () => {
    try {
      const ctrl = new AbortController();
      const to = setTimeout(() => ctrl.abort(), 9000);
      const [mk, fngRes] = await Promise.allSettled([
        fetch(
          `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${COIN_IDS}&order=market_cap_desc&sparkline=true&price_change_percentage=24h`,
          { signal: ctrl.signal }
        ),
        fetch("https://api.alternative.me/fng/?limit=1", { signal: ctrl.signal }),
      ]);
      clearTimeout(to);

      if (mk.status === "fulfilled" && mk.value.ok) {
        const json = await mk.value.json();
        setCoins((prev) =>
          prev.map((c) => {
            const d = (json as any[]).find((x) => x.id === c.id);
            if (!d) return c;
            const price = Number(d.current_price) || c.price;
            const change = d.price_change_percentage_24h ?? c.change24h;
            const spark = downsample(d.sparkline_in_7d?.price ?? [], 34);
            return {
              ...c, price, change24h: change,
              marketCap: d.market_cap ?? c.marketCap,
              sparkline: spark.length ? spark : c.sparkline,
            };
          })
        );
        // re-cast REAL market movers as satirical world intel
        try {
          const arr = (json as any[])
            .map((d) => ({ id: d.id as string, ch: Number(d.price_change_percentage_24h) || 0 }))
            .filter((x) => isFinite(x.ch));
          const sorted = [...arr].sort((a, b) => b.ch - a.ch);
          const top = sorted[0];
          const bot = sorted[sorted.length - 1];
          const emit = (m: { id: string; ch: number } | undefined, tone: Tone, tmpl: (c: Coin, ch: number) => string) => {
            if (!m) return;
            const coin = COIN_BY_ID[m.id];
            if (!coin || Math.abs(m.ch) < 4.5) return;
            pushTransmission({ source: "LIVE MKT", text: tmpl(coin, m.ch), tone });
          };
          emit(top, "hype", (c, ch) => `${c.emoji} ${c.foldName} (${c.symbol}) ${ch >= 0 ? "+" : ""}${ch.toFixed(1)}% — ${pick(GAINER_LINES)}`);
          emit(bot, bot && bot.ch < 0 ? "fud" : "info", (c, ch) => `${c.emoji} ${c.foldName} (${c.symbol}) ${ch.toFixed(1)}% — ${pick(LOSER_LINES)}`);
          if (!linkedOnce.current) {
            linkedOnce.current = true;
            pushTransmission({ source: "SYSTEM", text: "⚡ LIVE MARKETS LINKED — the Fold now tracks reality. Every candle rewrites the world.", tone: "alpha" });
          }
        } catch { /* intel must never break the feed */ }
        setLiveConnected(true);
        setLoading(false);
        setLastUpdate(Date.now());
      } else {
        setLiveConnected(false);
        setLoading(false);
      }

      if (fngRes.status === "fulfilled" && fngRes.value.ok) {
        const fj = await fngRes.value.json();
        const v = Number(fj?.data?.[0]?.value);
        if (isFinite(v)) setFng(v);
      }
    } catch {
      setLiveConnected(false);
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (mode !== "live") return;
    fetchLive();
    const iv = setInterval(fetchLive, 45000);
    return () => clearInterval(iv);
  }, [mode, fetchLive]);

  /* ---------------- SIM DRIFT (always runs; keeps the world breathing) -----
     When LIVE markets are connected we only gently shimmer around the real
     price (faithful to reality). In SIM / fallback we run a full lively drift. */
  useEffect(() => {
    const iv = setInterval(() => {
      setCoins((prev) =>
        prev.map((c) => {
          const base = baseChange.current[c.id] ?? 0;
          const isMeme = c.category === "meme";
          let ch = c.change24h ?? 0;
          if (liveConnected) {
            ch += (Math.random() - 0.5) * (isMeme ? 1.1 : 0.45);
            if (Math.random() < 0.02) ch += (Math.random() - 0.5) * (isMeme ? 5 : 2.5);
          } else {
            ch += (base - ch) * 0.06 + (Math.random() - 0.5) * (isMeme ? 3.4 : 1.3);
            if (Math.random() < 0.04) ch += (Math.random() - 0.5) * (isMeme ? 14 : 6);
          }
          ch = clamp(ch, isMeme ? -45 : -16, isMeme ? 45 : 16);
          const move = ch / 100 / (isMeme ? 140 : 190);
          const price = Math.max(c.price * (1 + move), c.price * 0.5);
          const spark = [...(c.sparkline ?? []), price];
          if (spark.length > 34) spark.shift();
          return { ...c, price, change24h: ch, sparkline: spark };
        })
      );
    }, 3000);
    return () => clearInterval(iv);
  }, [liveConnected]);

  /* ---------------- MASTER 1s TICK: block, scheduler, regen, chatter ------ */
  useEffect(() => {
    const iv = setInterval(() => {
      setBlock((b) => b + 1);

      setShockRemaining((rem) => {
        if (rem > 1) return rem - 1;
        const { shock, duration, tx } = scheduleNext(coinsRef.current, moodRef.current, activeShockRef.current);
        setActiveShock(shock);
        if (tx) pushTransmission(tx);
        return duration;
      });

      setResources((r) => {
        const energy = clamp(r.energy + 0.9, 0, r.maxEnergy);
        let security = r.security;
        const sid = activeShockRef.current?.id;
        if (sid === "bridge-breach" || sid === "exchange-freeze") security = clamp(security - 0.25, 0, 100);
        else security = clamp(security + 0.15, 0, 100);
        return { ...r, energy, security };
      });

      seedCounterRef.current += 1;
      if (seedCounterRef.current % 14 === 0) pushTransmission(pick(TRANSMISSION_SEED));
    }, 1000);
    return () => clearInterval(iv);
  }, [pushTransmission]);

  /* ---------------- ACTIONS (the core gameplay loop) ---------------------- */
  const scanSignals = useCallback((): ActionResult => {
    setResources((r) => {
      if (r.energy < 6) return r;
      const gain = 6 + Math.round(Math.random() * 10);
      setTimeout(() => pushTransmission({
        source: "RECON",
        text: pick([
          "Crowd sentiment parsed. Half of them are lying. Filed anyway.",
          "Picked up a signal through the noise. It's probably nothing. It's never nothing.",
          "Rumor map updated. Three of these will be true by tomorrow.",
        ]),
        tone: "alpha",
      }), 0);
      return { ...r, energy: r.energy - 6, signal: r.signal + gain, influence: r.influence + 1 };
    });
    return { ok: true, msg: "Signals scanned. Intel +.", tone: "alpha" };
  }, [pushTransmission]);

  const deployModule = useCallback((): ActionResult => {
    let ok = false;
    setResources((r) => {
      if (r.materials < 24 || r.energy < 14) return r;
      ok = true;
      return { ...r, materials: r.materials - 24, energy: r.energy - 14, influence: r.influence + 4 };
    });
    return ok
      ? { ok: true, msg: "Module deployed. Production node expanded.", tone: "info" }
      : { ok: false, msg: "Need ≥24 materials & 14 energy.", tone: "warn" };
  }, []);

  const arbitrage = useCallback((): ActionResult => {
    let ok = false;
    setResources((r) => {
      if (r.signal < 12) return r;
      ok = true;
      const gain = 60 + Math.round(Math.random() * 140);
      return { ...r, signal: r.signal - 12, fold: r.fold + gain };
    });
    return ok
      ? { ok: true, msg: "Spread captured. +$FOLD.", tone: "hype" }
      : { ok: false, msg: "Need ≥12 signal to find an edge.", tone: "warn" };
  }, []);

  const hedgeCataclysm = useCallback((): ActionResult => {
    let ok = false;
    setResources((r) => {
      if (r.fold < 200) return r;
      ok = true;
      return { ...r, fold: r.fold - 200, security: clamp(r.security + 22, 0, 100) };
    });
    return ok
      ? { ok: true, msg: "Cataclysm hedged. Security reinforced.", tone: "info" }
      : { ok: false, msg: "Insurance costs 200 $FOLD.", tone: "warn" };
  }, []);

  const forgeAlliance = useCallback((f: FactionId): ActionResult => {
    let ok = false;
    setResources((r) => {
      if (r.influence < 25) return r;
      ok = true;
      return { ...r, influence: r.influence - 25 };
    });
    if (ok) {
      setFactionRep((rep) => ({ ...rep, [f]: clamp(rep[f] + 9, 0, 100) }));
      setTimeout(() => pushTransmission({
        source: "DIPLOMACY",
        text: pick([
          "Alliance sealed over a shared enemy. The strongest kind.",
          "Treaty signed. Neither side trusts it. Both will honor it. For now.",
          "You traded influence for friends. Classic exchange-rate play.",
        ]),
        tone: "info",
      }), 0);
      return { ok: true, msg: "Alliance forged. Faction standing up.", tone: "info" };
    }
    return { ok: false, msg: "Need ≥25 influence to broker.", tone: "warn" };
  }, [pushTransmission]);

  const lockInfluence = useCallback((): ActionResult => {
    let ok = false;
    setResources((r) => {
      if (r.influence < 60) return r;
      ok = true;
      return { ...r, influence: r.influence - 60 };
    });
    if (ok) {
      setNode((n) => {
        let progress = n.rankProgress + 26;
        let idx = n.rankIndex;
        if (progress >= 100) {
          progress -= 100;
          idx = Math.min(idx + 1, RANKS.length - 1);
        }
        return { ...n, rankProgress: progress, rankIndex: idx, rank: RANKS[idx], tier: Math.max(n.tier, idx + 1) };
      });
      return { ok: true, msg: "Influence crystallized. Rank advanced.", tone: "hype" };
    }
    return { ok: false, msg: "Need ≥60 influence to crystallize.", tone: "warn" };
  }, []);

  const setSpecialization = useCallback((id: string) => {
    setNode((n) => ({ ...n, specialization: id }));
  }, []);

  const value: GameApi = {
    mode, setMode, liveConnected, loading,
    coins, fng, mood, vol, seasonId,
    activeShock, shockRemaining,
    resources, node, factionRep, transmissions, block, lastUpdate, foldPrice,
    scanSignals, deployModule, forgeAlliance, hedgeCataclysm, arbitrage, lockInfluence, setSpecialization,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

/* scheduler picks the next shock (or a calm window) */
function scheduleNext(coins: Coin[], mood: number, current: Shock | null) {
  const candidate = evaluateShock(coins, mood);
  if (candidate) {
    const duration = candidate.severity === "apocalyptic" ? 50 + Math.random() * 50 : 28 + Math.random() * 40;
    const changed = !current || current.id !== candidate.id;
    return { shock: candidate, duration: Math.round(duration), tx: changed ? shockNarrative(candidate) : null };
  }
  const calmDuration = 16 + Math.random() * 22;
  const tx: Transmission | null = current
    ? { id: uid(), source: "THE FOLD", text: "🌫️ The noise settles. The world holds its breath. Reload. Re-arm.", tone: "info" as Tone, ts: Date.now() }
    : null;
  return { shock: null, duration: Math.round(calmDuration), tx };
}

export function useGame(): GameApi {
  const v = useContext(Ctx);
  if (!v) throw new Error("useGame must be used within GameProvider");
  return v;
}

export { MOOD_BANDS, SHOCKS };
