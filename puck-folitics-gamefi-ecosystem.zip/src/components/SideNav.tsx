import type { ViewId } from "../lib/types";
import { useGame } from "../lib/useGame";
import { cn } from "../utils/cn";

const NAV: { id: ViewId; label: string; icon: string }[] = [
  { id: "node", label: "NODE", icon: "🛰️" },
  { id: "fold", label: "THE FOLD", icon: "🗺️" },
  { id: "markets", label: "MARKETS", icon: "📈" },
  { id: "intel", label: "INTEL", icon: "📡" },
  { id: "factions", label: "FACTIONS", icon: "⚔️" },
  { id: "vault", label: "VAULT", icon: "🎒" },
  { id: "masks", label: "MASKS", icon: "🎭" },
];

export default function SideNav({ view, setView }: { view: ViewId; setView: (v: ViewId) => void }) {
  const { node } = useGame();
  return (
    <nav className="shrink-0 w-[68px] glass-strong border-r border-line flex flex-col items-stretch py-2">
      <div className="flex flex-col gap-1 px-1.5 flex-1">
        {NAV.map((n) => {
          const active = view === n.id;
          return (
            <button key={n.id} onClick={() => setView(n.id)}
              className={cn("group relative clip-sm flex flex-col items-center gap-1 py-2 transition-all",
                active ? "bg-white/8" : "hover:bg-white/5")}>
              {active && <span className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-[3px] rounded-r bg-toxic" style={{ boxShadow: "0 0 8px #00ff9c" }} />}
              <span className={cn("text-lg transition-transform", active ? "scale-110" : "opacity-70 group-hover:opacity-100 group-hover:scale-105")}>{n.icon}</span>
              <span className={cn("chip text-[8px] leading-none", active ? "text-toxic" : "text-ink-dim")}>{n.label}</span>
            </button>
          );
        })}
      </div>
      <div className="px-1.5 pt-2 border-t border-line/60 mt-2">
        <div className="grid place-items-center py-1">
          <div className="w-8 h-8 rounded-full grid place-items-center font-display font-bold text-xs"
            style={{ background: "linear-gradient(135deg,#9b6bff,#ff2d95)", color: "#fff" }}>0x7F</div>
          <span className="chip text-[7px] text-ink-dim mt-1 text-center leading-tight">T{node.tier}</span>
        </div>
      </div>
    </nav>
  );
}
