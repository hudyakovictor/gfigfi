import { useId, type ReactNode } from "react";
import { cn } from "../utils/cn";
import type { Tone } from "../lib/types";
import { MOOD_BANDS } from "../lib/gameData";

/* ----------------------------- Tone styling ----------------------------- */
export const TONE: Record<Tone, { color: string; label: string }> = {
  info: { color: "#29e7ff", label: "INFO" },
  warn: { color: "#ffb020", label: "WARN" },
  hype: { color: "#00ff9c", label: "HYPE" },
  fud: { color: "#ff6a3d", label: "FUD" },
  raid: { color: "#ff2d95", label: "RAID" },
  alpha: { color: "#c6ff00", label: "ALPHA" },
  reg: { color: "#9b6bff", label: "REG" },
};

export function MOOD_COLOR(mood: number) {
  const band = MOOD_BANDS.find((b) => mood <= b.max) || MOOD_BANDS[MOOD_BANDS.length - 1];
  return band;
}

/* -------------------------------- Panel --------------------------------- */
export function Panel({
  title, icon, accent = "#29e7ff", right, children, className, bodyClass,
}: {
  title?: ReactNode; icon?: ReactNode; accent?: string;
  right?: ReactNode; children: ReactNode; className?: string; bodyClass?: string;
}) {
  return (
    <section className={cn("glass clip relative", className)}>
      {title && (
        <header
          className="flex items-center justify-between gap-2 border-b border-line/60 px-3 py-2"
          style={{ background: `linear-gradient(90deg, ${accent}1f, transparent 60%)` }}
        >
          <div className="flex items-center gap-2 min-w-0">
            {icon && <span className="text-sm shrink-0" style={{ color: accent }}>{icon}</span>}
            <h3 className="chip truncate" style={{ color: accent }}>{title}</h3>
          </div>
          {right && <div className="shrink-0 text-[11px] text-ink-dim font-mono">{right}</div>}
        </header>
      )}
      <div className={cn("p-3", bodyClass)}>{children}</div>
    </section>
  );
}

/* ------------------------------ Sparkline ------------------------------- */
export function Sparkline({
  data, color = "#00ff9c", width = 88, height = 28, strokeWidth = 1.5, fill = true, fluid = false,
}: { data: number[]; color?: string; width?: number; height?: number; strokeWidth?: number; fill?: boolean; fluid?: boolean }) {
  const id = useId();
  if (!data || data.length < 2) return <svg width={fluid ? "100%" : width} height={height} />;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const stepX = width / (data.length - 1);
  const pts = data.map((v, i) => {
    const x = i * stepX;
    const y = height - ((v - min) / range) * (height - 4) - 2;
    return [x, y] as const;
  });
  const line = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
  const area = `${line} L${width},${height} L0,${height} Z`;
  return (
    <svg
      width={fluid ? "100%" : width}
      height={height}
      viewBox={fluid ? `0 0 ${width} ${height}` : undefined}
      preserveAspectRatio={fluid ? "none" : undefined}
      className="overflow-visible block"
      style={{ maxWidth: "100%" }}>
      <defs>
        <linearGradient id={`spk-${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.32" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {fill && <path d={area} fill={`url(#spk-${id})`} />}
      <path d={line} fill="none" stroke={color} strokeWidth={strokeWidth} strokeLinejoin="round" strokeLinecap="round" />
      <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r={1.8} fill={color} />
    </svg>
  );
}

/* -------------------------------- Bar ----------------------------------- */
export function Bar({ value, max = 100, color = "#00ff9c", height = 8, className, glow }:
  { value: number; max?: number; color?: string; height?: number; className?: string; glow?: boolean }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div className={cn("w-full rounded-full bg-white/8 overflow-hidden", className)} style={{ height }}>
      <div className="h-full rounded-full transition-all duration-500"
        style={{ width: `${pct}%`, background: color, boxShadow: glow ? `0 0 10px ${color}` : undefined }} />
    </div>
  );
}

/* ------------------------------- DeltaPill ------------------------------ */
export function DeltaPill({ value, className }: { value: number; className?: string }) {
  const up = value >= 0;
  const color = up ? "#00ff9c" : "#ff4d4d";
  return (
    <span className={cn("chip tnum px-1.5 py-0.5 rounded", className)} style={{ color, background: `${color}1a` }}>
      {up ? "▲" : "▼"} {Math.abs(value).toFixed(2)}%
    </span>
  );
}

/* ------------------------------ GlowButton ----------------------------- */
export function GlowButton({ children, onClick, color = "#00ff9c", disabled, className, title, subtle }:
  { children: ReactNode; onClick?: () => void; color?: string; disabled?: boolean; className?: string; title?: string; subtle?: boolean }) {
  return (
    <button onClick={onClick} disabled={disabled} title={title}
      className={cn(
        "clip-sm group relative overflow-hidden px-3 py-2 text-left transition-all duration-150",
        "disabled:opacity-40 disabled:cursor-not-allowed enabled:hover:-translate-y-0.5 enabled:active:translate-y-0",
        subtle ? "border border-line bg-white/5" : "", className
      )}
      style={{
        color: subtle ? color : "#06121a",
        background: subtle ? undefined : `linear-gradient(180deg, ${color}, ${color}cc)`,
        boxShadow: disabled ? "none" : `0 0 18px -6px ${color}`,
        fontWeight: 600,
      }}>
      <span className="relative z-10 flex items-center gap-2 font-display text-[13px]">{children}</span>
      {!subtle && !disabled && (
        <span className="pointer-events-none absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity"
          style={{ background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.25), transparent)" }} />
      )}
    </button>
  );
}

/* --------------------------------- Stat --------------------------------- */
export function Stat({ label, value, sub, color, align = "left" }:
  { label: ReactNode; value: ReactNode; sub?: ReactNode; color?: string; align?: "left" | "center" | "right" }) {
  return (
    <div className={cn(align === "right" && "text-right", align === "center" && "text-center")}>
      <div className="chip text-ink-dim">{label}</div>
      <div className="font-mono text-base font-semibold leading-tight" style={{ color: color || "#d4dde6" }}>{value}</div>
      {sub && <div className="text-[11px] text-ink-dim font-mono">{sub}</div>}
    </div>
  );
}

/* --------------------------------- Tag ---------------------------------- */
export function Tag({ children, color = "#8a96a3", filled = true }:
  { children: ReactNode; color?: string; filled?: boolean }) {
  return (
    <span className="chip inline-flex items-center gap-1 px-1.5 py-0.5 rounded"
      style={filled ? { color, background: `${color}1f`, border: `1px solid ${color}40` } : { color }}>
      {children}
    </span>
  );
}

export function Hairline({ className }: { className?: string }) {
  return <div className={cn("h-px w-full bg-line", className)} />;
}

/* --------------------------- Mood gauge (arc) --------------------------- */
export function MoodGauge({ mood, size = 120 }: { mood: number; size?: number }) {
  const r = size / 2 - 8;
  const c = 2 * Math.PI * r;
  const band = MOOD_COLOR(mood);
  const dash = (mood / 100) * c;
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={6} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={band.color} strokeWidth={6}
          strokeLinecap="round" strokeDasharray={`${dash} ${c}`}
          style={{ transition: "stroke-dasharray .8s ease, stroke .6s" }} />
      </svg>
      <div className="absolute text-center">
        <div className="font-mono text-2xl font-bold neon-soft" style={{ color: band.color }}>{Math.round(mood)}</div>
        <div className="chip text-ink-dim">WORLD MOOD</div>
      </div>
    </div>
  );
}
