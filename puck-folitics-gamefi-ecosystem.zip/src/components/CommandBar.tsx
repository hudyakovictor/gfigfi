import { useGame } from "../lib/useGame";
import { SEASON_BY_ID } from "../lib/gameData";
import { MOOD_COLOR, Bar } from "./ui";
import { fmtUsd } from "../lib/format";
import { cn } from "../utils/cn";

export default function CommandBar() {
  const { node, resources, mood, seasonId, mode, setMode, liveConnected, block, foldPrice, loading } = useGame();
  const season = SEASON_BY_ID[seasonId];
  const mb = MOOD_COLOR(mood);
  const foldValue = resources.fold * foldPrice;

  return (
    <header className="relative z-30 glass-strong border-b border-line">
      <div className="flex items-center gap-3 px-3 sm:px-4 h-[58px]">
        {/* Logo */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="grid place-items-center w-9 h-9 clip-sm font-display font-bold text-[15px]"
            style={{ background: "linear-gradient(135deg,#00ff9c,#29e7ff)", color: "#06121a", boxShadow: "0 0 18px -4px #00ff9c" }}>
            PF
          </div>
          <div className="leading-none">
            <div className="font-display font-bold text-[15px] tracking-tight text-ink">
              PUCK <span className="title-glitch neon-soft" data-text="FOLITICS" style={{ color: "#ff2d95" }}>FOLITICS</span>
            </div>
            <div className="chip text-ink-dim mt-0.5 hidden sm:block">THE FOLD // OPERATOR CONSOLE</div>
          </div>
        </div>

        {/* Season + mood (md+) */}
        <div className="hidden md:flex items-center gap-2 ml-1">
          <div className="clip-sm flex items-center gap-1.5 px-2 py-1 border" style={{ borderColor: `${season.color}55`, background: `${season.color}14` }}>
            <span className="text-sm">{season.emoji}</span>
            <span className="chip" style={{ color: season.color }}>{season.name}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="chip text-ink-dim">MOOD</span>
            <div className="w-20"><Bar value={mood} color={mb.color} height={6} glow /></div>
            <span className="font-mono text-xs font-bold" style={{ color: mb.color }}>{Math.round(mood)}</span>
          </div>
        </div>

        <div className="flex-1" />

        {/* Block + sync */}
        <div className="hidden xl:flex flex-col items-end leading-none mr-1">
          <span className="chip text-ink-dim">BLOCK</span>
          <span className="font-mono text-xs text-ink">#{block.toLocaleString()}</span>
        </div>

        {/* Wallet cluster */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="hidden sm:flex flex-col items-end leading-tight">
            <span className="chip text-ink-dim">{node.rank}</span>
            <span className="font-mono text-[11px] text-toxic">⬢ {resources.influence.toFixed(0)} INF</span>
          </div>
          <div className="clip-sm flex flex-col items-end justify-center px-2.5 py-1 border border-toxic/30" style={{ background: "#00ff9c12" }}>
            <span className="chip text-toxic/80">$FOLD</span>
            <span className="font-mono text-[13px] font-bold text-toxic tnum">{fmtUsd(foldValue, 0)}</span>
          </div>
          <div className="hidden lg:flex flex-col w-16">
            <span className="chip text-ink-dim flex justify-between"><span>NRG</span><span className="text-amber">{Math.round(resources.energy)}</span></span>
            <Bar value={resources.energy} max={resources.maxEnergy} color="#ffb020" height={5} className="mt-1" />
          </div>
        </div>

        {/* Mode toggle */}
        <div className="flex items-center clip-sm border border-line bg-black/30 p-0.5">
          {(["live", "sim"] as const).map((m) => {
            const active = mode === m;
            const live = m === "live";
            const dotColor = live ? (liveConnected ? "#00ff9c" : "#ffb020") : "#9b6bff";
            return (
              <button key={m} onClick={() => setMode(m)}
                className={cn("px-2 py-1 chip flex items-center gap-1.5 transition-colors rounded-[3px]",
                  active ? "text-ink" : "text-ink-dim hover:text-ink")}
                style={active ? { background: `${dotColor}22` } : undefined}>
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: dotColor, boxShadow: `0 0 6px ${dotColor}` }} />
                {live ? (liveConnected ? "LIVE" : loading ? "LINK…" : "LIVE•") : "SIM"}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}
