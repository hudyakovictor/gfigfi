import { useGame } from "../lib/useGame";
import { TICKER_LINES } from "../lib/gameData";
import { fmtUsd, fmtPct } from "../lib/format";

export default function MarqueeTicker() {
  const { coins } = useGame();
  const items: string[] = [];
  coins.slice(0, 8).forEach((c) => {
    const arrow = (c.change24h ?? 0) >= 0 ? "▲" : "▼";
    items.push(`${c.emoji} ${c.symbol} ${fmtUsd(c.price)} ${arrow} ${fmtPct(c.change24h)}`);
  });
  const combined = [...TICKER_LINES, ...items];
  // duplicate for seamless loop
  const loop = [...combined, ...combined];

  return (
    <div className="relative z-20 overflow-hidden border-b border-line bg-black/40">
      <div className="marquee flex whitespace-nowrap py-1">
        {loop.map((t, i) => (
          <span key={i} className="chip mx-4 inline-flex items-center gap-1 text-ink-dim">
            <span className="text-toxic/70">◆</span> {t}
          </span>
        ))}
      </div>
    </div>
  );
}
