import { useState, type ReactNode } from "react";
import { ASSETS, RARITY_COLOR } from "../../lib/gameData";
import { Panel, Tag } from "../ui";
import { cn } from "../../utils/cn";
import type { Rarity } from "../../lib/types";

const RARITY_ORDER: Rarity[] = ["mythic", "legendary", "epic", "rare", "common"];

export default function VaultView() {
  const [filter, setFilter] = useState<Rarity | "all" | "token">("all");
  const total = ASSETS.reduce((s, a) => s + a.qty, 0);
  const tokCount = ASSETS.filter((a) => a.tokenized).length;
  const shown = ASSETS.filter((a) => filter === "all" ? true : filter === "token" ? a.tokenized : a.rarity === filter);

  return (
    <div className="space-y-3">
      {/* summary */}
      <Panel title="OPERATOR VAULT // FUNCTIONAL ASSETS" icon="🎒" accent="#ffb020"
        right={<span className="text-ink-dim">{ASSETS.length} distinct · {total} items</span>}>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
          <Mini label="TOTAL ITEMS" value={total.toString()} color="#ffb020" />
          <Mini label="TOKENIZED" value={`${tokCount}/${ASSETS.length}`} color="#00ff9c" />
          <Mini label="MYTHIC" value={ASSETS.filter((a) => a.rarity === "mythic").length.toString()} color="#ff2d95" />
          <Mini label="LEGENDARY" value={ASSETS.filter((a) => a.rarity === "legendary").length.toString()} color="#ffb020" />
        </div>
        <p className="text-[11px] text-ink-dim italic mb-3">
          ⟁ Not NFTs-for-NFTs'-sake. Each item has a <b className="text-toxic">function</b> — access, identity, rights, influence, or infra. Tokenization earns its place; it isn't the default.
        </p>
        {/* filters */}
        <div className="flex flex-wrap gap-1.5">
          <FilterChip active={filter === "all"} onClick={() => setFilter("all")} color="#d4dde6">ALL</FilterChip>
          <FilterChip active={filter === "token"} onClick={() => setFilter("token")} color="#00ff9c">⛓ ONCHAIN</FilterChip>
          {RARITY_ORDER.map((r) => (
            <FilterChip key={r} active={filter === r} onClick={() => setFilter(r)} color={RARITY_COLOR[r]}>{r.toUpperCase()}</FilterChip>
          ))}
        </div>
      </Panel>

      {/* grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
        {shown.map((a) => {
          const col = RARITY_COLOR[a.rarity];
          return (
            <div key={a.id} className="clip border p-3 transition-all hover:-translate-y-0.5 group" style={{ borderColor: `${col}55`, background: `linear-gradient(180deg, ${col}10, transparent 70%)` }}>
              <div className="flex items-start justify-between">
                <div className="grid place-items-center w-11 h-11 clip-sm border text-2xl" style={{ borderColor: `${col}66`, background: `${col}14`, boxShadow: `0 0 16px -6px ${col}` }}>{a.emoji}</div>
                <div className="text-right">
                  <Tag color={col}>{a.rarity}</Tag>
                  <div className="chip text-[8px] mt-1" style={{ color: a.tokenized ? "#00ff9c" : "#8a96a3" }}>{a.tokenized ? "⛓ ONCHAIN" : "◌ OFFCHAIN"}</div>
                </div>
              </div>
              <h4 className="font-display font-semibold text-[14px] text-ink mt-2 leading-tight">{a.name}</h4>
              <div className="chip text-[8px] text-ink-dim mt-0.5">{a.type}{a.qty > 1 && ` · ×${a.qty}`}</div>
              <p className="text-[11px] text-toxic/90 mt-1.5 leading-snug">⚙ {a.fn}</p>
              <p className="text-[11px] text-ink-dim italic mt-1.5 leading-snug">"{a.flavor}"</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Mini({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="clip-sm border border-line p-2">
      <div className="chip text-ink-dim">{label}</div>
      <div className="font-mono text-lg font-bold" style={{ color }}>{value}</div>
    </div>
  );
}

function FilterChip({ active, onClick, color, children }:
  { active: boolean; onClick: () => void; color: string; children: ReactNode }) {
  return (
    <button onClick={onClick}
      className={cn("chip px-2 py-1 rounded transition-all", active ? "" : "opacity-60 hover:opacity-100")}
      style={active ? { color: "#06121a", background: color } : { color, border: `1px solid ${color}44` }}>
      {children}
    </button>
  );
}
