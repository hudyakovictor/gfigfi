import { useState } from "react";
import { useGame, SPECIALIZATIONS, type ActionResult } from "../../lib/useGame";
import { SEASON_BY_ID, FACTION_BY_ID } from "../../lib/gameData";
import type { FactionId } from "../../lib/types";
import { Panel, Bar, GlowButton, Stat, MOOD_COLOR, MoodGauge, Tag } from "../ui";
import { cn } from "../../utils/cn";

const RES = [
  { key: "energy", label: "NODE ENERGY", icon: "⚡", color: "#ffb020" },
  { key: "materials", label: "MATERIALS", icon: "📦", color: "#29e7ff" },
  { key: "signal", label: "SIGNAL", icon: "📡", color: "#c6ff00" },
  { key: "security", label: "SECURITY", icon: "🛡️", color: "#00ff9c" },
  { key: "influence", label: "INFLUENCE", icon: "⬢", color: "#9b6bff" },
] as const;

export default function NodeView() {
  const g = useGame();
  const { resources, node, mood, seasonId, activeShock } = g;
  const season = SEASON_BY_ID[seasonId];
  const mb = MOOD_COLOR(mood);
  const [result, setResult] = useState<ActionResult | null>(null);

  const run = (fn: () => ActionResult) => {
    const r = fn();
    setResult(r);
  };

  const actions = [
    { label: "Scan Signals", icon: "🛰️", color: "#c6ff00", cost: "−6 NRG → +Signal", fn: () => g.scanSignals() },
    { label: "Arbitrage Edge", icon: "⚖️", color: "#00ff9c", cost: "−12 Signal → +$FOLD", fn: () => g.arbitrage() },
    { label: "Deploy Module", icon: "🏭", color: "#29e7ff", cost: "−24 Mat · −14 NRG", fn: () => g.deployModule() },
    { label: "Hedge Cataclysm", icon: "🛡️", color: "#ffb020", cost: "−200 $FOLD → +Sec", fn: () => g.hedgeCataclysm() },
    { label: "Crystallize Rank", icon: "💎", color: "#9b6bff", cost: "−60 Influence", fn: () => g.lockInfluence() },
  ];

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">
      {/* NODE IDENTITY */}
      <Panel title="OPERATOR NODE" icon="🛰️" accent="#00ff9c" className="xl:col-span-2"
        right={<Tag color="#00ff9c">TIER {node.tier} · ONLINE</Tag>}>
        <div className="flex flex-wrap items-start gap-4">
          <div className="min-w-0 flex-1">
            <h2 className="font-display font-bold text-xl text-ink leading-tight">{node.name}</h2>
            <div className="text-ink-dim text-sm mt-0.5">{node.type} · {SPECIALIZATIONS.find((s) => s.id === node.specialization)?.name}</div>
            <div className="mt-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-mono font-bold" style={{ color: "#9b6bff" }}>{node.rank}</span>
                <span className="chip text-ink-dim">{node.rankProgress.toFixed(0)}% TO NEXT RANK</span>
              </div>
              <Bar value={node.rankProgress} color="#9b6bff" height={8} className="mt-1" glow />
            </div>
            <div className="grid grid-cols-3 gap-3 mt-4">
              <Stat label="$FOLD" value={Math.round(resources.fold).toLocaleString()} sub={`@ $${g.foldPrice.toFixed(3)}`} color="#00ff9c" />
              <Stat label="INFLUENCE" value={resources.influence.toFixed(0)} sub="spendable" color="#9b6bff" />
              <Stat label="NODE VALUE" value={"$" + Math.round(resources.fold * g.foldPrice + resources.materials * 12).toLocaleString()} sub="est. portfolio" color="#29e7ff" />
            </div>
          </div>
        </div>
      </Panel>

      {/* WORLD PULSE */}
      <Panel title="WORLD PULSE" icon="🌐" accent={mb.color}>
        <div className="flex items-center gap-3">
          <MoodGauge mood={mood} size={96} />
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-base">{season.emoji}</span>
              <span className="chip" style={{ color: season.color }}>{season.name}</span>
            </div>
            <p className="text-[11px] text-ink-dim mt-1 leading-snug">{season.tagline}</p>
            {activeShock ? (
              <div className="mt-2 clip-sm border px-2 py-1" style={{ borderColor: "#ff2d9544", background: "#ff2d950d" }}>
                <span className="chip" style={{ color: "#ff2d95" }}>{activeShock.emoji} {activeShock.name}</span>
              </div>
            ) : (
              <div className="mt-2 chip text-ink-dim">🌫️ NO ACTIVE SHOCK</div>
            )}
          </div>
        </div>
      </Panel>

      {/* CORE LOOP */}
      <Panel title="CORE LOOP // OPERATE" icon="▶" accent="#00ff9c" className="xl:col-span-2"
        right={<span className="hidden sm:inline">collect → decide → rebuild → deal → survive → lock</span>}>
        {result && (
          <div className={cn("mb-3 clip-sm border px-3 py-2 text-[12px] font-mono rise-in",
            result.ok ? "border-toxic/40 bg-toxic/8 text-toxic" : "border-amber/40 bg-amber/8 text-amber")}>
            {result.ok ? "✓ " : "✕ "}{result.msg}
          </div>
        )}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
          {actions.map((a) => (
            <GlowButton key={a.label} color={a.color} onClick={() => run(a.fn)} className="flex-col items-start gap-1 w-full">
              <span className="text-lg">{a.icon}</span>
              <span className="text-[12px] leading-tight">{a.label}</span>
              <span className="chip text-[8px] opacity-70" style={{ color: "#06121a" }}>{a.cost}</span>
            </GlowButton>
          ))}
        </div>
        <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2">
          <div className="chip text-ink-dim col-span-2 sm:col-span-1 self-center">FORGE ALLIANCE ·25 INF</div>
          {(Object.keys(FACTION_BY_ID) as FactionId[]).map((fid) => {
            const f = FACTION_BY_ID[fid];
            return (
              <button key={fid} onClick={() => run(() => g.forgeAlliance(fid))}
                className="clip-sm border px-2 py-1.5 text-left hover:-translate-y-0.5 transition-transform"
                style={{ borderColor: `${f.color}44`, background: `${f.color}0d` }}>
                <div className="flex items-center gap-1.5">
                  <span>{f.emoji}</span>
                  <span className="chip" style={{ color: f.color }}>{f.name}</span>
                </div>
                <div className="flex items-center gap-1.5 mt-1">
                  <Bar value={g.factionRep[fid]} color={f.color} height={4} className="flex-1" />
                  <span className="font-mono text-[10px]" style={{ color: f.color }}>{g.factionRep[fid].toFixed(0)}</span>
                </div>
              </button>
            );
          })}
        </div>
      </Panel>

      {/* RESOURCES */}
      <Panel title="NODE RESOURCES" icon="📊" accent="#ffb020">
        <div className="space-y-3">
          {RES.map((r) => {
            const val = resources[r.key as keyof typeof resources];
            const isEnergy = r.key === "energy";
            const max = isEnergy ? resources.maxEnergy : Math.max(100, Math.ceil(val / 50) * 50);
            return (
              <div key={r.key}>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="flex items-center gap-1.5 text-ink-dim">{r.icon}<span className="chip">{r.label}</span></span>
                  <span className="font-mono font-semibold" style={{ color: r.color }}>{Math.round(val)}{isEnergy && <span className="text-ink-dim">/{resources.maxEnergy}</span>}</span>
                </div>
                <Bar value={val} max={max} color={r.color} height={7} glow />
              </div>
            );
          })}
          <div className="pt-2 border-t border-line/60">
            <Stat label="$FOLD TREASURY" value={"$" + Math.round(resources.fold * g.foldPrice).toLocaleString()} sub={`${Math.round(resources.fold)} $FOLD held`} color="#00ff9c" />
          </div>
        </div>
      </Panel>

      {/* SPECIALIZATION */}
      <Panel title="SPECIALIZATION PATH" icon="🧭" accent="#29e7ff" className="xl:col-span-3"
        right={<span className="text-ink-dim">respec freely — adapt to the season</span>}>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
          {SPECIALIZATIONS.map((s) => {
            const active = node.specialization === s.id;
            return (
              <button key={s.id} onClick={() => g.setSpecialization(s.id)}
                className={cn("clip-sm border p-2.5 text-left transition-all hover:-translate-y-0.5",
                  active ? "border-toxic/60 bg-toxic/8" : "border-line bg-white/3")}>
                <div className="flex items-center gap-2">
                  <span className="text-lg">{s.icon}</span>
                  <span className={cn("font-display font-semibold text-[13px]", active ? "text-toxic" : "text-ink")}>{s.name}</span>
                  {active && <span className="ml-auto chip text-[7px] text-toxic">● ACTIVE</span>}
                </div>
                <p className="text-[11px] text-ink-dim mt-1.5 leading-snug">{s.desc}</p>
              </button>
            );
          })}
        </div>
        <p className="text-[11px] text-ink-dim mt-3 italic">
          ⟁ The Fold rewards adaptation. {season.emoji} In <b style={{ color: season.color }}>{season.name}</b>, {seasonAdvice(seasonId)}.
        </p>
      </Panel>
    </div>
  );
}

function seasonAdvice(id: string): string {
  switch (id) {
    case "bull": return "Speculators feast — ride memes & velocity, but don't over-leverage into the euphoria";
    case "bear": return "Builders & Archivists shine — stack infrastructure, reputation and yield, dump the tourists";
    case "rotation": return "Capital migrates overnight — keep logistics flexible and watch the dead regions reawaken";
    case "crackdown": return "Security & alliances win — hoard transparency, insurance and trustworthy partners";
    default: return "stay adaptive";
  }
}
