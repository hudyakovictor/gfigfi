import { useState } from "react";
import { useGame } from "../../lib/useGame";
import { FACTIONS } from "../../lib/gameData";
import { Panel, Bar, Tag } from "../ui";
import type { FactionId } from "../../lib/types";

const DYNAMICS = [
  { a: "Builders", b: "Raiders", t: "Builders forge it. Raiders probe it. A perpetual cold war of patches vs exploits.", color: "#ff2d95" },
  { a: "Speculators", b: "Archivists", t: "Speculators chase the next thing. Archivists remember the last time it ended badly. They argue forever.", color: "#ffb020" },
  { a: "Builders", b: "Speculators", t: "Builders need capital. Speculators need something to pump. Mutually useful, mutually suspicious.", color: "#00ff9c" },
  { a: "Raiders", b: "Archivists", t: "Raiders find the hole. Archivists document who fell through it. Frenemies of the highest order.", color: "#29e7ff" },
];

export default function FactionsView() {
  const { factionRep, forgeAlliance } = useGame();
  const [msg, setMsg] = useState("");

  const ally = (id: FactionId) => {
    const r = forgeAlliance(id);
    setMsg(r.msg);
    setTimeout(() => setMsg(""), 2600);
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {FACTIONS.map((f) => (
          <Panel key={f.id} title={`${f.emoji}  ${f.name.toUpperCase()}`} accent={f.color}
            right={<Tag color={f.color}>{f.playstyle.split(" · ")[0]}</Tag>}>
            <p className="text-[12px] italic text-ink-dim mb-2">"{f.motto}"</p>
            <p className="text-[12px] text-ink/90 leading-relaxed">{f.blurb}</p>

            <div className="mt-3">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="chip text-ink-dim">YOUR STANDING</span>
                <span className="font-mono font-bold" style={{ color: f.color }}>{factionRep[f.id].toFixed(0)}<span className="text-ink-dim">/100</span></span>
              </div>
              <Bar value={factionRep[f.id]} color={f.color} height={9} glow />
              <div className="chip text-[9px] mt-1" style={{ color: standingLabel(factionRep[f.id]).color }}>{standingLabel(factionRep[f.id]).text}</div>
            </div>

            <div className="mt-3 flex gap-2">
              <button onClick={() => ally(f.id)}
                className="flex-1 clip-sm py-2 font-display text-[12px] font-semibold transition-transform hover:-translate-y-0.5"
                style={{ background: `linear-gradient(180deg,${f.color},${f.color}cc)`, color: "#06121a", boxShadow: `0 0 16px -6px ${f.color}` }}>
                🤝 FORGE ALLIANCE ·25 INF
              </button>
            </div>
          </Panel>
        ))}
      </div>

      {msg && (
        <div className="clip-sm border border-toxic/40 bg-toxic/8 px-3 py-2 text-[12px] font-mono text-toxic rise-in">✓ {msg}</div>
      )}

      {/* DYNAMICS */}
      <Panel title="FACTION DYNAMICS // THE ENGINE OF GENRES" icon="⚛️" accent="#9b6bff">
        <p className="text-[12px] text-ink-dim mb-3">
          Four forces in tension = a natural skeleton for <b className="text-ink">strategy, economic sim, MMO-lite, social diplomacy &amp; PvPvE</b> all sharing one core. Pick a side, play many ways.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {DYNAMICS.map((d) => (
            <div key={d.a + d.b} className="clip-sm border border-line p-2.5 flex items-start gap-2.5">
              <div className="flex flex-col items-center gap-0.5 shrink-0">
                <span className="chip text-[9px]" style={{ color: d.color }}>{d.a}</span>
                <span className="text-ink-dim text-xs">↔</span>
                <span className="chip text-[9px]" style={{ color: d.color }}>{d.b}</span>
              </div>
              <p className="text-[11px] text-ink/85 leading-snug pt-0.5">{d.t}</p>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

function standingLabel(v: number): { text: string; color: string } {
  if (v >= 80) return { text: "● TRUSTED ALLY", color: "#00ff9c" };
  if (v >= 60) return { text: "● ON GOOD TERMS", color: "#c6ff00" };
  if (v >= 40) return { text: "○ NEUTRAL / TOLERATED", color: "#8a96a3" };
  if (v >= 20) return { text: "○ DISTRUSTED", color: "#ffb020" };
  return { text: "○ MARKED", color: "#ff4d4d" };
}
