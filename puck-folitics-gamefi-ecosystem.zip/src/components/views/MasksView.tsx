import { useState } from "react";
import { MASKS } from "../../lib/gameData";
import { Panel, Tag } from "../ui";

export default function MasksView() {
  const [accepted, setAccepted] = useState<Record<string, boolean>>({});

  return (
    <div className="space-y-3">
      <Panel title="MASKS OF THE FOLD // ARCHETYPES" icon="🎭" accent="#9b6bff"
        right={<span className="text-ink-dim">{MASKS.length} figures</span>}>
        <p className="text-[12px] text-ink-dim italic">
          ⟁ Recognizable industry archetypes — <b className="text-ink">not copies, not real IP</b>. A gold-skyscraper mogul,
          a rocket-fixated jester, a mirror-palace illusionist... the industry reads the nod instantly; the lawyers find nothing to sue.
          Total coincidence. Definitely.
        </p>
      </Panel>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-2.5">
        {MASKS.map((m) => (
          <div key={m.id} className="clip border p-3 transition-all hover:-translate-y-0.5" style={{ borderColor: `${m.color}44`, background: `linear-gradient(135deg, ${m.color}0e, transparent 70%)` }}>
            <div className="flex items-start gap-3">
              <div className="grid place-items-center w-14 h-14 clip-sm border shrink-0 text-3xl"
                style={{ borderColor: `${m.color}66`, background: `${m.color}14`, boxShadow: `0 0 18px -6px ${m.color}` }}>
                {m.emoji}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="font-display font-bold text-[15px]" style={{ color: m.color }}>{m.name}</h4>
                  <Tag color={m.color}>{m.ref}</Tag>
                </div>
                <div className="chip text-[8px] text-ink-dim mt-0.5">{m.title}</div>
                <p className="text-[12px] text-ink/90 mt-1.5 leading-snug">{m.blurb}</p>
              </div>
            </div>

            <div className="mt-2.5 clip-sm border-l-2 pl-2.5 py-1.5" style={{ borderColor: m.color }}>
              <span className="text-[12px] italic text-ink-dim">"{m.quote}"</span>
            </div>

            <div className="mt-2.5 flex items-center gap-2">
              <span className="text-[11px] text-ink/85 flex-1"><b className="chip" style={{ color: m.color }}>QUEST:</b> {m.quest}</span>
              <button onClick={() => setAccepted((p) => ({ ...p, [m.id]: !p[m.id] }))}
                className="shrink-0 clip-sm px-3 py-1.5 font-display text-[11px] font-semibold transition-transform hover:-translate-y-0.5"
                style={accepted[m.id]
                  ? { background: "rgba(0,255,156,0.12)", color: "#00ff9c", border: "1px solid #00ff9c55" }
                  : { background: `linear-gradient(180deg,${m.color},${m.color}cc)`, color: "#06121a", boxShadow: `0 0 14px -6px ${m.color}` }}>
                {accepted[m.id] ? "✓ TRACKING" : "▶ ACCEPT"}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
