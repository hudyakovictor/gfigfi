import { useGame } from "../../lib/useGame";
import { Panel, Sparkline, DeltaPill, Bar, Tag, MOOD_COLOR } from "../ui";
import { fmtUsd, fmtCompact } from "../../lib/format";
import type { Coin } from "../../lib/types";

const CAT_COLOR: Record<string, string> = {
  blue: "#f7931a", l1: "#8a92ff", defi: "#2a5ada", meme: "#00ff9c", stable: "#26a17b", ai: "#ff2d95",
};

const SINKS = [
  "Infrastructure build & upkeep",
  "Guild insurance & risk pools",
  "Seasonal expedition entry",
  "Governance staking → councils",
  "Creator publishing bonds",
  "Post-raid repair fees",
  "Launch a public world event",
];

const FAUCETS = [
  "Capped daily ops reward (no infinite farm)",
  "Season rewards (soft-reset between seasons)",
  "Early players are NOT permanent winners",
];

const CATEGORY_LABEL: Record<string, string> = {
  blue: "BLUE", l1: "L1", defi: "DEFI", meme: "MEME", stable: "STABLE", ai: "AI",
};

export default function MarketsView() {
  const { coins, foldPrice, mood } = useGame();
  const foldChange = (mood - 50) * 0.9; // $FOLD tracks world mood
  const mb = MOOD_COLOR(mood);

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">
      {/* $FOLD TOKENOMICS */}
      <Panel title="$FOLD // SERVICE TOKEN" icon="🪙" accent="#00ff9c" className="xl:col-span-1"
        right={<Tag color="#00ff9c">SINKS &gt; HYPE</Tag>}>
        <div className="flex items-end justify-between">
          <div>
            <div className="chip text-ink-dim">PRICE</div>
            <div className="font-mono text-2xl font-bold text-toxic neon-soft">{fmtUsd(foldPrice, 3)}</div>
          </div>
          <DeltaPill value={foldChange} />
        </div>
        <div className="mt-2"><Sparkline data={coins[0].sparkline} color="#00ff9c" width={120} height={40} fluid /></div>
        <p className="text-[11px] text-ink-dim mt-1">$FOLD tracks World Mood ({Math.round(mood)} · {mb.label}). It is a service layer, not a salary. The game is the product; the token is plumbing.</p>

        <div className="grid grid-cols-2 gap-2 mt-3">
          <div className="clip-sm border border-line p-2"><div className="chip text-ink-dim">MAX SUPPLY</div><div className="font-mono text-sm text-ink">1,000,000,000</div></div>
          <div className="clip-sm border border-line p-2"><div className="chip text-ink-dim">CIRCULATING</div><div className="font-mono text-sm text-ink">420,000,000</div></div>
        </div>

        <div className="mt-3">
          <div className="chip text-danger mb-1.5">🩶 SINKS (where tokens die honorably)</div>
          <ul className="space-y-1">
            {SINKS.map((s) => <li key={s} className="text-[11px] text-ink/85 flex gap-1.5"><span className="text-danger">▸</span>{s}</li>)}
          </ul>
        </div>
        <div className="mt-3">
          <div className="chip text-amber mb-1.5">🚰 FAUCETS (deliberately throttled)</div>
          <ul className="space-y-1">
            {FAUCETS.map((s) => <li key={s} className="text-[11px] text-ink/85 flex gap-1.5"><span className="text-amber">▸</span>{s}</li>)}
          </ul>
        </div>
      </Panel>

      {/* COIN BASKET */}
      <Panel title="THE BASKET // LIVE FOLD MARKETS" icon="📈" accent="#29e7ff" className="xl:col-span-2"
        right={<span className="text-ink-dim">real prices · satirical names</span>}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {coins.map((c) => <CoinCard key={c.id} c={c} />)}
        </div>
        <p className="text-[11px] text-ink-dim mt-3 italic">
          ⟁ All names are archetypes, not copies. The real refs stay deniable. We learned the lesson about IP — and about the rugs.
        </p>
      </Panel>

      {/* TWO-CIRCUIT ECONOMY */}
      <Panel title="DUAL-CIRCUIT ECONOMY" icon="🔁" accent="#9b6bff" className="xl:col-span-3">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="clip-sm border border-line p-3" style={{ background: "#29e7ff08" }}>
            <div className="flex items-center gap-2"><Tag color="#29e7ff">CIRCUIT 1</Tag><span className="font-display font-semibold text-ink">Operational Economy</span></div>
            <p className="text-[12px] text-ink-dim mt-2">Off-chain / semi-onchain. Daily play: node energy, materials, blueprints, district influence, contract services, season certs, temp items. Low friction, mass-market friendly.</p>
            <div className="flex flex-wrap gap-1.5 mt-2">
              {["Energy", "Materials", "Blueprints", "Influence", "Contract Svc", "Season Certs"].map((x) => <Tag key={x} color="#29e7ff">{x}</Tag>)}
            </div>
          </div>
          <div className="clip-sm border border-line p-3" style={{ background: "#9b6bff08" }}>
            <div className="flex items-center gap-2"><Tag color="#9b6bff">CIRCUIT 2</Tag><span className="font-display font-semibold text-ink">Ownership & Coordination</span></div>
            <p className="text-[12px] text-ink-dim mt-2">Onchain. The scarce stuff: territorial licenses, creator royalties, governance keys, rare identity assets, guild debt/insurance, infra shares. Real stakes, real rights.</p>
            <div className="flex flex-wrap gap-1.5 mt-2">
              {["Land Licenses", "Royalties", "Gov Keys", "Identity", "Guild Debt", "Infra Shares"].map((x) => <Tag key={x} color="#9b6bff">{x}</Tag>)}
            </div>
          </div>
        </div>
        <div className="mt-3 flex items-center gap-3">
          <span className="chip text-ink-dim shrink-0">INFLATION CONTROL</span>
          <Bar value={68} color="#00ff9c" height={7} glow />
          <span className="chip text-toxic">SINKS OUTRUN FAUCETS</span>
        </div>
      </Panel>
    </div>
  );
}

function CoinCard({ c }: { c: Coin }) {
  const up = (c.change24h ?? 0) >= 0;
  const col = up ? "#00ff9c" : "#ff4d4d";
  return (
    <div className="clip-sm border p-2.5 transition-colors hover:bg-white/4" style={{ borderColor: `${CAT_COLOR[c.category]}33` }}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="text-base">{c.emoji}</span>
            <span className="font-mono font-bold text-sm text-ink">{c.symbol}</span>
            <span className="chip text-[8px]" style={{ color: CAT_COLOR[c.category] }}>{CATEGORY_LABEL[c.category]}</span>
          </div>
          <div className="text-[11px] text-ink-dim truncate">{c.foldName}</div>
        </div>
        <div className="text-right shrink-0">
          <div className="font-mono text-sm font-semibold text-ink">{fmtUsd(c.price)}</div>
          <DeltaPill value={c.change24h ?? 0} />
        </div>
      </div>
      <div className="mt-1.5"><Sparkline data={c.sparkline} color={col} width={300} height={30} /></div>
      <div className="flex items-center justify-between mt-1">
        <span className="text-[10px] text-ink-dim italic truncate pr-2">{c.tagline}</span>
        {c.marketCap && <span className="chip text-ink-dim shrink-0">MC {fmtCompact(c.marketCap)}</span>}
      </div>
    </div>
  );
}
