import { useState } from "react";
import { useGame } from "../../lib/useGame";
import { REGIONS, FACTION_BY_ID, REGION_BY_ID } from "../../lib/gameData";
import { Panel, Tag } from "../ui";
import { cn } from "../../utils/cn";

// which regions a given world shock disrupts
const SHOCK_REGIONS: Record<string, string[]> = {
  "exchange-freeze": ["citadel"],
  "stable-fracture": ["vaultstep", "citadel"],
  "bridge-breach": ["bridges"],
  "meme-fever": ["reef", "citadel"],
  "jpeg-mania": ["reef"],
  "whale-awakening": ["citadel"],
  "presidential-statement": ["forum"],
  "influencer-trial": ["forum"],
  "airdrop-exodus": ["bridges", "fault"],
  "mining-ban": ["fault"],
  "fork-dispute": ["fault"],
  "protocol-resurrection": ["ashen"],
};

export default function FoldView() {
  const { activeShock } = useGame();
  const [sel, setSel] = useState<string>("bridges");
  const region = REGION_BY_ID[sel];
  const hot = activeShock ? SHOCK_REGIONS[activeShock.id] ?? [] : [];
  const hub = REGION_BY_ID["bridges"];

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">
      {/* MAP */}
      <Panel title="THE FOLD // WORLD MAP" icon="🗺️" accent="#29e7ff" className="xl:col-span-2"
        right={<span className="text-ink-dim">{activeShock ? <span style={{ color: "#ff2d95" }}>● {activeShock.name} live</span> : "all channels nominal"}</span>}>
        <div className="relative w-full dotgrid clip-sm border border-line overflow-hidden" style={{ aspectRatio: "16 / 9.5", background: "radial-gradient(60% 80% at 50% 40%, rgba(43,231,255,0.06), transparent)" }}>
          {/* connectors from hub */}
          <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
            {REGIONS.filter((r) => r.id !== "bridges").map((r) => (
              <line key={r.id} x1={`${hub.x}%`} y1={`${hub.y}%`} x2={`${r.x}%`} y2={`${r.y}%`}
                stroke={hot.includes(r.id) ? "#ff2d95" : "rgba(255,255,255,0.12)"}
                strokeWidth={hot.includes(r.id) ? 1.6 : 1}
                strokeDasharray="3 4" />
            ))}
          </svg>

          {/* region markers */}
          {REGIONS.map((r) => {
            const f = FACTION_BY_ID[r.faction];
            const isHot = hot.includes(r.id);
            const isSel = sel === r.id;
            return (
              <button key={r.id} onClick={() => setSel(r.id)}
                className="absolute -translate-x-1/2 -translate-y-1/2 group"
                style={{ left: `${r.x}%`, top: `${r.y}%` }}>
                {/* pulse ring if hot */}
                {isHot && <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full pulse-danger" style={{ boxShadow: "0 0 0 2px #ff2d95" }} />}
                <div className={cn("relative grid place-items-center w-9 h-9 clip-sm border transition-all",
                  isSel ? "scale-110" : "group-hover:scale-110")}
                  style={{ borderColor: r.color, background: `${r.color}1a`, boxShadow: `0 0 16px -4px ${r.color}` }}>
                  <span className="text-base">{r.emoji}</span>
                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full" style={{ background: f.color }} />
                </div>
                <div className="absolute left-1/2 -translate-x-1/2 mt-1 whitespace-nowrap">
                  <span className={cn("chip text-[8px] px-1 rounded", isSel ? "text-ink" : "text-ink-dim")} style={{ background: "rgba(0,0,0,0.5)" }}>{r.name}</span>
                </div>
              </button>
            );
          })}

          {/* legend */}
          <div className="absolute bottom-2 left-2 flex flex-wrap gap-1.5">
            {Object.values(FACTION_BY_ID).map((f) => (
              <span key={f.id} className="chip text-[8px] flex items-center gap-1 px-1.5 py-0.5 rounded" style={{ background: "rgba(0,0,0,0.45)", color: f.color }}>
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: f.color }} />{f.name}
              </span>
            ))}
          </div>
          {activeShock && hot.length > 0 && (
            <div className="absolute top-2 right-2 clip-sm border px-2 py-1 text-right" style={{ borderColor: "#ff2d9544", background: "rgba(0,0,0,0.5)" }}>
              <div className="chip" style={{ color: "#ff2d95" }}>{activeShock.emoji} {activeShock.name}</div>
              <div className="text-[10px] text-ink-dim">disrupting {hot.length} region{hot.length > 1 ? "s" : ""}</div>
            </div>
          )}
        </div>

        {/* region strip */}
        <div className="flex gap-1.5 mt-3 overflow-x-auto no-scrollbar pb-1">
          {REGIONS.map((r) => (
            <button key={r.id} onClick={() => setSel(r.id)}
              className={cn("shrink-0 clip-sm border px-2 py-1 text-left transition-colors", sel === r.id ? "" : "border-line opacity-70 hover:opacity-100")}
              style={sel === r.id ? { borderColor: r.color, background: `${r.color}12` } : undefined}>
              <span className="chip text-[8px]" style={{ color: r.color }}>{r.emoji} {r.name.split(" ")[0].toUpperCase()}</span>
            </button>
          ))}
        </div>
      </Panel>

      {/* REGION DETAIL */}
      <Panel title="REGION DOSSIER" icon="📂" accent={region.color}>
        <div className="flex items-center gap-3">
          <div className="grid place-items-center w-12 h-12 clip-sm border text-2xl" style={{ borderColor: region.color, background: `${region.color}1a` }}>{region.emoji}</div>
          <div className="min-w-0">
            <h3 className="font-display font-bold text-lg leading-tight" style={{ color: region.color }}>{region.name}</h3>
            <p className="text-[12px] text-ink-dim italic">"{region.tagline}"</p>
          </div>
        </div>
        <p className="text-[12px] text-ink/90 mt-3 leading-relaxed">{region.desc}</p>

        <div className="mt-3 flex items-center gap-2">
          <span className="chip text-ink-dim">FACTION LEAN</span>
          <Tag color={FACTION_BY_ID[region.faction].color}>{FACTION_BY_ID[region.faction].emoji} {FACTION_BY_ID[region.faction].name}</Tag>
        </div>

        <div className="mt-3">
          <div className="chip text-toxic mb-1.5">⚒ CRAFTS / OUTPUT</div>
          <div className="flex flex-wrap gap-1.5">
            {region.crafts.map((c) => <Tag key={c} color="#00ff9c">{c}</Tag>)}
          </div>
        </div>
        <div className="mt-3">
          <div className="chip text-danger mb-1.5">⚠ THREATS</div>
          <div className="flex flex-wrap gap-1.5">
            {region.threats.map((t) => <Tag key={t} color="#ff4d4d">{t}</Tag>)}
          </div>
        </div>

        {hot.includes(region.id) && activeShock && (
          <div className="mt-3 clip-sm border p-2" style={{ borderColor: "#ff2d9544", background: "#ff2d950d" }}>
            <div className="chip" style={{ color: "#ff2d95" }}>{activeShock.emoji} {activeShock.name} ACTIVE HERE</div>
            <p className="text-[11px] text-ink-dim mt-1">{activeShock.systemic}</p>
          </div>
        )}

        <div className="mt-4 flex gap-2">
          <button className="flex-1 clip-sm py-2 font-display text-[12px] font-semibold transition-transform hover:-translate-y-0.5"
            style={{ background: "linear-gradient(180deg,#00ff9c,#00ff9ccc)", color: "#06121a", boxShadow: "0 0 18px -6px #00ff9c" }}>
            ⚡ DEPLOY NODE HERE
          </button>
          <button className="clip-sm px-3 py-2 font-display text-[12px] border border-line text-ink hover:bg-white/5">
            🧭 SCOUT
          </button>
        </div>
      </Panel>
    </div>
  );
}
