import { useState } from "react";
import { useGame } from "../../lib/useGame";
import { SHOCKS } from "../../lib/gameData";
import { Panel, TONE, Tag } from "../ui";
import { timeAgo } from "../../lib/format";
import { cn } from "../../utils/cn";

const SEV_COLOR: Record<string, string> = { minor: "#29e7ff", major: "#ffb020", apocalyptic: "#ff2d95" };

export default function IntelView() {
  const { transmissions, activeShock } = useGame();
  const [open, setOpen] = useState<string | null>(activeShock?.id ?? "exchange-freeze");

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
      {/* INTEL FEED */}
      <Panel title="INTEL FEED // WORLD TRANSMISSIONS" icon="📡" accent="#c6ff00"
        right={<span className="text-ink-dim">{transmissions.length} signals</span>}>
        <p className="text-[11px] text-ink-dim mb-3 italic">
          ⟁ This feed blends <b className="text-toxic">real market moves</b> with Fold satire. When BTC dumps or a meme moons,
          the world rewrites itself. Scroll the past. Watch it repeat. It rhymes.
        </p>
        {activeShock && (
          <div className="mb-3 clip border p-2.5 rise-in" style={{ borderColor: `${SEV_COLOR[activeShock.severity]}66`, background: `${SEV_COLOR[activeShock.severity]}10` }}>
            <div className="flex items-center gap-2">
              <span className="text-lg">{activeShock.emoji}</span>
              <span className="chip blink" style={{ color: SEV_COLOR[activeShock.severity] }}>● BREAKING · {activeShock.name.toUpperCase()}</span>
            </div>
            <p className="text-[12px] text-ink mt-1">{activeShock.atmospheric}</p>
          </div>
        )}
        <div className="space-y-2 max-h-[640px] overflow-y-auto scroll-thin pr-1">
          {transmissions.map((t) => {
            const tone = TONE[t.tone];
            return (
              <div key={t.id} className="ticker-drop flex gap-2 text-[12px] leading-snug border-b border-line/40 pb-2">
                <span className="w-1 shrink-0 rounded-full self-stretch" style={{ background: tone.color }} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="chip" style={{ color: tone.color }}>{t.source}</span>
                    <span className="text-[10px] text-ink-dim">{timeAgo(t.ts)} ago</span>
                  </div>
                  <p className="text-ink/90 mt-0.5">{t.text}</p>
                </div>
              </div>
            );
          })}
        </div>
      </Panel>

      {/* SHOCK LIBRARY */}
      <Panel title="SCRIPTED WORLD SHOCKS // LIBRARY" icon="⛈️" accent="#ff2d95"
        right={<span className="text-ink-dim">{SHOCKS.length} scenarios</span>}>
        <p className="text-[11px] text-ink-dim mb-3 italic">
          Pre-coded events with probabilistic windows &amp; three impact tiers. Felt as huge — but they only tune a bounded set of params, never nuke your whole stash. LiveOps that respects your time.
        </p>
        <div className="space-y-1.5 max-h-[680px] overflow-y-auto scroll-thin pr-1">
          {SHOCKS.map((s) => {
            const isOpen = open === s.id;
            const isActive = activeShock?.id === s.id;
            const col = SEV_COLOR[s.severity];
            return (
              <div key={s.id} className={cn("clip border transition-colors", isOpen ? "" : "border-line")}
                style={isOpen ? { borderColor: `${col}66`, background: `${col}08` } : undefined}>
                <button onClick={() => setOpen(isOpen ? null : s.id)} className="w-full flex items-center gap-2 px-2.5 py-2 text-left">
                  <span className="text-lg">{s.emoji}</span>
                  <span className="font-display font-semibold text-[13px]" style={{ color: col }}>{s.name}</span>
                  {isActive && <span className="chip text-[7px] blink px-1 rounded" style={{ color: "#00ff9c", background: "#00ff9c1a" }}>LIVE</span>}
                  <Tag color={col}>{s.severity}</Tag>
                  <span className="ml-auto chip text-ink-dim">{isOpen ? "▲" : "▼"}</span>
                </button>
                {isOpen && (
                  <div className="px-2.5 pb-2.5 rise-in">
                    <p className="text-[12px] text-ink-dim italic mb-2">"{s.tagline}" · lasts {s.duration}</p>
                    <div className="space-y-1.5 text-[11px]">
                      <ImpactRow label="ATMOSPHERIC" color="#9b6bff" text={s.atmospheric} />
                      <ImpactRow label="SYSTEMIC" color="#ffb020" text={s.systemic} />
                      <ImpactRow label="SOCIAL" color="#29e7ff" text={s.social} />
                    </div>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {s.effects.map((e) => (
                        <span key={e.label} className="chip text-[8px] px-1.5 py-0.5 rounded" style={{ color: "#d4dde6", background: "rgba(255,255,255,0.06)" }}>
                          {e.label} <b style={{ color: e.delta.startsWith("-") ? "#ff4d4d" : "#00ff9c" }}>{e.delta}</b>
                        </span>
                      ))}
                    </div>
                    <div className="mt-2 chip text-ink-dim">triggers: {s.triggers.join(" · ")}</div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </Panel>
    </div>
  );
}

function ImpactRow({ label, color, text }: { label: string; color: string; text: string }) {
  return (
    <div className="flex gap-2">
      <span className="chip shrink-0 w-[72px]" style={{ color }}>{label}</span>
      <span className="text-ink/85">{text}</span>
    </div>
  );
}
