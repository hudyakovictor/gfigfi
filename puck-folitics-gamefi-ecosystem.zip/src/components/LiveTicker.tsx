import { useGame } from "../lib/useGame";
import { TONE, MoodGauge, MOOD_COLOR, Bar, Sparkline } from "./ui";
import { fmtUsd, fmtPct, timeAgo } from "../lib/format";
import { cn } from "../utils/cn";

const SEV_COLOR: Record<string, string> = {
  minor: "#29e7ff", major: "#ffb020", apocalyptic: "#ff2d95",
};

export default function LiveTicker() {
  const { coins, activeShock, shockRemaining, transmissions, mood, fng, mode, liveConnected, loading } = useGame();
  const mb = MOOD_COLOR(mood);
  const movers = [...coins].sort((a, b) => Math.abs(b.change24h ?? 0) - Math.abs(a.change24h ?? 0)).slice(0, 5);

  return (
    <aside className="hidden lg:flex w-[320px] shrink-0 glass-strong border-l border-line flex-col">
      {/* status */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-line">
        <span className="chip text-ink">⚡ LIVE WORLD FEED</span>
        <span className="chip flex items-center gap-1.5"
          style={{ color: mode === "live" ? (liveConnected ? "#00ff9c" : "#ffb020") : "#9b6bff" }}>
          <span className="w-1.5 h-1.5 rounded-full pulse-dot" style={{ background: "currentColor" }} />
          {mode === "live" ? (liveConnected ? "LIVE MKT" : loading ? "LINKING" : "SIM FALLBACK") : "SIMULATION"}
        </span>
      </div>

      <div className="flex-1 overflow-y-auto scroll-thin">
        {/* Active shock */}
        <div className="p-3 border-b border-line">
          {activeShock ? (
            <div className="clip border p-2.5 rise-in" style={{ borderColor: `${SEV_COLOR[activeShock.severity]}66`, background: `${SEV_COLOR[activeShock.severity]}10` }}>
              <div className="flex items-center gap-2">
                <span className="text-xl">{activeShock.emoji}</span>
                <div className="min-w-0">
                  <div className="chip text-[8px]" style={{ color: SEV_COLOR[activeShock.severity] }}>● ACTIVE WORLD SHOCK · {activeShock.severity.toUpperCase()}</div>
                  <div className="font-display font-bold text-sm truncate" style={{ color: SEV_COLOR[activeShock.severity] }}>{activeShock.name}</div>
                </div>
              </div>
              <p className="text-[11px] text-ink-dim mt-1.5 italic">"{activeShock.tagline}"</p>
              <div className="mt-2 flex items-center gap-2">
                <Bar value={shockRemaining} max={100} color={SEV_COLOR[activeShock.severity]} height={4} />
                <span className="chip text-ink-dim shrink-0">{shockRemaining}s</span>
              </div>
              <div className="flex flex-wrap gap-1 mt-2">
                {activeShock.effects.slice(0, 3).map((e) => (
                  <span key={e.label} className="chip text-[8px] px-1.5 py-0.5 rounded" style={{ color: "#d4dde6", background: "rgba(255,255,255,0.06)" }}>
                    {e.label} <b style={{ color: e.delta.startsWith("-") ? "#ff4d4d" : "#00ff9c" }}>{e.delta}</b>
                  </span>
                ))}
              </div>
            </div>
          ) : (
            <div className="clip border border-line p-2.5 text-center">
              <div className="text-2xl mb-1 flicker">🌫️</div>
              <div className="chip text-ink-dim">THE FOLD IS QUIET</div>
              <p className="text-[11px] text-ink-dim mt-1">…which is suspicious. Reload. Re-arm. Something always breaks.</p>
            </div>
          )}
        </div>

        {/* Mood + F&G */}
        <div className="p-3 border-b border-line flex items-center gap-3">
          <MoodGauge mood={mood} size={92} />
          <div className="min-w-0">
            <div className="chip" style={{ color: mb.color }}>{mb.label}</div>
            <p className="text-[11px] text-ink-dim mt-1 leading-snug">{mb.vibe}</p>
            <div className="chip text-ink-dim mt-1.5">FEAR&GREED {fng != null ? Math.round(fng) : "—"}</div>
          </div>
        </div>

        {/* Movers */}
        <div className="p-3 border-b border-line">
          <div className="chip text-ink-dim mb-2">TOP MOVERS</div>
          <div className="space-y-1.5">
            {movers.map((c) => {
              const up = (c.change24h ?? 0) >= 0;
              return (
                <div key={c.id} className="flex items-center gap-2">
                  <span className="text-sm w-4">{c.emoji}</span>
                  <span className="font-mono text-[11px] text-ink w-9">{c.symbol}</span>
                  <Sparkline data={c.sparkline} color={up ? "#00ff9c" : "#ff4d4d"} width={56} height={16} fill={false} strokeWidth={1.3} />
                  <span className="flex-1 text-right font-mono text-[11px] text-ink-dim">{fmtUsd(c.price)}</span>
                  <span className="chip tnum" style={{ color: up ? "#00ff9c" : "#ff4d4d" }}>{fmtPct(c.change24h)}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Transmissions */}
        <div className="p-3">
          <div className="chip text-ink-dim mb-2">TRANSMISSIONS</div>
          <div className="space-y-2">
            {transmissions.slice(0, 14).map((t) => {
              const tone = TONE[t.tone];
              return (
                <div key={t.id} className="ticker-drop flex gap-2 text-[11px] leading-snug">
                  <span className="w-1 shrink-0 rounded-full mt-0.5 self-stretch" style={{ background: tone.color, opacity: 0.7 }} />
                  <div className="min-w-0">
                    <span className="chip" style={{ color: tone.color }}>{t.source}</span>
                    <span className="text-ink-dim ml-1">· {timeAgo(t.ts)}</span>
                    <p className={cn("mt-0.5", t.tone === "raid" || t.tone === "fud" ? "text-ink" : "text-ink/90")}>{t.text}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </aside>
  );
}
