import { useState } from "react";
import { useApp } from "../store";
import { tx } from "../i18n";
import { DEVICE_LINES, RARITY_META, STATE_META, ROLE_META, type DeviceRole } from "../data";
import { Panel, TONE, Tag, Ring, Btn, fmtNum, fmtUsd, type Tone } from "../components/ui";
import { ScreenHeader, DeviceCard, ModuleGrid } from "../components/widgets";
import { cn } from "../utils/cn";

export function Devices() {
  const { owned, selected, selectDevice, lang, t, upgradePart, player, toggleEquip, toast } = useApp();
  const [roleF, setRoleF] = useState<string>("all");

  const lineRole = (id: string) => DEVICE_LINES.find((l) => l.id === id)?.role;
  const filtered = owned.filter((d) => roleF === "all" || lineRole(d.line) === roleF);

  return (
    <div className="p-4 max-w-[1500px] mx-auto space-y-4">
      <ScreenHeader icon="⬢" tone="violet" title={t("Devices")}
        sub={lang === "ru" ? "Экипируй до 4 девайсов — они дают бонусы в War Room. Жми карточку для прокачки и ремонта." : "Equip up to 4 devices — they grant War Room bonuses. Tap a card to upgrade or repair."}
        actions={<Tag tone="acid" dot glow>{lang === "ru" ? "Экипировано" : "Equipped"} {player.equipped.length}/4</Tag>}
      />

      {/* single role filter row (also the legend) */}
      <div className="flex gap-1.5 flex-wrap">
        <Chip active={roleF === "all"} onClick={() => setRoleF("all")} label={t("All")} count={owned.length} />
        {(Object.keys(ROLE_META) as DeviceRole[]).map((rk) => {
          const r = ROLE_META[rk];
          const n = owned.filter((d) => lineRole(d.line) === rk).length;
          return <Chip key={rk} active={roleF === rk} onClick={() => setRoleF(rk)} icon={r.icon} tone={r.tone} label={tx(r.label, lang)} count={n} title={tx(r.short, lang)} />;
        })}
      </div>

      {/* grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
        {filtered.map((d) => {
          const eq = player.equipped.includes(d.id);
          const slotFull = !eq && player.equipped.length >= 4;
          return (
            <div key={d.id} className="space-y-1.5">
              <DeviceCard device={d} equipped={eq} onClick={() => selectDevice(d.id)} />
              <button
                onClick={() => { toggleEquip(d.id); toast(eq ? (lang === "ru" ? "Снято." : "Unequipped.") : (slotFull ? (lang === "ru" ? "Слоты заняты (макс 4)." : "Slots full (max 4).") : (lang === "ru" ? "В бой!" : "Equipped!")), eq ? "mut" : "acid"); }}
                disabled={slotFull}
                className={cn("w-full py-1.5 rounded-lg text-[11px] font-bold uppercase tracking-wide border transition-colors disabled:opacity-40",
                  eq ? cn(TONE["ok"].bg, "text-black border-transparent") : "border-edge text-mut hover:text-ink hover:border-edge2")}>
                {eq ? "✓ " + (lang === "ru" ? "В лоадауте" : "In Loadout") : (slotFull ? (lang === "ru" ? "Слотов нет" : "No Slots") : "+ " + (lang === "ru" ? "Экипировать" : "Equip"))}
              </button>
            </div>
          );
        })}
      </div>

      {selected && (
        <DeviceModal onClose={() => selectDevice(null)} onUpgrade={(k) => upgradePart(selected.id, k)} onBay={() => selectDevice(null)} />
      )}
    </div>
  );
}

function Chip({ active, onClick, label, icon, tone = "mut", count, title }: { active: boolean; onClick: () => void; label: string; icon?: string; tone?: Tone; count?: number; title?: string }) {
  return (
    <button title={title} onClick={onClick} className={cn(
      "inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10.5px] font-semibold uppercase tracking-wide border transition-colors",
      active ? cn(TONE[tone].bg, "text-black border-transparent") : "bg-white/[0.04] text-mut border-edge hover:text-ink"
    )}>
      {icon && <span>{icon}</span>}{label}
      {count != null && <span className={cn("text-[9px] font-mono", active ? "text-black/60" : "text-mut2")}>{count}</span>}
    </button>
  );
}

function DeviceModal({ onClose, onUpgrade, onBay }: { onClose: () => void; onUpgrade: (k: string) => void; onBay: () => void }) {
  const { selected, lang, t, toast } = useApp();
  if (!selected) return null;
  const d = selected;
  const line = DEVICE_LINES.find((l) => l.id === d.line)!;
  const rar = RARITY_META[d.rarity];
  const st = STATE_META[d.state];
  const role = ROLE_META[line.role];
  const upgradable = d.parts.filter((p) => p.status === "upgradable").length;

  return (
    <div className="fixed inset-0 z-50 flex items-stretch sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <Panel className={cn("relative z-10 w-full sm:max-w-2xl max-h-screen sm:max-h-[90vh] overflow-y-auto rounded-none sm:rounded-xl", TONE[rar.tone].border)} tone={rar.tone}>
        {/* header */}
        <div className="sticky top-0 z-10 bg-panel/95 backdrop-blur border-b border-edge p-4 flex items-start gap-3">
          <div className={cn("w-14 h-14 rounded-xl flex items-center justify-center text-2xl border shrink-0", TONE[line.tone].soft, TONE[line.tone].border)}>{line.icon}</div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg font-bold text-ink leading-tight">{tx(d.name, lang)}</h2>
              <Tag tone={st.tone} dot>{tx(st.label, lang)}</Tag>
            </div>
            <div className="text-[11px] text-mut font-mono">{tx(line.name, lang)} · {tx(d.tier, lang)}</div>
            <div className="flex flex-wrap gap-1 mt-1.5">
              <Tag tone={role.tone} dot>{role.icon} {tx(role.label, lang)}</Tag>
              <Tag tone={rar.tone}>{tx(rar.label, lang)}</Tag>
              {d.faction && <Tag tone="pink">{lang === "ru" ? "фракция" : "faction"}</Tag>}
            </div>
            <div className="mt-2 rounded-md bg-white/[0.03] border border-edge px-2 py-1.5">
              <div className="flex items-center justify-between text-[10px]">
                <span className="uppercase tracking-wider text-mut">{lang === "ru" ? "Где используется" : "Used in"}</span>
                <span className="text-ink font-medium">{tx(line.usedIn, lang)}</span>
              </div>
              <div className="flex items-center gap-1 mt-0.5 text-[10.5px]">
                <span className={cn("font-bold", TONE[line.tone].text)}>⚡</span>
                <span className="text-mut">{tx(line.effect.text, lang)}</span>
              </div>
            </div>
          </div>
          <button onClick={onClose} className="text-mut hover:text-ink text-xl px-1">✕</button>
        </div>

        <div className="p-4 space-y-4">
          {/* stats row */}
          <div className="grid grid-cols-4 gap-2">
            <div className="flex flex-col items-center"><Ring value={d.utility} tone={rar.tone} size={52} label="UTIL" /></div>
            <Stat label={t("Value")} value={fmtNum(d.value)} sub="$FOLD" tone="acid" />
            <Stat label={lang === "ru" ? "В долларах" : "USD"} value={fmtUsd(d.valueUsd)} tone="mut" />
            <Stat label={lang === "ru" ? "Доход" : "Yield"} value={d.yieldPct ? "+" + d.yieldPct + "%" : "—"} tone="ok" />
          </div>

          <p className="text-[12px] text-mut italic leading-snug border-l-2 border-edge pl-3">“{tx(d.note, lang)}”</p>

          {/* modules */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-[12px] font-semibold uppercase tracking-wide text-ink">{lang === "ru" ? "Модульная структура" : "Modular Structure"} <span className="text-mut normal-case">— {upgradable} {lang === "ru" ? "готово к апгрейду" : "ready to upgrade"}</span></h3>
              <Btn size="sm" variant="ghost" onClick={onBay}>⚙ {t("Upgrade Bay")}</Btn>
            </div>
            <ModuleGrid device={d} onUpgrade={onUpgrade} />
          </div>

          {/* lifecycle */}
          <div>
            <h3 className="text-[12px] font-semibold uppercase tracking-wide text-ink mb-2">{lang === "ru" ? "Жизненный цикл ассета" : "Asset Lifecycle"}</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 text-[11px]">
              <Lifecycle label={lang === "ru" ? "Владельцев" : "Owners"} value={String(d.owners)} />
              <Lifecycle label={t("Season")} value={d.season || "—"} />
              <Lifecycle label={lang === "ru" ? "Прошлый ремонт" : "Last repair"} value={lang === "ru" ? "12д назад" : "12d ago"} />
              <Lifecycle label={lang === "ru" ? "Страховка" : "Insurance"} value={d.state === "insured" ? "✓" : "—"} />
              <Lifecycle label={lang === "ru" ? "В аренде" : "Rented"} value={d.state === "rented" ? "✓" : "—"} />
              <Lifecycle label={lang === "ru" ? "Бонд" : "Bonded"} value={d.state === "bonded" ? "✓" : "—"} />
            </div>
          </div>

          {/* actions */}
          <div className="flex flex-wrap gap-2 pt-2 border-t border-edge">
            <Btn size="sm" tone="acid" onClick={() => toast(lang === "ru" ? "Установлено." : "Equipped.")}>{t("Equip")}</Btn>
            <Btn size="sm" variant="outline" tone="cyan" onClick={() => toast(lang === "ru" ? "Страховка оформлена." : "Insured.")}>{t("Insure")}</Btn>
            <Btn size="sm" variant="outline" tone="warn" onClick={() => toast(lang === "ru" ? "Отправлено в ремонт." : "Sent to repair.")}>{t("Repair")}</Btn>
            <Btn size="sm" variant="outline" tone="gold" onClick={() => toast(lang === "ru" ? "Выставлено на рынок." : "Listed on market.")}>{t("List")}</Btn>
            <Btn size="sm" variant="outline" tone="violet" onClick={() => toast(lang === "ru" ? "Требуется 2 таких же для слияния." : "Needs 2 more to fuse.")}>{t("Fuse")}</Btn>
            <Btn size="sm" variant="ghost" onClick={() => toast(lang === "ru" ? "Переработано в материалы." : "Recycled into materials.")}>{t("Recycle")}</Btn>
          </div>
        </div>
      </Panel>
    </div>
  );
}

function Stat({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone: Tone }) {
  return (
    <div className="rounded-lg bg-white/[0.03] border border-edge p-2 text-center">
      <div className="text-[9px] uppercase text-mut tracking-wider">{label}</div>
      <div className={cn("text-sm font-bold tnum mt-0.5", TONE[tone].text)}>{value}</div>
      {sub && <div className="text-[9px] text-mut">{sub}</div>}
    </div>
  );
}

function Lifecycle({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md bg-white/[0.02] border border-edge px-2 py-1.5 flex items-center justify-between">
      <span className="text-mut">{label}</span>
      <span className="font-mono tnum text-ink">{value}</span>
    </div>
  );
}
