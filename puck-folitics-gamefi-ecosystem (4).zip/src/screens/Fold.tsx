import { useApp } from "../store";
import { tx } from "../i18n";
import { REGIONS, WORLD_SHOCKS, CHARACTERS, SEASONS } from "../data";
import { Panel, TONE, Bar, Tag, Ring, type Tone } from "../components/ui";
import { ScreenHeader } from "../components/widgets";
import { cn } from "../utils/cn";

export function Fold() {
  const { market, lang, t } = useApp();
  return (
    <div className="p-4 max-w-[1500px] mx-auto space-y-5">
      <ScreenHeader icon="🗺" tone="cyan" title={lang === "ru" ? "The Fold" : "The Fold"}
        sub={lang === "ru" ? "Карта мира, в котором ты живёшь. Реальный рынок задаёт ей настроение — а настроение меняет правила игры." : "The map of the world you live in. The real market sets its mood — and the mood changes the rules of the game."}
      />

      {/* WHAT IS THIS / WHY IT MATTERS */}
      <Panel className="p-3.5" tone="cyan">
        <div className="flex items-start gap-3">
          <span className="text-2xl shrink-0">🧭</span>
          <div>
            <h3 className="text-[13px] font-bold text-ink mb-1">{lang === "ru" ? "Что это и зачем тебе" : "What this is & why it matters"}</h3>
            <p className="text-[12px] text-mut leading-relaxed">
              {lang === "ru"
                ? "The Fold — это карта мира. Это не лор-витрина, а твоя игровая доска. Три вещи, которые тут важно знать:"
                : "The Fold is the world map. It's not a lore showcase — it's your game board. Three things matter here:"}
            </p>
            <div className="grid sm:grid-cols-3 gap-2 mt-2.5">
              {[
                { icon: "🌍", t: { en: "Real market = world mood", ru: "Реальный рынок = настроение мира" }, d: { en: "BTC pumps → world is Bull, yields heat up, raids get bold. This is the same data as your War Room.", ru: "BTC летит → мир Бычий, доход греется, рейдеры дерзеют. Это те же данные, что в War Room." } },
                { icon: "🏙", t: { en: "Regions = where you play", ru: "Регионы = где ты играешь" }, d: { en: "Each region has different risk, liquidity & jobs. Your node sits in one — expand to others.", ru: "У каждого региона свой риск, ликвидность и профессии. Твой узел в одном — расширяйся в другие." } },
                { icon: "🧨", t: { en: "Shocks = events that hit", ru: "Шоки = события, что бьют" }, d: { en: "Bridge Breach, Meme Fever, etc. They change the rules for a while. Anticipate & adapt.", ru: "Прорыв Моста, Мем-Лихорадка и т.д. Они временно меняют правила. Предвидь и адаптируйся." } },
              ].map((it, i) => (
                <div key={i} className="rounded-lg border border-edge p-2.5 bg-white/[0.02]">
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="text-base">{it.icon}</span>
                    <span className="text-[11px] font-bold text-ink">{tx(it.t, lang)}</span>
                  </div>
                  <p className="text-[10.5px] text-mut leading-snug">{tx(it.d, lang)}</p>
                </div>
              ))}
            </div>
            <div className="mt-2.5 rounded-lg bg-acid/5 border border-acid/20 p-2 flex items-start gap-2">
              <span className="text-sm">💡</span>
              <p className="text-[11px] text-ink leading-snug">
                {lang === "ru"
                  ? "Главное: мир тебя не наказывает и не сжигает деньги. Он просто меняет условия — и требует, чтобы ты обращал внимание и адаптировался. Заходи сюда, чтобы понять, что происходит вокруг твоего узла."
                  : "Key point: the world doesn't punish you or burn your money. It just shifts conditions — and asks you to pay attention and adapt. Come here to understand what's happening around your node."}
              </p>
            </div>
          </div>
        </div>
      </Panel>

      {/* Live regime banner */}
      <Panel className="p-4" tone={market.regimeTone}>
        <div className="flex flex-wrap items-center gap-4">
          <Ring value={market.sentiment} tone={market.regimeTone} size={64} label="WORLD" />
          <div className="min-w-[200px]">
            <div className="flex items-center gap-2">
              <span className={cn("text-lg font-bold uppercase tracking-wide", TONE[market.regimeTone].text)}>{tx(market.regimeLabel, lang)}</span>
              <Tag tone={market.live ? "ok" : "warn"} dot glow>{market.live ? t("Live") : t("Simulated")}</Tag>
            </div>
            <p className="text-[12px] text-mut mt-1 max-w-xl leading-snug">
              {lang === "ru"
                ? "Мир синхронизирован с реальными рынками. Режим меняет доходность, надёжность контрактов, панику NPC, спрос на страховки и вероятность рейдов — но никогда не сжигает ваши деньги напрямую."
                : "The world is synced to real markets. The regime shifts yields, contract reliability, NPC panic, insurance demand and raid probability — but never burns your money directly."}
            </p>
          </div>
          <div className="flex-1" />
          <div className="grid grid-cols-3 gap-3">
            {[
              { l: lang === "ru" ? "Логистика" : "Logistics", v: Math.round(80 + market.btcChg * 2), tone: "cyan" },
              { l: lang === "ru" ? "Паника NPC" : "NPC Panic", v: Math.round(100 - market.sentiment), tone: "danger" },
              { l: lang === "ru" ? "Спрос страховок" : "Insurance Demand", v: Math.round(40 + (100 - market.sentiment) * 0.5), tone: "ok" },
            ].map((m) => (
              <div key={m.l} className="text-center min-w-[64px]">
                <Ring value={m.v} tone={m.tone as Tone} size={48} />
                <div className="text-[9px] uppercase text-mut mt-1">{m.l}</div>
              </div>
            ))}
          </div>
        </div>
      </Panel>

      {/* Regions */}
      <section>
        <h2 className="text-[13px] font-semibold uppercase tracking-wide text-ink mb-3 flex items-center gap-2"><span className="text-gold">🏙</span> {lang === "ru" ? "Регионы мира" : "Regions of The Fold"}</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {REGIONS.map((r) => (
            <Panel key={r.id} className="p-3.5" tone={r.tone} hover>
              <div className="flex items-start gap-3">
                <div className={cn("w-11 h-11 rounded-lg flex items-center justify-center text-xl border", TONE[r.tone].soft, TONE[r.tone].border)}>{r.icon}</div>
                <div className="min-w-0 flex-1">
                  <div className="text-[13px] font-bold text-ink leading-tight">{tx(r.name, lang)}</div>
                  <div className="text-[10px] font-mono text-mut mt-0.5">{tx(r.play, lang)}</div>
                </div>
              </div>
              <p className="text-[11px] text-mut mt-2.5 leading-snug">{tx(r.desc, lang)}</p>
              <div className="mt-3 space-y-1.5">
                {[{ l: lang === "ru" ? "Опасность" : "Danger", v: r.danger, tone: "danger" }, { l: lang === "ru" ? "Ликвидность" : "Liquidity", v: r.liquidity, tone: "cyan" }, { l: lang === "ru" ? "Влияние" : "Influence", v: r.influence, tone: "gold" }].map((m) => (
                  <div key={m.l} className="flex items-center gap-2">
                    <span className="text-[10px] text-mut w-20 shrink-0">{m.l}</span>
                    <Bar value={m.v} tone={m.tone as Tone} className="flex-1" />
                    <span className="text-[10px] font-mono tnum text-mut w-7 text-right">{m.v}</span>
                  </div>
                ))}
              </div>
            </Panel>
          ))}
        </div>
      </section>

      {/* World shocks */}
      <section>
        <h2 className="text-[13px] font-semibold uppercase tracking-wide text-ink mb-3 flex items-center gap-2"><span className="text-pink">🧨</span> {lang === "ru" ? "Сценарные мировые шоки" : "Scripted World Shocks"}
          <span className="text-[10px] font-normal text-mut">— {lang === "ru" ? "контролируемая библиотека, а не хаос. 3 уровня влияния." : "a curated library, not chaos. 3 impact levels."}</span>
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {WORLD_SHOCKS.map((s) => (
            <Panel key={s.id} className="p-3" tone={s.tone}>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-lg">{s.icon}</span>
                <span className="text-[12px] font-bold text-ink leading-tight">{tx(s.name, lang)}</span>
              </div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[9px] uppercase text-mut">{lang === "ru" ? "шанс окна" : "window chance"}</span>
                <Bar value={s.chance * 3} tone={s.tone} className="flex-1" height="h-1" />
                <span className="text-[10px] font-mono tnum text-mut">{s.chance}%</span>
              </div>
              <div className="space-y-1 text-[10.5px]">
                <ImpactRow dot="cyan" label={lang === "ru" ? "Визуал" : "Visual"} text={tx(s.vis, lang)} />
                <ImpactRow dot="gold" label={lang === "ru" ? "Система" : "System"} text={tx(s.sys, lang)} />
                <ImpactRow dot="pink" label={lang === "ru" ? "Социум" : "Social"} text={tx(s.soc, lang)} />
              </div>
            </Panel>
          ))}
        </div>
      </section>

      {/* Characters */}
      <section>
        <h2 className="text-[13px] font-semibold uppercase tracking-wide text-ink mb-3 flex items-center gap-2"><span className="text-violet">🎭</span> {lang === "ru" ? "Маски индустрии" : "Masks of the Industry"}
          <span className="text-[10px] font-normal text-mut">— {lang === "ru" ? "архетипы. Считывается мгновенно, IP не копируется." : "archetypes. Instantly read, no IP copied."}</span>
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {CHARACTERS.map((c) => (
            <Panel key={c.id} className="p-3.5" tone={c.tone}>
              <div className="flex items-center gap-2.5">
                <div className={cn("w-11 h-11 rounded-lg flex items-center justify-center text-xl border", TONE[c.tone].soft, TONE[c.tone].border)}>{c.icon}</div>
                <div className="min-w-0">
                  <div className="text-[13px] font-bold text-ink leading-tight">{tx(c.name, lang)}</div>
                  <div className="text-[10px] text-mut">{tx(c.role, lang)}</div>
                </div>
              </div>
              <p className="text-[11px] text-mut mt-2 leading-snug min-h-[48px]">{tx(c.desc, lang)}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-[9px] uppercase text-mut">{lang === "ru" ? "Сила" : "Power"}</span>
                <Bar value={c.power} tone={c.tone} className="flex-1" height="h-1" />
                <span className="text-[10px] font-mono tnum text-mut">{c.power}</span>
              </div>
            </Panel>
          ))}
        </div>
      </section>

      {/* Seasons */}
      <section>
        <h2 className="text-[13px] font-semibold uppercase tracking-wide text-ink mb-3 flex items-center gap-2"><span className="text-acid">📅</span> {lang === "ru" ? "Сезонная структура" : "Seasonal Structure"}</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {SEASONS.map((s) => (
            <Panel key={s.id} className={cn("p-3.5", s.active && TONE[s.tone].border)} tone={s.active ? s.tone : undefined}>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-xl">{s.icon}</span>
                <span className="text-[12px] font-bold text-ink">{tx(s.name, lang)}</span>
                {s.active && <Tag tone={s.tone} dot glow>{lang === "ru" ? "сейчас" : "active"}</Tag>}
              </div>
              <p className="text-[11px] text-mut leading-snug">{tx(s.desc, lang)}</p>
            </Panel>
          ))}
        </div>
      </section>
    </div>
  );
}

function ImpactRow({ dot, label, text }: { dot: Tone; label: string; text: string }) {
  return (
    <div className="flex gap-1.5">
      <span className={cn("w-1.5 h-1.5 rounded-full mt-1 shrink-0", TONE[dot].dot)} />
      <span><span className="text-mut uppercase text-[9px] tracking-wide">{label}:</span> <span className="text-mut2">{text}</span></span>
    </div>
  );
}
