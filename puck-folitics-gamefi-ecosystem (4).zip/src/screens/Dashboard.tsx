import { useApp, RANKS } from "../store";
import { tx, type Tx } from "../i18n";
import {
  SEASONS, LISTINGS, FACTIONS, REGIONS, RIVALS, RIVAL_RELATION,
  PLAYER_NODE, MISSION, FACTION_WAR, PLAYER_GLOBAL_RANK, PLAYER_GLOBAL_TOTAL,
  type FactionId, type Relation, type Tone as DataTone,
} from "../data";
import { Panel, TONE, Bar, Ring, Tag, Btn, fmtNum, fmtUsd, fmtPrice, Spark, KPI, type Tone } from "../components/ui";
import { ListingCard } from "../components/widgets";
import { cn } from "../utils/cn";

export function Dashboard() {
  const { market, news, owned, player, lang, t, setView, selectDevice, toast } = useApp();
  const season = SEASONS.find((s) => s.active)!;
  const f = FACTIONS[player.faction];
  const rank = RANKS.filter((r) => player.xp >= r.xp).slice(-1)[0];
  const node = PLAYER_NODE;
  const region = REGIONS.find((r) => r.id === node.regionId)!;
  const threatLevel = Math.round(38 + (100 - market.sentiment) * 0.5);
  const netWorth = owned.reduce((s, d) => s + d.value, 0) + player.resources.fold;
  const dayYield = owned.reduce((s, d) => s + (d.yieldPct || 0) * d.value / 100 / 365, 0);

  const leaderboard = [...RIVALS, {
    id: "you", name: { en: player.name, ru: player.name }, handle: player.handle, faction: player.faction,
    power: 71, net: netWorth, globalRank: PLAYER_GLOBAL_RANK, relation: "rival" as Relation, region: node.regionId,
    note: { en: "This is you. Build, defend, climb.", ru: "Это ты. Строй, защищайся, поднимайся." },
  }].sort((a, b) => a.globalRank - b.globalRank);

  const alerts = [
    ...owned.filter((d) => d.state === "damaged").map((d) => ({ icon: "⚠", tone: "danger", text: tx(d.name, lang) + (lang === "ru" ? " повреждён!" : " is damaged!"), go: () => { selectDevice(d.id); setView("devices"); } })),
    { icon: "⚔", tone: "danger", text: lang === "ru" ? "0xРипер навёлся на твой узел." : "0xReaper marked your node.", go: () => setView("fold") },
    { icon: "🛡", tone: "cyan", text: lang === "ru" ? "Страховка Bridge Relay истекает через 2 дня." : "Bridge Relay insurance expires in 2 days.", go: () => setView("devices") },
    { icon: "🧊", tone: "warn", text: lang === "ru" ? "Окно Прорыва Моста откроется через ~6ч." : "Bridge Breach window opens in ~6h.", go: () => setView("fold") },
  ].slice(0, 4);

  return (
    <div className="p-4 max-w-[1500px] mx-auto space-y-4">
      {/* ============ OPERATOR HERO ============ */}
      <Panel className="overflow-hidden" tone={f.tone}>
        <div className="grid lg:grid-cols-[auto_1fr_auto] gap-5 p-4 items-center">
          {/* WHO */}
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className={cn("w-20 h-20 rounded-2xl flex items-center justify-center text-4xl border-2", TONE[f.tone].soft, TONE[f.tone].border)} style={{ boxShadow: `0 0 28px -4px var(--color-${f.tone === "acid" ? "acid" : f.tone})` }}>
                {f.icon}
              </div>
              <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded bg-acid text-black text-[9px] font-black uppercase whitespace-nowrap">{lang === "ru" ? "Ты" : "You"}</span>
            </div>
            <div className="min-w-0">
              <div className="text-[10px] uppercase tracking-[0.2em] text-mut">{t("Operator")}</div>
              <div className="text-2xl font-black text-ink leading-none">{player.name}</div>
              <div className="text-[11px] text-mut mt-1.5 leading-snug max-w-[230px]">
                {lang === "ru"
                  ? "Ты оператор мира. Строй узел, переживай шоки, лезь на вершину."
                  : "You run a piece of this world. Build your node, survive shocks, climb to the top."}
              </div>
              <div className="flex gap-1.5 mt-2 flex-wrap">
                <Tag tone={f.tone} dot glow>{tx(f.name, lang)}</Tag>
                <Tag tone="gold">R{rank.tier} · {tx(rank.name, lang)}</Tag>
              </div>
            </div>
          </div>

          {/* WHERE */}
          <div className="min-w-0 lg:border-x lg:border-edge lg:px-5">
            <div className="text-[10px] uppercase tracking-[0.2em] text-mut mb-1.5">{lang === "ru" ? "📍 Ты здесь" : "📍 You are here"}</div>
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">{region.icon}</span>
              <div className="min-w-0">
                <div className="text-[15px] font-bold text-ink truncate">{tx(node.name, lang)}</div>
                <div className="text-[11px] text-mut truncate">{tx(region.name, lang)} · {tx(node.sector, lang)}</div>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3 mt-3">
              <NodeStat l={lang === "ru" ? "Контроль" : "Control"} v={node.control} tone="acid" />
              <NodeStat l={lang === "ru" ? "Целостность" : "Integrity"} v={node.integrity} tone="ok" />
              <NodeStat l={lang === "ru" ? "Угроза" : "Threat"} v={threatLevel} tone={threatLevel > 60 ? "danger" : "warn"} />
            </div>
          </div>

          {/* RANK + CTA */}
          <div className="flex flex-col items-end justify-between gap-3 min-w-[140px]">
            <div className="text-right">
              <div className="text-[10px] uppercase tracking-wider text-mut">{lang === "ru" ? "Мировой ранг" : "Global Rank"}</div>
              <div className="text-2xl font-black tnum text-acid leading-none">#{PLAYER_GLOBAL_RANK.toLocaleString()}</div>
              <div className="text-[10px] text-mut font-mono mt-0.5">{lang === "ru" ? "из" : "of"} {fmtNum(PLAYER_GLOBAL_TOTAL)}</div>
            </div>
            <Btn tone={f.tone} onClick={() => setView("fold")}>{lang === "ru" ? "Текущая цель →" : "Active Objective →"}</Btn>
          </div>
        </div>
      </Panel>

      {/* ============ DO THIS NEXT (dominant) ============ */}
      <NextMove />

      {/* ============ KPI ROW ============ */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KPI label={lang === "ru" ? "Капитал" : "Net Worth"} value={<span>{fmtNum(netWorth)} <span className="text-[11px] text-mut">$FOLD</span></span>} sub={fmtUsd(netWorth / 42.6)} tone="acid" icon="💎" />
        <KPI label={lang === "ru" ? "Доход/день" : "Daily Yield"} value={<span className="text-ok">+{fmtNum(dayYield)}</span>} sub={lang === "ru" ? "пассивно" : "passive"} tone="ok" icon="📈" />
        <KPI label={lang === "ru" ? "Активные блоки" : "Active Devices"} value={owned.filter((d) => d.state !== "locked").length + "/" + owned.length} sub={owned.filter((d) => d.state === "damaged").length + " " + (lang === "ru" ? "требуют ремонта" : "need repair")} tone="violet" icon="⬢" />
        <KPI label={lang === "ru" ? "Репутация" : "Reputation"} value={f.rep + "%"} sub={tx(f.name, lang)} tone={f.tone} icon="⚑" />
      </div>

      {/* ============ MISSION + FACTION WAR ============ */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* current objective */}
        <Panel className="lg:col-span-2 p-4" tone="cyan">
          <div className="flex items-start justify-between gap-3 mb-2">
            <div className="flex items-center gap-2">
              <span className="text-lg">🎯</span>
              <div>
                <div className="text-[10px] uppercase tracking-wider text-mut">{lang === "ru" ? "Текущая цель" : "Active Objective"}</div>
                <h3 className="text-[14px] font-bold text-ink leading-tight">{tx(MISSION.title, lang)}</h3>
              </div>
            </div>
            <Tag tone="danger" dot glow>{tx(MISSION.deadline, lang)}</Tag>
          </div>
          <p className="text-[12px] text-mut leading-snug mb-3">{tx(MISSION.desc, lang)}</p>
          <div className="space-y-1.5 mb-3">
            {MISSION.steps.map((s, i) => (
              <div key={i} className="flex items-center gap-2 text-[12px]">
                <span className={cn("w-4 h-4 rounded flex items-center justify-center text-[10px] font-bold border", s.done ? "bg-ok/20 border-ok text-ok" : "border-edge text-mut2")}>{s.done ? "✓" : i + 1}</span>
                <span className={s.done ? "text-mut line-through" : "text-ink"}>{tx(s, lang)}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-[11px]">
              <Bar value={MISSION.progress} tone="cyan" className="w-32" />
              <span className="text-mut font-mono">{MISSION.progress}%</span>
              <span className="text-acid font-bold">+{fmtNum(MISSION.reward)} $FOLD</span>
            </div>
            <Btn size="sm" tone="cyan" onClick={() => { selectDevice("dev-bridge-01"); setView("devices"); }}>{lang === "ru" ? "Выполнить →" : "Continue →"}</Btn>
          </div>
        </Panel>

        {/* faction war */}
        <Panel className="p-4">
          <h3 className="text-[10px] uppercase tracking-wider text-mut mb-2 flex items-center gap-1.5"><span>⚔</span> {lang === "ru" ? "Война фракций" : "Faction War"}</h3>
          <div className="space-y-2 mb-3">
            {(Object.keys(FACTION_WAR.power) as FactionId[]).map((fid) => {
              const ff = FACTIONS[fid];
              const isYou = fid === player.faction;
              return (
                <div key={fid} className="flex items-center gap-2">
                  <span className={cn("text-sm w-5 text-center", isYou && "scale-125")}>{ff.icon}</span>
                  <Bar value={FACTION_WAR.power[fid] * 3} tone={ff.tone} className="flex-1" height="h-2" />
                  <span className={cn("text-[11px] font-mono tnum w-8 text-right", isYou ? "text-ink font-bold" : "text-mut")}>{FACTION_WAR.power[fid]}%</span>
                </div>
              );
            })}
          </div>
          <div className="space-y-1.5 pt-2 border-t border-edge">
            {FACTION_WAR.pairs.map((p, i) => (
              <div key={i} className="flex items-center justify-between text-[10.5px]">
                <span className="text-mut">{tx(p.label, lang)}</span>
                <span className={cn("font-mono font-bold", p.tension > 70 ? "text-danger" : "text-warn")}>{p.tension}%</span>
              </div>
            ))}
          </div>
          <p className="text-[10px] text-mut2 mt-2 leading-snug">{lang === "ru" ? "Билдеры и Рейдеры — в горячей войне. Каждый Прорыв Моста — это раунд." : "Builders and Raiders are at war. Every Bridge Breach is a round."}</p>
        </Panel>
      </div>

      {/* ============ YOU vs THE FOLD (leaderboard / rivals) ============ */}
      <Panel className="p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-[13px] font-bold uppercase tracking-wide text-ink flex items-center gap-2"><span className="text-pink">🏆</span> {lang === "ru" ? "Ты против The Fold" : "You vs The Fold"} <span className="text-[10px] font-normal text-mut">— {lang === "ru" ? "операторы вокруг тебя" : "operators around your rank"}</span></h3>
          <Btn size="sm" variant="ghost" onClick={() => setView("factions")}>{lang === "ru" ? "Все фракции" : "All Factions"} ›</Btn>
        </div>
        <div className="space-y-1.5">
          {leaderboard.map((r) => {
            const isYou = r.id === "you";
            const rf = FACTIONS[r.faction];
            const rel = RIVAL_RELATION[r.relation];
            return (
              <div key={r.id} className={cn("flex items-center gap-3 rounded-lg px-2.5 py-2 border transition-colors", isYou ? cn(TONE[f.tone].border, TONE[f.tone].soft) : "border-edge hover:border-edge2")}>
                <span className={cn("text-[12px] font-mono font-bold tnum w-12 text-right", isYou ? "text-acid" : "text-mut")}>#{r.globalRank.toLocaleString()}</span>
                <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center text-base border shrink-0", TONE[rf.tone].soft, TONE[rf.tone].border)}>{rf.icon}</div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className={cn("text-[12.5px] font-semibold truncate", isYou ? "text-ink" : "text-ink/90")}>{tx(r.name, lang)}</span>
                    {isYou && <span className="text-[8px] bg-acid text-black font-bold px-1 rounded">{lang === "ru" ? "ТЫ" : "YOU"}</span>}
                  </div>
                  <div className="text-[10px] text-mut font-mono truncate">{r.handle}</div>
                </div>
                <div className="hidden sm:block text-right min-w-[70px]">
                  <div className="text-[11px] font-mono tnum text-mut">{fmtNum(r.net)}</div>
                  <div className="text-[9px] text-mut2">$FOLD</div>
                </div>
                <div className="hidden md:flex items-center gap-1.5 min-w-[80px]">
                  <span className="text-[9px] uppercase text-mut">{lang === "ru" ? "Сила" : "Power"}</span>
                  <Bar value={r.power} tone={rf.tone} className="w-12" height="h-1.5" />
                </div>
                {!isYou ? (
                  <>
                    <Tag tone={rel.tone as DataTone} dot>{tx(rel.label, lang)}</Tag>
                    <Btn size="sm" variant="outline" tone={rel.tone as DataTone} onClick={() => toast(lang === "ru" ? `${tx(rel.act, lang)}: ${tx(r.name, lang)}` : `${tx(rel.act, lang)}: ${tx(r.name, lang)}`, rel.tone)}>{tx(rel.act, lang)}</Btn>
                  </>
                ) : (
                  <Tag tone={f.tone} dot glow>{lang === "ru" ? "в игре" : "in play"}</Tag>
                )}
              </div>
            );
          })}
        </div>
      </Panel>

      {/* ============ WORLD + RIGHT COLUMN ============ */}
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          {/* world state strip */}
          <Panel className="p-3.5" tone={market.regimeTone}>
            <div className="flex flex-wrap items-center gap-4">
              <Ring value={market.sentiment} tone={market.regimeTone} size={52} label="WORLD" />
              <div className="min-w-[140px]">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{season.icon}</span>
                  <span className="text-[13px] font-bold text-ink">{tx(season.name, lang)}</span>
                  <Tag tone={market.regimeTone} dot glow>{tx(market.regimeLabel, lang)}</Tag>
                </div>
                <div className="text-[11px] text-mut mt-0.5">{market.live ? (lang === "ru" ? "Синхрон с реальным рынком" : "Synced to live market") : (lang === "ru" ? "Симуляция ленты" : "Simulated feed")}</div>
              </div>
              <div className="flex-1" />
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {market.coins.map((c) => (
                  <div key={c.sym} className="rounded-lg bg-black/30 px-2 py-1.5 border border-edge min-w-[88px]">
                    <div className="flex items-center justify-between"><span className="text-[10px] font-bold text-ink">{c.sym}</span><Spark data={c.spark} tone={c.chg >= 0 ? "ok" : "danger"} w={36} h={12} /></div>
                    <div className="text-[11px] font-mono tnum text-ink">{fmtPrice(c.price)}</div>
                    <div className={cn("text-[10px] font-mono tnum", c.chg >= 0 ? "text-ok" : "text-danger")}>{c.chg >= 0 ? "+" : ""}{c.chg.toFixed(2)}%</div>
                  </div>
                ))}
              </div>
            </div>
          </Panel>

          {/* signals */}
          <Panel className="p-3.5">
            <h3 className="text-[13px] font-semibold uppercase tracking-wide text-ink flex items-center gap-2 mb-2.5"><span className="text-cyan">📡</span> {lang === "ru" ? "Что происходит в мире" : "What's Happening"} <Tag tone={market.live ? "ok" : "warn"} dot glow>{market.live ? t("Live") : t("Simulated")}</Tag></h3>
            <div className="space-y-1">
              {news.slice(0, 4).map((n, i) => (
                <div key={i} className="flex gap-2.5 items-start text-[12px] py-1.5 border-b border-edge/50 last:border-0">
                  <span className={cn("w-1 h-1 rounded-full mt-1.5 shrink-0", i === 0 ? "bg-acid blink" : "bg-mut2")} />
                  <span className="text-mut leading-snug">{tx(n, lang)}</span>
                </div>
              ))}
            </div>
          </Panel>

          {/* marketplace highlights */}
          <Panel className="p-3.5">
            <div className="flex items-center justify-between mb-2.5">
              <h3 className="text-[13px] font-semibold uppercase tracking-wide text-ink flex items-center gap-2"><span className="text-gold">🛒</span> {lang === "ru" ? "В тренде на рынке" : "Trending on Market"}</h3>
              <Btn size="sm" variant="ghost" onClick={() => setView("marketplace")}>{t("View all")} ›</Btn>
            </div>
            <div className="grid sm:grid-cols-2 gap-2.5">
              {[...LISTINGS].sort((a, b) => b.demand - a.demand).slice(0, 2).map((l) => <ListingCard key={l.id} listing={l} onClick={() => setView("marketplace")} />)}
            </div>
          </Panel>
        </div>

        {/* right column */}
        <div className="space-y-4">
          {/* LIVE SPIN teaser */}
          <Panel className="p-3.5 relative overflow-hidden" tone="pink">
            <div className="absolute inset-0 shimmer opacity-40 pointer-events-none" />
            <div className="relative">
              <div className="flex items-center justify-between mb-1.5">
                <h3 className="text-[13px] font-bold uppercase tracking-wide text-ink flex items-center gap-2"><span>🎩</span> {lang === "ru" ? "Спин готов" : "Spin Ready"}</h3>
                <Tag tone={market.live ? "ok" : "warn"} dot glow>{market.live ? t("Live") : t("Simulated")}</Tag>
              </div>
              <p className="text-[12px] text-ink font-medium leading-snug mb-1">{market.btcChg >= 0 ? (lang === "ru" ? `BTC ${market.btcChg >= 0 ? "+" : ""}${market.btcChg.toFixed(1)}% — раскрути памп.` : `BTC ${market.btcChg >= 0 ? "+" : ""}${market.btcChg.toFixed(1)}% — spin the pump.`) : (lang === "ru" ? `BTC ${market.btcChg.toFixed(1)}% — собери урожай страха.` : `BTC ${market.btcChg.toFixed(1)}% — harvest the fear.`)}</p>
              <p className="text-[10.5px] text-mut leading-snug mb-2.5">{lang === "ru" ? "Читаешь рынок → спинишь нарратив → забираешь толпу." : "Read market → spin narrative → take the crowd."}</p>
              <Btn tone="pink" size="sm" full onClick={() => setView("warroom")}>🎲 {lang === "ru" ? "Открыть War Room" : "Open War Room"}</Btn>
            </div>
          </Panel>

          {/* needs attention */}
          <Panel className="p-3.5">
            <h3 className="text-[13px] font-semibold uppercase tracking-wide text-ink flex items-center gap-2 mb-2.5"><span className="text-danger">🔔</span> {lang === "ru" ? "Требует внимания" : "Needs Attention"}</h3>
            <div className="space-y-1">
              {alerts.map((a, i) => (
                <button key={i} onClick={a.go} className="w-full flex items-center gap-2.5 text-left rounded-lg px-2 py-2 hover:bg-white/[0.04] transition-colors group">
                  <span className={cn("w-7 h-7 rounded-md flex items-center justify-center text-sm shrink-0", TONE[a.tone as DataTone].soft)}>{a.icon}</span>
                  <span className="text-[11.5px] text-mut group-hover:text-ink leading-snug flex-1">{a.text}</span>
                  <span className="text-mut group-hover:text-ink">›</span>
                </button>
              ))}
            </div>
          </Panel>

          {/* progression */}
          <Panel className="p-3.5" tone={f.tone}>
            <h3 className="text-[13px] font-semibold uppercase tracking-wide text-ink flex items-center gap-2 mb-2.5"><span className={TONE[f.tone].text}>📈</span> {t("Progression")}</h3>
            <RankLadder lang={lang} xp={player.xp} />
            <Btn size="sm" variant="outline" tone={f.tone} full className="mt-3" onClick={() => setView("devices")}>{lang === "ru" ? "Ускорить рост →" : "Accelerate Growth →"}</Btn>
          </Panel>

          {/* store CTA */}
          <Panel className="p-3.5 relative overflow-hidden" tone="pink">
            <div className="absolute inset-0 shimmer opacity-40 pointer-events-none" />
            <div className="relative">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-lg">🎫</span>
                <span className="text-[13px] font-bold text-ink">{lang === "ru" ? "Бычий Пропуск" : "Bull Season Pass"}</span>
              </div>
              <p className="text-[11px] text-mut mb-2 leading-snug">{lang === "ru" ? "100+ наград. ФОМО — это фича." : "100+ rewards. FOMO is a feature."}</p>
              <Btn tone="pink" size="sm" full onClick={() => setView("store")}>{lang === "ru" ? "Открыть · $14.99" : "Unlock · $14.99"}</Btn>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function NodeStat({ l, v, tone }: { l: string; v: number; tone: DataTone }) {
  return (
    <div>
      <div className="flex justify-between text-[10px] mb-1">
        <span className="text-mut">{l}</span>
        <span className={cn("font-mono tnum font-bold", TONE[tone].text)}>{v}%</span>
      </div>
      <Bar value={v} tone={tone} height="h-1.5" />
    </div>
  );
}

function RankLadder({ lang, xp }: { lang: "en" | "ru"; xp: number }) {
  const rank = RANKS.filter((r) => xp >= r.xp).slice(-1)[0];
  const next = RANKS.find((r) => r.xp > xp) ?? RANKS[RANKS.length - 1];
  const prog = next ? ((xp - rank.xp) / (next.xp - rank.xp)) * 100 : 100;
  return (
    <div>
      <div className="flex items-center justify-between text-[12px] mb-1.5">
        <span className="font-bold text-ink">{tx(rank.name, lang)}</span>
        <span className="text-mut text-[11px]">→ {next ? tx(next.name, lang) : "MAX"}</span>
      </div>
      <Bar value={prog} tone="cyan" />
      <div className="flex justify-between text-[10px] text-mut mt-1 font-mono">
        <span>{fmtNum(xp)} XP</span>
        <span>{next ? fmtNum(next.xp) : "—"}</span>
      </div>
    </div>
  );
}

/* The single most important thing on the screen: what to do right now. */
function NextMove() {
  const { lang, setView, selectDevice, setHelpOpen, toast, t } = useApp();
  const moves: { id: string; icon: string; tone: Tone; go: () => void; title: Tx; why: Tx; big?: boolean }[] = [
    { id: "spin", icon: "🎲", tone: "pink", go: () => setView("warroom"), big: true,
      title: { en: "Spin the market", ru: "Раскрути рынок" },
      why: { en: "BTC just moved. Spin a narrative, win the crowd. This is the game.", ru: "BTC только что двинул. Раскрути нарратив, забери толпу. Это и есть игра." } },
    { id: "upgrade", icon: "⚙", tone: "violet", go: () => { selectDevice("dev-rug-01"); setView("devices"); },
      title: { en: "Fix & upgrade", ru: "Почини и прокачай" },
      why: { en: "Your Rug Detector is damaged. Repair it.", ru: "Детектор Скама повреждён. Почини." } },
    { id: "squeeze", icon: "⚔", tone: "gold", go: () => { setView("command"); toast(lang === "ru" ? "Дожми ДампТрак Дэна!" : "Squeeze DumpTruck Dan!", "gold"); },
      title: { en: "Squeeze a rival", ru: "Дожми соперника" },
      why: { en: "DumpTruck Dan is over-leveraged. Easy rank.", ru: "ДампТрак Дэн перегружен. Лёгкий ранг." } },
  ];
  return (
    <Panel className="p-3.5" tone="acid">
      <div className="flex items-center justify-between mb-2.5 flex-wrap gap-2">
        <h3 className="text-[13px] font-bold uppercase tracking-wide text-ink flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-acid blink" />
          {lang === "ru" ? "Что делать прямо сейчас" : "Do this next"}
        </h3>
        <button onClick={() => setHelpOpen(true)} className="text-[11px] text-mut hover:text-acid underline underline-offset-2">
          {lang === "ru" ? "Не понимаешь? Жми сюда" : "Confused? Read this"}
        </button>
      </div>
      <div className="grid sm:grid-cols-3 gap-2.5">
        {moves.map((m) => (
          <button key={m.id} onClick={m.go}
            className={cn("relative text-left rounded-xl border p-3 transition-all hover:scale-[1.02] active:scale-100 overflow-hidden", TONE[m.tone].border, TONE[m.tone].soft, m.big && "sm:col-span-1 row-span-1")}>
            {m.big && <span className="absolute inset-0 shimmer opacity-50 pointer-events-none" />}
            <div className="relative">
              <div className="flex items-center gap-2 mb-1">
                <span className={cn(m.big ? "text-2xl" : "text-lg")}>{m.icon}</span>
                <span className={cn(m.big ? "text-[15px]" : "text-[13px]", "font-bold", TONE[m.tone].text)}>{tx(m.title, lang)}</span>
                {m.big && <Tag tone={m.tone} glow>{lang === "ru" ? "ГЛАВНОЕ" : "MAIN"}</Tag>}
              </div>
              <p className="text-[11px] text-mut leading-snug">{tx(m.why, lang)}</p>
              <span className={cn("text-[10px] font-bold uppercase tracking-wider mt-2 inline-flex items-center gap-1", TONE[m.tone].text)}>
                {t("Go")} ›
              </span>
            </div>
          </button>
        ))}
      </div>
    </Panel>
  );
}
