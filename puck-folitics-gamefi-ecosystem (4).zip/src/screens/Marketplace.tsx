import { useState, useMemo } from "react";
import { useApp } from "../store";
import { tx } from "../i18n";
import { LISTINGS, ASSET_CLASS_META, RARITY_META, type Listing } from "../data";
import { Panel, TONE, Tag, Btn, KPI, fmtNum, fmtUsd, type Tone } from "../components/ui";
import { ScreenHeader, ListingCard } from "../components/widgets";
import { cn } from "../utils/cn";

const TYPES = [
  { id: "all", label: "All", tone: "mut" },
  { id: "buy", label: "Buy", tone: "acid" },
  { id: "auction", label: "Auction", tone: "gold" },
  { id: "offer", label: "Offer", tone: "violet" },
  { id: "rent", label: "Rent", tone: "cyan" },
  { id: "bundle", label: "Bundle", tone: "pink" },
] as const;
const SORTS = [
  { id: "demand", en: "Demand", ru: "Спрос" },
  { id: "price", en: "Price", ru: "Цена" },
  { id: "liquidity", en: "Liquidity", ru: "Ликвидность" },
  { id: "utility", en: "Utility", ru: "Полезность" },
];

export function Marketplace() {
  const { lang, t, spend, toast } = useApp();
  const [typeF, setTypeF] = useState<string>("all");
  const [sort, setSort] = useState("demand");
  const [sel, setSel] = useState<Listing | null>(null);

  const list = useMemo(() => {
    let l = LISTINGS.filter((x) => typeF === "all" || x.type === typeF);
    l = [...l].sort((a, b) => {
      if (sort === "price") return b.price - a.price;
      if (sort === "liquidity") return b.liquidity - a.liquidity;
      if (sort === "utility") return (b.utility || 0) - (a.utility || 0);
      return b.demand - a.demand;
    });
    return l;
  }, [typeF, sort]);

  const stats = useMemo(() => {
    const floor = Math.min(...LISTINGS.map((l) => l.price));
    const vol = LISTINGS.reduce((s, l) => s + l.price, 0);
    const fee = LISTINGS.reduce((s, l) => s + l.fee, 0) / LISTINGS.length;
    return { floor, vol, fee, count: LISTINGS.length };
  }, []);

  return (
    <div className="p-4 max-w-[1500px] mx-auto space-y-4">
      <ScreenHeader icon="🛒" tone="gold" title={t("Marketplace")}
        sub={lang === "ru" ? "Живой рынок между игроками: устройства, модули, лицензии, страховки, чертежи, фрагменты и креаторский контент." : "A living market between players: devices, modules, licenses, insurance, blueprints, fragments & creator content."}
        actions={<Btn size="sm" tone="gold" onClick={() => toast(lang === "ru" ? "Открой хранилище и выбери ассет для листинга." : "Open Vault and pick an asset to list.")}>＋ {t("List")}</Btn>}
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KPI label={lang === "ru" ? "Мин. пол" : "Floor Index"} value={fmtNum(stats.floor)} sub="$FOLD" tone="acid" />
        <KPI label={lang === "ru" ? "Объём (24ч)" : "Volume (24h)"} value={fmtNum(stats.vol)} sub="$FOLD" tone="gold" />
        <KPI label={lang === "ru" ? "Активных лотов" : "Active Listings"} value={stats.count} tone="cyan" />
        <KPI label={lang === "ru" ? "Ср. комиссия" : "Avg Fee"} value={stats.fee.toFixed(1) + "%"} tone="violet" />
      </div>

      {/* filters */}
      <div className="flex flex-wrap items-center gap-2 justify-between">
        <div className="flex gap-1.5 flex-wrap">
          {TYPES.map((tp) => (
            <FChip key={tp.id} active={typeF === tp.id} tone={tp.tone as Tone} onClick={() => setTypeF(tp.id)} label={tp.label === "All" ? t("All") : t(tp.label)} />
          ))}
        </div>
        <div className="flex gap-1.5 flex-wrap items-center">
          <span className="text-[10px] uppercase text-mut tracking-wider">{t("Sort")}:</span>
          {SORTS.map((s) => (
            <FChip key={s.id} active={sort === s.id} onClick={() => setSort(s.id)} label={tx(s, lang)} />
          ))}
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
        {list.map((l) => <ListingCard key={l.id} listing={l} onClick={() => setSel(l)} />)}
      </div>

      {sel && <ListingModal l={sel} onClose={() => setSel(null)} onBuy={() => {
        if (spend(sel.price)) toast(lang === "ru" ? `Куплено: ${tx(sel.name, lang)}` : `Acquired: ${tx(sel.name, lang)}`, "ok");
        else toast(lang === "ru" ? "Недостаточно $FOLD." : "Not enough $FOLD.", "danger");
      }} />}
    </div>
  );
}

function FChip({ active, onClick, label, tone = "mut" }: { active: boolean; onClick: () => void; label: string; tone?: Tone }) {
  return (
    <button onClick={onClick} className={cn("px-2 py-1 rounded-md text-[10.5px] font-semibold uppercase tracking-wide border transition-colors",
      active ? cn(TONE[tone].bg, "text-black border-transparent") : "bg-white/[0.04] text-mut border-edge hover:text-ink")}>{label}</button>
  );
}

function ListingModal({ l, onClose, onBuy }: { l: Listing; onClose: () => void; onBuy: () => void }) {
  const { lang, t } = useApp();
  const cls = ASSET_CLASS_META[l.class];
  const rar = l.rarity ? RARITY_META[l.rarity] : null;
  const hist = ["0x4f…ea", "guild:NIGHTWHALE", "@archivist_99"].slice(0, 3);
  const typeTone: Tone = l.type === "auction" ? "gold" : l.type === "rent" ? "cyan" : l.type === "offer" ? "violet" : l.type === "bundle" ? "pink" : "acid";
  const action = l.type === "auction" ? t("Bid") : l.type === "offer" ? t("Offer") : l.type === "rent" ? t("Rent") : l.type === "bundle" ? t("Buy") : t("Buy");
  return (
    <div className="fixed inset-0 z-50 flex items-stretch sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <Panel className={cn("relative z-10 w-full sm:max-w-lg max-h-screen sm:max-h-[90vh] overflow-y-auto rounded-none sm:rounded-xl", TONE[typeTone].border)} tone={typeTone}>
        <div className="sticky top-0 z-10 bg-panel/95 backdrop-blur border-b border-edge p-4 flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Tag tone={typeTone}>{tx(l.kind, lang)}</Tag>
              {l.tag && <Tag tone="pink" glow>{tx(l.tag, lang)}</Tag>}
            </div>
            <h2 className="text-lg font-bold text-ink leading-tight">{tx(l.name, lang)}</h2>
            <div className="text-[11px] text-mut font-mono">{tx(l.meta, lang)}</div>
          </div>
          <button onClick={onClose} className="text-mut hover:text-ink text-xl">✕</button>
        </div>
        <div className="p-4 space-y-4">
          <div className="flex flex-wrap gap-1">
            <Tag tone={cls.tone}>{tx(cls.label, lang)}</Tag>
            {rar && <Tag tone={rar.tone}>{tx(rar.label, lang)}</Tag>}
            {l.faction && <Tag tone="pink">{lang === "ru" ? "фракция-лок" : "faction-locked"}</Tag>}
          </div>

          {/* price block */}
          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-lg bg-white/[0.03] border border-edge p-3">
              <div className="text-[10px] uppercase text-mut">{l.type === "auction" ? t("Top Bid") : l.type === "rent" ? lang === "ru" ? "За период" : "Per period" : t("Price")}</div>
              <div className="text-xl font-bold tnum text-acid">{fmtNum(l.price)}</div>
              <div className="text-[11px] font-mono text-mut">{fmtUsd(l.priceUsd)}</div>
            </div>
            <div className="rounded-lg bg-white/[0.03] border border-edge p-3 space-y-1">
              {l.floor != null && <Row k={t("Floor")} v={fmtNum(l.floor)} />}
              {l.lastSale != null && <Row k={t("Last sale")} v={fmtNum(l.lastSale)} />}
              <Row k={t("Fee")} v={l.fee + "%"} />
              <Row k={t("Royalty")} v={l.royalty + "%"} />
            </div>
          </div>

          {/* metrics */}
          <div className="grid grid-cols-3 gap-2">
            {[{ l: t("Utility"), v: l.utility ?? "—" }, { l: t("Demand"), v: l.demand }, { l: t("Liquidity"), v: l.liquidity }].map((m) => (
              <div key={m.l} className="rounded-lg bg-white/[0.03] border border-edge p-2 text-center">
                <div className="text-[9px] uppercase text-mut">{m.l}</div>
                <div className="text-sm font-bold tnum text-ink">{m.v}</div>
              </div>
            ))}
          </div>

          {/* owner history */}
          <div>
            <div className="text-[11px] uppercase text-mut tracking-wider mb-1.5">{lang === "ru" ? "История владения" : "Owner History"}</div>
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px]"><span className="font-mono text-ink">{l.owner}</span><span className="text-mut font-mono">{lang === "ru" ? "сейчас" : "current"}</span></div>
              {hist.map((h, i) => (
                <div key={i} className="flex items-center justify-between text-[11px]"><span className="font-mono text-mut">{h}</span><span className="text-mut2 font-mono">{(i + 1) * 23}д назад</span></div>
              ))}
            </div>
          </div>

          <div className="flex gap-2">
            <Btn tone={typeTone} full onClick={onBuy}>{action} →</Btn>
            <Btn variant="outline" tone="cyan" onClick={() => {}}>{lang === "ru" ? "Сделать оффер" : "Make Offer"}</Btn>
          </div>
          <p className="text-[10px] text-mut2 leading-snug">{lang === "ru" ? "Покупка облагается комиссией и роялти создателя. Фракционные предметы требуют соответствия фракции." : "Purchases incur the marketplace fee and creator royalty. Faction items require faction alignment."}</p>
        </div>
      </Panel>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex items-center justify-between text-[11px]"><span className="text-mut">{k}</span><span className="font-mono tnum text-ink">{v}</span></div>;
}
