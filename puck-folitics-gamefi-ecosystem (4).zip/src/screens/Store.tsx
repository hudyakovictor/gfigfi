import { useState, useEffect } from "react";
import { useApp } from "../store";
import { tx } from "../i18n";
import { STORE_GROUPS, STORE_ITEMS, VIP_TIERS, type StoreGroup } from "../data";
import { Panel, TONE, Bar, Tag, Btn } from "../components/ui";
import { ScreenHeader } from "../components/widgets";
import { cn } from "../utils/cn";

function useCountdown(seconds: number) {
  const [left, setLeft] = useState(seconds);
  useEffect(() => {
    const iv = setInterval(() => setLeft((l) => (l <= 0 ? seconds : l - 1)), 1000);
    return () => clearInterval(iv);
  }, [seconds]);
  const h = Math.floor(left / 3600), m = Math.floor((left % 3600) / 60), s = left % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function Store() {
  const { player, lang, t, toast, setPlayer } = useApp();
  const [group, setGroup] = useState<StoreGroup>("currency");
  const items = STORE_ITEMS.filter((i) => i.group === group);
  const countdown = useCountdown(8 * 3600 + 42 * 60 + 13);

  const nextVip = VIP_TIERS.find((v) => v.spend > player.vipSpend);
  const curVip = [...VIP_TIERS].reverse().find((v) => v.spend <= player.vipSpend) ?? VIP_TIERS[0];

  return (
    <div className="p-4 max-w-[1500px] mx-auto space-y-4">
      <ScreenHeader icon="💎" tone="pink" title={t("Store")}
        sub={lang === "ru" ? "Поддержи цивилизацию (и себя). Пропуски, бустеры, лимитированные дропы и VIP. Плати за скорость — не за победу." : "Fund the civilization (and yourself). Passes, boosters, limited drops & VIP. Pay for speed — not for victory."}
        actions={<Tag tone="gold" glow>⭐ {player.vipTier}</Tag>}
      />

      {/* featured hero */}
      <div className="grid md:grid-cols-2 gap-3">
        <Panel className="p-4 relative overflow-hidden" tone="gold">
          <div className="absolute inset-0 shimmer opacity-30 pointer-events-none" />
          <div className="relative">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-2xl">🎫</span>
              <h3 className="text-[15px] font-bold text-ink">{lang === "ru" ? "Бычий Сезонный Пропуск" : "Bull Season Pass"}</h3>
              <Tag tone="pink" glow>{lang === "ru" ? "ХИТ" : "POPULAR"}</Tag>
            </div>
            <p className="text-[11.5px] text-mut leading-snug mb-2.5">{lang === "ru" ? "Открой 100+ наград сезона, эксклюзивные устройства и косметику. Лучшее соотношение цена/ценность." : "Unlock 100+ season rewards, exclusive devices & cosmetics. Best value-for-money in The Fold."}</p>
            <div className="flex items-center gap-2 mb-2">
              <Bar value={64} tone="gold" />
              <span className="text-[10px] font-mono text-mut">64% {lang === "ru" ? "собрано" : "claimed"}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black text-acid">$14.99</span>
                <span className="text-[12px] text-mut line-through">$24.99</span>
              </div>
              <Btn tone="gold" onClick={() => toast(lang === "ru" ? "Пропуск активирован. Сезон твой." : "Pass activated. The season is yours.", "gold")}>{t("Buy")} →</Btn>
            </div>
          </div>
        </Panel>

        <Panel className="p-4 relative overflow-hidden" tone="pink">
          <div className="absolute inset-0 shimmer opacity-30 pointer-events-none" />
          <div className="relative">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-2xl">🔥</span>
              <h3 className="text-[15px] font-bold text-ink">{lang === "ru" ? "Крейтер Основателя" : "Founder Crate"}</h3>
              <Tag tone="pink" glow>{lang === "ru" ? "ОСТАЛОСЬ 217" : "ONLY 217 LEFT"}</Tag>
            </div>
            <p className="text-[11.5px] text-mut leading-snug mb-2.5">{lang === "ru" ? "1 из 1 000. Гарантированный мифический девайс + бейдж основателя навсегда." : "1 of 1,000. Guaranteed mythic device + founder badge forever."}</p>
            <div className="flex items-center gap-2 mb-2">
              <Bar value={78} tone="pink" />
              <span className="text-[10px] font-mono text-mut">783/1000</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black text-acid">$49.99</span>
              </div>
              <Btn tone="pink" onClick={() => toast(lang === "ru" ? "Крейтер открыт! Мифик твой. 🐋" : "Crate opened! Mythic secured. 🐋", "pink")}>{t("Buy")} →</Btn>
            </div>
          </div>
        </Panel>
      </div>

      {/* daily deal countdown */}
      <Panel className="p-3 flex items-center gap-3 flex-wrap" tone="cyan">
        <span className="text-xl">⏱</span>
        <div>
          <div className="text-[12px] font-bold text-ink">{lang === "ru" ? "Ежедневная сделка истекает через" : "Daily deal ends in"}</div>
          <div className="text-[10px] text-mut">{lang === "ru" ? "Yield Multiplier x2 по -40%" : "Yield Multiplier x2 at -40%"}</div>
        </div>
        <div className="font-mono font-bold text-cyan text-lg tnum ml-auto">{countdown}</div>
        <Btn size="sm" tone="cyan" onClick={() => toast(lang === "ru" ? "Сделка забрана!" : "Deal claimed!", "cyan")}>{lang === "ru" ? "Забрать $1.79" : "Claim $1.79"}</Btn>
      </Panel>

      {/* group tabs */}
      <div className="flex gap-1.5 flex-wrap">
        {STORE_GROUPS.map((g) => (
          <button key={g.id} onClick={() => setGroup(g.id)}
            className={cn("inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold uppercase tracking-wide border transition-colors",
              group === g.id ? cn(TONE[g.tone].bg, "text-black border-transparent") : "bg-white/[0.04] text-mut border-edge hover:text-ink")}>
            <span>{g.icon}</span>{tx(g.label, lang)}
          </button>
        ))}
      </div>

      {/* packs */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {items.map((it) => (
          <Panel key={it.id} className={cn("p-3.5 flex flex-col", it.highlight && TONE[it.tone].border)} tone={it.highlight ? it.tone : undefined}>
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="text-[13px] font-bold text-ink leading-tight">{tx(it.name, lang)}</div>
                <div className="text-[10.5px] text-mut mt-0.5">{tx(it.sub, lang)}</div>
              </div>
              {it.tag && <Tag tone={it.tone} glow>{tx(it.tag, lang)}</Tag>}
            </div>
            {it.perks.length > 0 && (
              <ul className="mt-2.5 space-y-1">
                {it.perks.map((p, i) => (
                  <li key={i} className="flex items-center gap-1.5 text-[11px] text-mut">
                    <span className={cn("w-1.5 h-1.5 rounded-full", TONE[it.tone].dot)} />{tx(p, lang)}
                  </li>
                ))}
              </ul>
            )}
            <div className="mt-auto pt-3 flex items-center justify-between">
              <div className="flex items-baseline gap-1.5">
                <span className="text-lg font-black text-acid">${it.price}</span>
                {it.oldPrice && <span className="text-[11px] text-mut line-through">${it.oldPrice}</span>}
              </div>
              <Btn size="sm" tone={it.tone} onClick={() => {
                toast(lang === "ru" ? `Куплено: ${tx(it.name, lang)}. Спасибо, что спонсируешь цивилизацию. 💸` : `Purchased: ${tx(it.name, lang)}. Thanks for funding the civilization. 💸`, it.tone);
                if (it.group === "currency") setPlayer({ vipSpend: player.vipSpend + it.price });
              }}>{it.best ? (lang === "ru" ? "Лучшее!" : "Best!") : t("Buy")}</Btn>
            </div>
          </Panel>
        ))}
      </div>

      {/* Inner Circle subscription */}
      <Panel className="p-4 relative overflow-hidden" tone="violet">
        <div className="absolute inset-0 shimmer opacity-25 pointer-events-none" />
        <div className="relative flex items-center gap-3 flex-wrap">
          <span className="text-2xl">👑</span>
          <div className="min-w-[180px]">
            <h3 className="text-[14px] font-bold text-ink">{lang === "ru" ? "Внутренний Круг" : "The Inner Circle"}</h3>
            <p className="text-[11px] text-mut">{lang === "ru" ? "Подписка $9.99/мес · +15% доход, скидки на страховки, без рекламы" : "$9.99/mo · +15% yield, insurance discounts, no ads"}</p>
          </div>
          <div className="flex-1" />
          <div className="flex gap-2">
            <Btn tone="violet" onClick={() => toast(lang === "ru" ? "Добро пожаловать в Круг." : "Welcome to the Circle.", "violet")}>{lang === "ru" ? "Подписаться" : "Subscribe"}</Btn>
            <Btn size="sm" variant="outline" tone="violet" onClick={() => toast(lang === "ru" ? "7 дней триала активировано." : "7-day trial activated.")}>{lang === "ru" ? "Триал 7 дней" : "7-day trial"}</Btn>
          </div>
        </div>
      </Panel>

      {/* VIP ladder */}
      <Panel className="p-3.5">
        <h3 className="text-[12px] font-semibold uppercase tracking-wide text-ink mb-1 flex items-center gap-2"><span className="text-gold">🏆</span> {lang === "ru" ? "VIP прогрессия" : "VIP Progression"}</h3>
        <p className="text-[10px] text-mut mb-3">{lang === "ru" ? "Ты" : "You are"} <span className="text-gold font-bold">{tx(curVip.tier, lang)}</span> · ${player.vipSpend} {lang === "ru" ? "потрачено" : "spent"}{nextVip ? ` · ${lang === "ru" ? "до" : "to"} ${tx(nextVip.tier, lang)}: $${nextVip.spend - player.vipSpend}` : ""}</p>
        <div className="grid sm:grid-cols-5 gap-2">
          {VIP_TIERS.map((v) => {
            const reached = player.vipSpend >= v.spend;
            const isYou = v.you;
            return (
              <div key={v.tier.en} className={cn("rounded-lg border p-2.5 text-center relative", reached ? cn(TONE[v.tone].border, TONE[v.tone].soft) : "border-edge opacity-60")}>
                {isYou && <span className="absolute -top-1.5 right-1.5 text-[8px] bg-acid text-black font-bold px-1 rounded">{lang === "ru" ? "ТЫ" : "YOU"}</span>}
                <div className={cn("text-[12px] font-bold", TONE[v.tone].text)}>{tx(v.tier, lang)}</div>
                <div className="text-[10px] font-mono text-mut">${v.spend}+</div>
                <div className="text-[9px] text-mut2 mt-1 leading-snug min-h-[26px]">{tx(v.perk, lang)}</div>
                {reached ? <span className="text-[9px] text-ok font-bold">✓</span> : <span className="text-[9px] text-mut2">{lang === "ru" ? "закрыто" : "locked"}</span>}
              </div>
            );
          })}
        </div>
      </Panel>
    </div>
  );
}
