import { useApp } from "../store";
import { tx } from "../i18n";
import { FACTIONS } from "../data";
import { Panel, TONE, Bar, Tag, Btn, type Tone } from "../components/ui";
import { ScreenHeader } from "../components/widgets";
import { cn } from "../utils/cn";

export function Factions() {
  const { player, setPlayer, lang, t, toast } = useApp();
  const list = Object.values(FACTIONS);

  return (
    <div className="p-4 max-w-[1500px] mx-auto space-y-4">
      <ScreenHeader icon="⚑" tone="pink" title={t("Factions")}
        sub={lang === "ru" ? "Четыре силы The Fold. Каркас для нескольких жанров сразу: стратегия, экономика, MMO-lite, дипломатия, PvPvE." : "Four forces of The Fold. A spine for several genres at once: strategy, economy, MMO-lite, diplomacy, PvPvE."} />

      <div className="grid sm:grid-cols-2 gap-4">
        {list.map((f) => {
          const active = player.faction === f.id;
          return (
            <Panel key={f.id} className={cn("p-4", active && TONE[f.tone].border + " " + TONE[f.tone].soft)} tone={active ? f.tone : undefined}>
              <div className="flex items-start gap-3">
                <div className={cn("w-14 h-14 rounded-xl flex items-center justify-center text-2xl border shrink-0", TONE[f.tone].soft, TONE[f.tone].border)}>{f.icon}</div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-[15px] font-bold text-ink">{tx(f.name, lang)}</h3>
                    <span className={cn("text-[9px] font-bold uppercase px-1.5 py-0.5 rounded", TONE[f.tone].soft, TONE[f.tone].text)}>{tx(f.tag, lang)}</span>
                    {active && <Tag tone={f.tone} dot glow>{lang === "ru" ? "твоя" : "yours"}</Tag>}
                  </div>
                  <p className="text-[11px] italic text-mut mt-1 leading-snug">“{tx(f.motto, lang)}”</p>
                </div>
              </div>
              <p className="text-[12px] text-mut mt-2.5 leading-snug">{tx(f.desc, lang)}</p>
              <div className="mt-3 space-y-1">
                {f.play.map((p, i) => (
                  <div key={i} className="flex items-center gap-2 text-[11px]">
                    <span className={cn("w-1.5 h-1.5 rounded-full", TONE[f.tone].dot)} />
                    <span className="text-mut">{tx(p, lang)}</span>
                  </div>
                ))}
              </div>
              <div className="mt-3 flex items-center gap-2">
                <span className="text-[10px] uppercase text-mut tracking-wider w-20">{t("Reputation")}</span>
                <Bar value={f.rep} tone={f.tone} className="flex-1" />
                <span className="text-[11px] font-mono tnum text-mut w-8 text-right">{f.rep}</span>
              </div>
              <div className="mt-3">
                <Btn size="sm" tone={f.tone} variant={active ? "outline" : "solid"} full
                  disabled={active}
                  onClick={() => {
                    setPlayer({ faction: f.id });
                    toast(lang === "ru" ? `Примкнул к ${tx(f.name, lang)}.` : `Aligned with ${tx(f.name, lang)}.`, f.tone);
                  }}>
                  {active ? (lang === "ru" ? "✓ Активная фракция" : "✓ Active Faction") : (lang === "ru" ? "Примкнуть" : "Align")}
                </Btn>
              </div>
            </Panel>
          );
        })}
      </div>

      {/* standing */}
      <Panel className="p-3.5">
        <h3 className="text-[12px] font-semibold uppercase tracking-wide text-ink mb-3 flex items-center gap-2"><span className="text-violet">📊</span> {lang === "ru" ? "Твоё положение во всех фракциях" : "Your Standing Across Factions"}</h3>
        <div className="grid sm:grid-cols-2 gap-x-6 gap-y-2.5">
          {list.map((f) => (
            <div key={f.id}>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="flex items-center gap-1.5 text-ink font-medium"><span className={cn("w-1.5 h-1.5 rounded-full", TONE[f.tone].dot)} />{tx(f.name, lang)}</span>
                <span className="font-mono tnum text-mut">{f.rep < 30 ? (lang === "ru" ? "враждебно" : "hostile") : f.rep < 50 ? (lang === "ru" ? "нейтрально" : "neutral") : f.rep < 75 ? (lang === "ru" ? "уважаем" : "respected") : (lang === "ru" ? "союзник" : "allied")}</span>
              </div>
              <Bar value={f.rep} tone={f.tone as Tone} height="h-2" />
            </div>
          ))}
        </div>
        <p className="text-[10px] text-mut2 mt-3 leading-snug">{lang === "ru" ? "Смена фракции вызывает мягкий сброс части влияния. Фракционные активы требуют соответствия." : "Switching factions triggers a soft reset of some influence. Faction-locked assets require alignment."}</p>
      </Panel>
    </div>
  );
}
