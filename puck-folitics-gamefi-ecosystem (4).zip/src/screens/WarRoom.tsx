import { useState, useEffect, useMemo } from "react";
import { useApp } from "../store";
import { tx, type Tx } from "../i18n";
import {
  SPIN_CARDS, buildSignal, resolveSpin, readIntel, computeEdge, HELPERS, TIER_META,
  DEVICE_LINES, type SpinResult,
} from "../data";
import { Panel, TONE, Bar, Tag, Btn, Ring, fmtNum, type Tone } from "../components/ui";
import { ScreenHeader } from "../components/widgets";
import { cn } from "../utils/cn";

const STAKES = [1000, 5000, 20000, 0]; // 0 = all-in (capped)
const ROUND_MS = 9000;

export function WarRoom() {
  const { market, player, lang, applySpin, toast, setHelpOpen, setView, equippedDevices } = useApp();
  const vol = useMemo(() => Math.max(2.4, Math.abs(market.btcChg) * 1.5 + 3), [market.btcChg]);
  const signal = useMemo(() => buildSignal(market.btcChg, vol), [market.btcChg, vol]);
  const intel = useMemo(() => readIntel(market.btcChg, vol, market.sentiment), [market.btcChg, vol, market.sentiment]);

  const [cardId, setCardId] = useState("fundamental");
  const [stakeIdx, setStakeIdx] = useState(1);
  const [hedge, setHedge] = useState(false);
  const [activeH, setActiveH] = useState<string[]>([]);
  const [phase, setPhase] = useState<"idle" | "spin" | "resolved">("idle");
  const [left, setLeft] = useState(ROUND_MS);
  const [result, setResult] = useState<SpinResult | null>(null);
  const [log, setLog] = useState<{ win: boolean; icon: string; delta: number; edge: number; aligned: boolean }[]>([]);

  // ---- LOADOUT: equipped devices give real War Room bonuses ----
  const loadout = useMemo(() => {
    let deviceEdge = 0, deviceIntel = 0, lossMult = 1, credBoost = 0;
    const parts: { icon: string; name: Tx; effect: Tx; tone: Tone }[] = [];
    for (const d of equippedDevices) {
      const line = DEVICE_LINES.find((l) => l.id === d.line);
      if (!line) continue;
      const e = line.effect;
      if (e.kind === "intel") deviceIntel += e.amount;
      else if (e.kind === "edge") deviceEdge += e.amount;
      else if (e.kind === "influence") deviceEdge += e.amount; // influence → edge too
      else if (e.kind === "defense") lossMult *= (1 - e.amount);
      else if (e.kind === "cred") credBoost += e.amount;
      parts.push({ icon: line.icon, name: line.name, effect: e.text, tone: line.tone });
    }
    return { deviceEdge, deviceIntel, lossMult: Math.max(0.55, lossMult), credBoost, parts };
  }, [equippedDevices]);

  const card = SPIN_CARDS.find((c) => c.id === cardId)!;
  const helpers = HELPERS.filter((h) => activeH.includes(h.id));
  const edge = useMemo(
    () => computeEdge(card, intel, helpers, loadout.deviceEdge, loadout.deviceIntel),
    [card, intel, helpers, loadout.deviceEdge, loadout.deviceIntel]
  );
  const helperCost = helpers.reduce((s, h) => s + h.cost, 0);

  const maxStake = Math.min(player.resources.fold, 50000);
  const stake = STAKES[stakeIdx] === 0 ? maxStake : Math.min(STAKES[stakeIdx], player.resources.fold);
  const potentialWin = Math.round(stake * (hedge ? card.mult * 0.72 - 1 : card.mult - 1));
  const potentialLoss = Math.round(stake * (hedge ? card.lossPct * 0.4 : card.lossPct) * loadout.lossMult);
  const wins = log.filter((l) => l.win).length;
  const cred = player.cred;
  const influOK = player.resources.influence >= helperCost;

  // spin animation timer
  useEffect(() => {
    if (phase !== "spin") return;
    setLeft(ROUND_MS);
    const start = Date.now();
    const iv = setInterval(() => {
      const l = ROUND_MS - (Date.now() - start);
      setLeft(l);
      if (l <= 0) {
        clearInterval(iv);
        finish();
      }
    }, 80);
    return () => clearInterval(iv);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  const finish = () => {
    const res = resolveSpin(card, stake, edge, hedge, loadout.lossMult);
    setResult(res);
    applySpin(res.delta, res.credDelta + (res.win ? loadout.credBoost : 0));
    setLog((p) => [{ win: res.win, icon: card.icon, delta: res.delta, edge: res.edgeProb, aligned: edge.aligned }, ...p].slice(0, 7));
    setPhase("resolved");
    if (res.win) toast((lang === "ru" ? "Зашло! +" : "Landed! +") + fmtNum(res.delta), "ok");
    else toast((lang === "ru" ? "Мимо, но ты не рекся: " : "Missed, not rekt: ") + fmtNum(res.delta), "danger");
  };

  const launch = () => {
    if (stake <= 0) { toast(lang === "ru" ? "Нет $FOLD на ставку." : "No $FOLD to stake.", "danger"); return; }
    if (!influOK) { toast(lang === "ru" ? "Мало влияния на помощников." : "Not enough Influence for helpers.", "danger"); return; }
    setResult(null);
    setPhase("spin");
  };
  const again = () => { setPhase("idle"); setResult(null); };
  const toggleH = (id: string) => setActiveH((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));

  return (
    <div className="p-4 max-w-[1500px] mx-auto space-y-4">
      <ScreenHeader icon="🎩" tone="pink" title={lang === "ru" ? "War Room · Спин-Терминал" : "War Room · The Spin Terminal"}
        sub={lang === "ru" ? "Это НЕ казино. Ты строишь перевес: читаешь реальный рынок, ставишь помощников, хеджируешь. Скилл побеждает." : "This is NOT a casino. You build an edge: read the real market, deploy helpers, hedge. Skill wins."}
        actions={<>
          <Tag tone={market.live ? "ok" : "warn"} dot glow>{market.live ? "● LIVE" : "● SIM"}</Tag>
          <Tag tone={cred > 60 ? "ok" : cred > 35 ? "warn" : "danger"} dot>{lang === "ru" ? "Кредо" : "Cred"} {cred}</Tag>
        </>}
      />

      {/* ===== 3-STEP EXPLAINER (always visible — kills the "I don't get it") ===== */}
      <Panel className="p-3">
        <div className="grid sm:grid-cols-3 gap-2">
          {[
            { n: "1", icon: "📡", t: { en: "Read the tape", ru: "Прочти ленту" }, d: { en: "Intel below shows real market lean.", ru: "Интел внизу показывает реальный уклон рынка." }, tone: "cyan" },
            { n: "2", icon: "🎯", t: { en: "Match it & build edge", ru: "Совпади и строй перевес" }, d: { en: "Aligned card + helpers = higher win%.", ru: "Совпадающая карта + помощники = выше шанс." }, tone: "gold" },
            { n: "3", icon: "🛡", t: { en: "Can't get wiped", ru: "Не рекнешься" }, d: { en: "Losses are partial. Hedge caps them.", ru: "Потери частичные. Хедж их режет." }, tone: "ok" },
          ].map((s) => (
            <div key={s.n} className="flex items-center gap-2.5 rounded-lg border border-edge p-2">
              <span className={cn("w-7 h-7 rounded-md flex items-center justify-center text-sm font-bold shrink-0", TONE[s.tone as Tone].soft, TONE[s.tone as Tone].text)}>{s.n}</span>
              <div className="min-w-0">
                <div className="text-[12px] font-bold text-ink flex items-center gap-1"><span>{s.icon}</span>{tx(s.t, lang)}</div>
                <div className="text-[10.5px] text-mut leading-snug">{tx(s.d, lang)}</div>
              </div>
            </div>
          ))}
        </div>
      </Panel>

      <div className="grid lg:grid-cols-3 gap-4">
        {/* ===== MAIN COLUMN ===== */}
        <div className="lg:col-span-2 space-y-4">
          {/* BREAKING + INTEL */}
          <Panel className="p-4 relative overflow-hidden" tone={intel.lean === "up" ? "ok" : intel.lean === "down" ? "danger" : intel.lean === "volatile" ? "pink" : "warn"}>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-1.5 py-0.5 rounded bg-danger text-white text-[9px] font-black uppercase tracking-wider blink">{lang === "ru" ? "СРОЧНО" : "BREAKING"}</span>
              <span className="text-[11px] uppercase tracking-wider text-mut">{signal.asset} {signal.realChg >= 0 ? "+" : ""}{signal.realChg.toFixed(2)}% · {lang === "ru" ? "вол" : "vol"} {vol.toFixed(1)}%</span>
            </div>
            <p className="text-[15px] sm:text-[16px] font-bold text-ink leading-snug mb-3">{tx(signal.headline, lang)}</p>

            {/* INTEL READ — the skill hook */}
            <div className="rounded-xl bg-black/30 border border-edge p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-lg">📡</span>
                  <div>
                    <div className="text-[9px] uppercase tracking-wider text-mut">{lang === "ru" ? "Интел · твой анализ рынка" : "Intel · your read of the market"}</div>
                    <div className="text-[14px] font-bold text-ink">{tx(intel.label, lang)}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[9px] uppercase text-mut">{lang === "ru" ? "Уверенность" : "Confidence"}</div>
                  <div className={cn("text-lg font-black tnum", intel.confidence > 0.66 ? "text-ok" : intel.confidence > 0.45 ? "text-gold" : "text-warn")}>{Math.round(intel.confidence * 100)}%</div>
                </div>
              </div>
              <Bar value={intel.confidence * 100} tone={intel.confidence > 0.66 ? "ok" : "gold"} />
              <div className="flex items-center justify-between mt-2 text-[10.5px] gap-2">
                <Tag tone={intel.lean === "up" ? "ok" : intel.lean === "down" ? "danger" : intel.lean === "volatile" ? "pink" : "warn"} dot>{tx(intel.label, lang)}</Tag>
                <span className="text-mut leading-snug">{tx(intel.tip, lang)}</span>
                <span className="text-mut font-mono shrink-0">{lang === "ru" ? "сила" : "strength"} {intel.strength}</span>
              </div>
            </div>
          </Panel>

          {/* PICK CARD + live EDGE */}
          <Panel className="p-4">
            <div className="flex items-center justify-between mb-2.5">
              <h3 className="text-[12px] font-semibold uppercase tracking-wide text-ink">{lang === "ru" ? "Выбери карту-нарратив" : "Pick a narrative card"}</h3>
              <Tag tone={edge.aligned ? "ok" : "warn"} dot glow>{edge.aligned ? (lang === "ru" ? "✓ Совпадает с рынком" : "✓ Matches market") : (lang === "ru" ? "⚠ Идёшь против тренда" : "⚠ Against the trend")}</Tag>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {SPIN_CARDS.map((c) => {
                const sel = cardId === c.id && phase === "idle";
                const tm = TIER_META[c.tier];
                return (
                  <button key={c.id} disabled={phase !== "idle"} onClick={() => setCardId(c.id)}
                    className={cn("text-left rounded-xl border p-2.5 transition-all disabled:opacity-60",
                      sel ? cn(TONE[c.tone].border, TONE[c.tone].soft, "scale-[1.02]") : "border-edge hover:border-edge2")}>
                    <div className="flex items-center justify-between">
                      <span className="text-lg">{c.icon}</span>
                      <span className={cn("text-[8px] font-bold uppercase px-1 rounded", TONE[tm.tone].soft, TONE[tm.tone].text)}>{tx(tm.label, lang)}</span>
                    </div>
                    <div className={cn("text-[12px] font-bold mt-1 leading-tight", TONE[c.tone].text)}>{tx(c.name, lang)}</div>
                    <div className="flex items-center gap-1.5 mt-1 text-[9px] font-mono">
                      <span className="text-ok">+{Math.round((c.mult - 1) * 100)}%</span>
                      <span className="text-danger">-{Math.round(c.lossPct * 100)}%</span>
                    </div>
                  </button>
                );
              })}
            </div>
            <p className="text-[10.5px] text-mut2 mt-2 leading-snug italic">"{tx(card.flavour, lang)}"</p>
          </Panel>

          {/* HELPERS */}
          <Panel className="p-4">
            <div className="flex items-center justify-between mb-2.5">
              <h3 className="text-[12px] font-semibold uppercase tracking-wide text-ink">{lang === "ru" ? "Помощники (спин-команда)" : "Helpers (spin team)"}</h3>
              <span className="text-[10px] text-mut font-mono">{lang === "ru" ? "Влияние" : "Influence"}: <span className={influOK ? "text-violet" : "text-danger"}>{player.resources.influence}</span> · {lang === "ru" ? "цена" : "cost"} {helperCost}</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {HELPERS.map((h) => {
                const on = activeH.includes(h.id);
                const useful = h.helps === card.winWhen;
                return (
                  <button key={h.id} disabled={phase !== "idle"} onClick={() => toggleH(h.id)}
                    className={cn("rounded-lg border p-2 text-center transition-all disabled:opacity-60 relative",
                      on ? cn(TONE[h.tone].border, TONE[h.tone].soft) : "border-edge hover:border-edge2", useful && "ring-1 ring-acid/40")}>
                    {useful && <span className="absolute -top-1.5 -right-1.5 text-[8px] bg-acid text-black font-bold px-1 rounded">{lang === "ru" ? "+" : "FIT"}</span>}
                    <div className="text-lg">{h.icon}</div>
                    <div className={cn("text-[10.5px] font-bold leading-tight", TONE[h.tone].text)}>{tx(h.name, lang)}</div>
                    <div className="text-[9px] font-mono text-ok">+{Math.round(h.bonus * 100)}%</div>
                    <div className="text-[9px] font-mono text-mut">{h.cost} {lang === "ru" ? "влияния" : "inf"}</div>
                  </button>
                );
              })}
            </div>
            <p className="text-[10px] text-mut2 mt-2 leading-snug">{lang === "ru" ? "Помощник с меткой FITboostяет именно выбранную карту. Остальные бесполезны — снял не тот и зря тратишь влияние." : "A helper marked FIT boosts your selected card. Others do nothing — wrong pick wastes Influence."}</p>
          </Panel>

          {/* STAKE + HEDGE + LAUNCH */}
          <Panel className="p-4" tone={phase === "spin" ? "pink" : undefined}>
            {phase === "idle" && (
              <>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-[12px] font-semibold uppercase tracking-wide text-ink">{lang === "ru" ? "Ставка" : "Stake"}</h3>
                  <span className="text-[11px] text-mut font-mono">{lang === "ru" ? "Баланс" : "Balance"}: <span className="text-acid">{fmtNum(player.resources.fold)}</span></span>
                </div>
                <div className="flex gap-1.5 flex-wrap mb-3">
                  {STAKES.map((s, i) => (
                    <button key={i} onClick={() => setStakeIdx(i)}
                      className={cn("px-3 py-1.5 rounded-lg text-[11px] font-bold border transition-colors",
                        stakeIdx === i ? "bg-acid text-black border-acid" : "bg-white/[0.04] text-mut border-edge hover:text-ink")}>
                      {s === 0 ? (lang === "ru" ? "ВА-БАНК" : "ALL-IN") : fmtNum(s)}
                    </button>
                  ))}
                </div>

                {/* HEDGE toggle */}
                <button onClick={() => setHedge((h) => !h)}
                  className={cn("w-full flex items-center gap-3 rounded-lg border p-2.5 mb-3 transition-colors", hedge ? "border-ok bg-ok/10" : "border-edge")}>
                  <span className={cn("w-9 h-5 rounded-full p-0.5 transition-colors shrink-0", hedge ? "bg-ok" : "bg-mut2")}><span className={cn("block w-4 h-4 rounded-full bg-base transition-transform", hedge && "translate-x-4")} /></span>
                  <div className="text-left">
                    <div className="text-[12px] font-bold text-ink flex items-center gap-1.5">🛡 {lang === "ru" ? "Хедж (две клетки)" : "Hedge (two cells)"}</div>
                    <div className="text-[10px] text-mut">{lang === "ru" ? "Раздели ставку: выигрыш меньше, но потери режутся до ~15%." : "Split stake: smaller win, but losses cut to ~15%."}</div>
                  </div>
                </button>

                {/* LAUNCH with live edge */}
                <div className="rounded-xl border border-edge bg-black/20 p-3 mb-3">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[11px] uppercase tracking-wider text-mut">{lang === "ru" ? "Твой перевес (edge)" : "Your edge"}</span>
                    <span className={cn("text-2xl font-black tnum", edge.prob > 0.6 ? "text-ok" : edge.prob > 0.48 ? "text-gold" : "text-danger")}>{Math.round(edge.prob * 100)}%</span>
                  </div>
                  <Bar value={edge.prob * 100} tone={edge.prob > 0.6 ? "ok" : "gold"} height="h-2" />
                  <div className="grid grid-cols-4 gap-2 mt-2 text-center">
                    <EdgeBit l={lang === "ru" ? "База" : "Base"} v={Math.round(edge.base * 100)} tone="mut" />
                    <EdgeBit l={lang === "ru" ? "Интел" : "Intel"} v={(edge.intelBonus * 100 >= 0 ? "+" : "") + Math.round(edge.intelBonus * 100)} tone={edge.intelBonus >= 0 ? "ok" : "danger"} />
                    <EdgeBit l={lang === "ru" ? "Команда" : "Team"} v={"+" + Math.round(edge.helperBonus * 100)} tone="gold" />
                    <EdgeBit l={lang === "ru" ? "Девайсы" : "Gear"} v={"+" + Math.round(loadout.deviceEdge * 100)} tone="violet" />
                  </div>
                  <div className="flex items-center justify-between mt-2 text-[11px] pt-2 border-t border-edge">
                    <span className="text-ok font-mono">{lang === "ru" ? "Выигрыш" : "Win"}: +{fmtNum(potentialWin)}</span>
                    <span className="text-danger font-mono">{lang === "ru" ? "Потеря" : "Loss"}: -{fmtNum(potentialLoss)}</span>
                  </div>
                </div>

                <Btn tone="pink" full size="md" onClick={launch} className="text-[13px] py-2.5">
                  🎲 {lang === "ru" ? `ЗАПУСТИТЬ · ${fmtNum(stake)} $FOLD` : `SPIN IT · ${fmtNum(stake)} $FOLD`}
                </Btn>
              </>
            )}

            {phase === "spin" && (
              <div className="flex items-center gap-4">
                <Ring value={(left / ROUND_MS) * 100} tone="pink" size={64} label="SPIN" />
                <div className="flex-1 min-w-0">
                  <div className="text-[11px] uppercase tracking-wider text-mut">{lang === "ru" ? "Спин запущен · edge" : "Spinning · edge"} {Math.round(edge.prob * 100)}%</div>
                  <div className="text-[15px] font-bold text-ink flex items-center gap-1.5">{card.icon} {tx(card.name, lang)}</div>
                  <div className="text-[11px] text-mut font-mono">{lang === "ru" ? "Рынок решает судьбу…" : "Market decides your fate…"}</div>
                </div>
                <div className="text-2xl font-black tnum text-pink">{(left / 1000).toFixed(1)}<span className="text-[12px] text-mut">s</span></div>
              </div>
            )}

            {phase === "resolved" && result && (
              <div className="rounded-xl border p-3" style={{ borderColor: result.win ? "var(--color-ok)" : "var(--color-danger)" }}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={cn("px-2 py-0.5 rounded text-[10px] font-black uppercase", result.win ? "bg-ok text-black" : "bg-danger text-white")}>{result.win ? (lang === "ru" ? "ЗАШЛО" : "LANDED") : (lang === "ru" ? "МИМО" : "MISSED")}</span>
                    <span className="text-[11px] text-mut">{lang === "ru" ? "Твой перевес был" : "Your edge was"} <span className="font-mono font-bold text-ink">{Math.round(result.edgeProb * 100)}%</span></span>
                  </div>
                  <span className={cn("text-xl font-black tnum", result.win ? "text-ok" : "text-danger")}>{result.delta >= 0 ? "+" : ""}{fmtNum(result.delta)}</span>
                </div>
                <p className="text-[12px] text-mut mt-2 italic leading-snug">"{tx(result.line, lang)}"</p>
                <div className="mt-2 rounded-lg bg-acid/5 border border-acid/20 p-2 flex items-start gap-2">
                  <span className="text-sm">💡</span>
                  <p className="text-[11px] text-ink leading-snug">{tx(result.lesson, lang)}</p>
                </div>
                <Btn tone={result.win ? "ok" : "danger"} variant="outline" size="sm" className="mt-3" onClick={again}>{lang === "ru" ? "Следующий раунд →" : "Next round →"}</Btn>
              </div>
            )}
          </Panel>
        </div>

        {/* ===== SIDE COLUMN ===== */}
        <div className="space-y-4">
          {/* cred */}
          <Panel className="p-4" tone={cred > 60 ? "ok" : cred > 35 ? "warn" : "danger"}>
            <div className="flex items-center gap-3">
              <Ring value={cred} tone={cred > 60 ? "ok" : cred > 35 ? "warn" : "danger"} size={60} label="CRED" />
              <div className="min-w-0">
                <div className="text-[12px] font-bold text-ink">{lang === "ru" ? "Твоё кредо брокера" : "Your broker cred"}</div>
                <div className="text-[10.5px] text-mut leading-snug">{cred > 70 ? (lang === "ru" ? "Тебе верят. Перевес растёт." : "They trust you. Edge grows.") : cred > 40 ? (lang === "ru" ? "Норм. Половина слушает." : "Solid. Half listen.") : (lang === "ru" ? "Ловят на блефе. Восстанавливайся." : "Bluffs get caught. Recover.")}</div>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-3 text-center">
              <Mini v={log.length} l={lang === "ru" ? "Спинов" : "Spins"} />
              <Mini v={wins} l={lang === "ru" ? "Побед" : "Wins"} tone="ok" />
              <Mini v={log.length ? Math.round((wins / log.length) * 100) + "%" : "—"} l={lang === "ru" ? "Винрейт" : "Win%"} tone="gold" />
            </div>
          </Panel>

          {/* ACTIVE LOADOUT — devices give real bonuses HERE */}
          <Panel className="p-3.5" tone="violet">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-[11px] font-semibold uppercase tracking-wide text-ink flex items-center gap-1.5"><span>⚙️</span> {lang === "ru" ? "Активный лоадаут" : "Active Loadout"}</h3>
              <Btn size="sm" variant="ghost" onClick={() => setView("devices")}>{lang === "ru" ? "Сменить" : "Edit"} ›</Btn>
            </div>
            <p className="text-[10px] text-mut mb-2 leading-snug">{lang === "ru" ? "Экипированные девайсы дают бонусы в спине. Это то, ЗАЧЕМ ты их прокачиваешь." : "Equipped devices grant spin bonuses. This is WHY you upgrade them."}</p>
            {loadout.parts.length === 0 ? (
              <p className="text-[11px] text-mut2">{lang === "ru" ? "Ничего не экипировано. Зайди в Devices." : "Nothing equipped. Go to Devices."}</p>
            ) : (
              <div className="space-y-1.5">
                {loadout.parts.map((p, i) => (
                  <div key={i} className="flex items-center gap-2 text-[11px]">
                    <span className={cn("w-6 h-6 rounded-md flex items-center justify-center text-sm shrink-0 border", TONE[p.tone].soft, TONE[p.tone].border)}>{p.icon}</span>
                    <span className="text-ink font-medium flex-1 truncate">{tx(p.name, lang)}</span>
                    <span className={cn("text-[10px] font-mono", TONE[p.tone].text)}>{tx(p.effect, lang)}</span>
                  </div>
                ))}
              </div>
            )}
            <div className="flex flex-wrap gap-1.5 mt-2.5 pt-2 border-t border-edge">
              {loadout.deviceEdge > 0 && <Tag tone="acid">+{Math.round(loadout.deviceEdge * 100)}% {lang === "ru" ? "перевес" : "edge"}</Tag>}
              {loadout.deviceIntel > 0 && <Tag tone="cyan">+{Math.round(loadout.deviceIntel * 100)}% {lang === "ru" ? "интел" : "intel"}</Tag>}
              {loadout.lossMult < 1 && <Tag tone="ok">-{Math.round((1 - loadout.lossMult) * 100)}% {lang === "ru" ? "потери" : "loss"}</Tag>}
              {loadout.credBoost > 0 && <Tag tone="violet">+{loadout.credBoost} {lang === "ru" ? "кредо" : "cred"}</Tag>}
            </div>
          </Panel>

          {/* honest disclaimer: not a casino */}
          <Panel className="p-3.5" tone="cyan">
            <h3 className="text-[11px] font-semibold uppercase tracking-wide text-ink mb-1.5 flex items-center gap-1.5"><span>⚖️</span> {lang === "ru" ? "Честно про риск" : "Honest about risk"}</h3>
            <ul className="space-y-1 text-[11px] text-mut">
              <li>✓ {lang === "ru" ? "Потеря по умолчанию — часть ставки, а не всё." : "Default loss is a fraction, never all."}</li>
              <li>✓ {lang === "ru" ? "Хедж режет потери до ~15%." : "Hedge cuts losses to ~15%."}</li>
              <li>✓ {lang === "ru" ? "Совпадая с рынком, ты побеждаешь чаще 60%." : "Aligned with the market, you win 60%+."}</li>
              <li>✓ {lang === "ru" ? "Дикие карты (розовые) — для смелых, не для новичков." : "Wild (pink) cards are for the bold, not beginners."}</li>
            </ul>
            <p className="text-[10px] text-mut2 mt-2 leading-snug">{lang === "ru" ? "Это игра на скилл чтения рынка, а не ставки на удачу. Чем лучше читаешь — тем выше edge." : "This is a market-reading skill game, not a luck bet. Better reading = higher edge."}</p>
          </Panel>

          {/* log */}
          <Panel className="p-3.5">
            <h3 className="text-[11px] font-semibold uppercase tracking-wide text-ink mb-2">{lang === "ru" ? "Журнал (учись на нём)" : "Log (learn from it)"}</h3>
            {log.length === 0 ? (
              <p className="text-[11px] text-mut2">{lang === "ru" ? "Запусти первый спин." : "Launch your first spin."}</p>
            ) : (
              <div className="space-y-1">
                {log.map((l, i) => (
                  <div key={i} className="flex items-center gap-2 text-[11px] py-1 border-b border-edge/40 last:border-0">
                    <span>{l.icon}</span>
                    <span className={cn("font-bold w-9", l.win ? "text-ok" : "text-danger")}>{l.win ? "WIN" : "MISS"}</span>
                    <span className="text-mut font-mono">{lang === "ru" ? "edge" : "edge"} {Math.round(l.edge * 100)}%</span>
                    <span className={cn("ml-auto font-mono tnum font-bold", l.win ? "text-ok" : "text-danger")}>{l.delta >= 0 ? "+" : ""}{fmtNum(l.delta)}</span>
                  </div>
                ))}
              </div>
            )}
          </Panel>

          {/* help */}
          <Panel className="p-3.5">
            <h3 className="text-[11px] font-semibold uppercase tracking-wide text-ink mb-1.5">{lang === "ru" ? "Запутался?" : "Confused?"}</h3>
            <p className="text-[11px] text-mut leading-snug mb-2.5">{lang === "ru" ? "Перечитай короткое объяснение игры — там всё простым языком." : "Re-read the short game explainer — plain language, no jargon."}</p>
            <div className="flex gap-2">
              <Btn size="sm" variant="outline" tone="acid" full onClick={() => setHelpOpen(true)}>❓ {lang === "ru" ? "Как играть" : "How to play"}</Btn>
              <Btn size="sm" variant="ghost" onClick={() => setView("command")}>{lang === "ru" ? "Дашборд" : "Dashboard"}</Btn>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function Mini({ v, l, tone }: { v: number | string; l: string; tone?: Tone }) {
  return (
    <div className="rounded-md bg-black/20 py-1.5">
      <div className={cn("text-[14px] font-bold tnum", tone ? TONE[tone].text : "text-ink")}>{v}</div>
      <div className="text-[8px] uppercase text-mut">{l}</div>
    </div>
  );
}

function EdgeBit({ l, v, tone }: { l: string; v: number | string; tone: Tone }) {
  return (
    <div className="rounded-md bg-black/20 py-1">
      <div className={cn("text-[12px] font-bold tnum", TONE[tone].text)}>{v}%</div>
      <div className="text-[8px] uppercase text-mut">{l}</div>
    </div>
  );
}
