import {
  createContext, useContext, useState, useEffect, useCallback, useMemo, type ReactNode,
} from "react";
import { type Lang, makeT } from "./i18n";
import { simulateMarket, fetchMarket, type MarketData, buildNews } from "./lib/market";
import { DEVICES, RANKS, MODULE_META, type Device, type FactionId } from "./data";

export type ViewId =
  | "command" | "warroom" | "fold" | "devices"
  | "marketplace" | "factions" | "store";

export interface Toast { id: number; text: string; tone: string; }

interface Player {
  name: string; handle: string; xp: number; faction: FactionId;
  season: string; vipTier: string; vipSpend: number; cred: number;
  resources: { fold: number; peg: number; energy: number; energyMax: number; materials: number; influence: number };
  equipped: string[]; // device ids currently in the active loadout (max 4, 1 per line)
}

interface Ctx {
  lang: Lang; setLang: (l: Lang) => void; t: (k: string) => string;
  market: MarketData; news: ReturnType<typeof buildNews>; refreshMarket: () => void;
  view: ViewId; setView: (v: ViewId) => void;
  player: Player; setPlayer: (p: Partial<Player>) => void;
  owned: Device[]; selected: Device | null; selectDevice: (id: string | null) => void;
  upgradePart: (devId: string, key: string) => void;
  toggleEquip: (devId: string) => void;
  equippedDevices: Device[];
  spend: (fold: number) => boolean;
  applySpin: (delta: number, credDelta: number) => void;
  toasts: Toast[]; toast: (text: string, tone?: string) => void;
  helpOpen: boolean; setHelpOpen: (v: boolean) => void;
}

const AppCtx = createContext<Ctx>(null as unknown as Ctx);
export const useApp = () => useContext(AppCtx);

const cloneDevices = (): Device[] =>
  DEVICES.map((d) => ({ ...d, parts: d.parts.map((p) => ({ ...p })) }));

export function AppProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>("en");
  const [market, setMarket] = useState<MarketData>(() => simulateMarket());
  const [view, setView] = useState<ViewId>("command");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [owned, setOwned] = useState<Device[]>(() => cloneDevices());
  const [helpOpen, setHelpOpen] = useState(false);
  const [player, setPlayerState] = useState<Player>({
    name: "Operator Kade", handle: "@kade.fold", xp: 18450, faction: "builders",
    season: "bull", vipTier: "Magnate", vipSpend: 268, cred: 58,
    equipped: ["dev-node-01", "dev-oracle-01", "dev-vault-01", "dev-fud-01"],
    resources: { fold: 142800, peg: 3120, energy: 86, energyMax: 120, materials: 940, influence: 51 },
  });

  const t = useMemo(() => makeT(lang), [lang]);
  const news = useMemo(() => buildNews(market), [market]);

  const toast = useCallback((text: string, tone = "acid") => {
    const id = Date.now() + Math.random();
    setToasts((p) => [...p, { id, text, tone }]);
    setTimeout(() => setToasts((p) => p.filter((x) => x.id !== id)), 3600);
  }, []);

  const refreshMarket = useCallback(() => {
    fetchMarket().then(setMarket).catch(() => setMarket(simulateMarket()));
  }, []);

  useEffect(() => {
    refreshMarket();
    const iv = setInterval(refreshMarket, 45000);
    return () => clearInterval(iv);
  }, [refreshMarket]);

  const setPlayer = useCallback((p: Partial<Player>) =>
    setPlayerState((cur) => ({ ...cur, ...p })), []);

  const spend = useCallback((fold: number) => {
    let ok = false;
    setPlayerState((cur) => {
      if (cur.resources.fold >= fold) {
        ok = true;
        return { ...cur, resources: { ...cur.resources, fold: cur.resources.fold - fold } };
      }
      return cur;
    });
    return ok;
  }, []);

  const applySpin = useCallback((delta: number, credDelta: number) => {
    setPlayerState((cur) => ({
      ...cur,
      cred: Math.max(0, Math.min(100, cur.cred + credDelta)),
      resources: {
        ...cur.resources,
        fold: Math.max(0, cur.resources.fold + delta),
        influence: Math.max(0, Math.min(100, cur.resources.influence + (delta > 0 ? Math.min(2, delta / 2000) : 0))),
      },
    }));
  }, []);

  const selected = useMemo(
    () => owned.find((d) => d.id === selectedId) ?? null,
    [owned, selectedId]
  );

  const selectDevice = useCallback((id: string | null) => setSelectedId(id), []);

  const toggleEquip = useCallback((devId: string) => {
    setPlayerState((cur) => {
      const dev = owned.find((d) => d.id === devId);
      if (!dev) return cur;
      const has = cur.equipped.includes(devId);
      if (has) return { ...cur, equipped: cur.equipped.filter((x) => x !== devId) };
      if (cur.equipped.length >= 4) return cur; // max 4 slots
      // one per line: drop any existing device of the same line
      const filtered = cur.equipped.filter((id) => {
        const od = owned.find((d) => d.id === id);
        return od && od.line !== dev.line;
      });
      return { ...cur, equipped: [...filtered, devId] };
    });
  }, [owned]);

  const equippedDevices = useMemo(
    () => owned.filter((d) => player.equipped.includes(d.id)),
    [owned, player.equipped]
  );

  const upgradePart = useCallback((devId: string, key: string) => {
    const cost = 1200;
    setPlayerState((cur) => {
      if (cur.resources.fold < cost) return cur;
      return { ...cur, resources: { ...cur.resources, fold: cur.resources.fold - cost } };
    });
    setOwned((list) =>
      list.map((d) => {
        if (d.id !== devId) return d;
        return {
          ...d,
          parts: d.parts.map((p) => {
            if (p.key !== key || p.status === "locked" || p.level >= p.max) return p;
            const level = p.level + 1;
            return { ...p, level, status: level >= p.max ? "maxed" : "upgradable" };
          }),
        };
      })
    );
    const dev = owned.find((d) => d.id === devId);
    const part = dev?.parts.find((p) => p.key === key);
    const meta = MODULE_META[key];
    const lbl = meta ? (lang === "ru" ? meta.label.ru : meta.label.en) : key;
    const next = (part?.level ?? 0) + 1;
    if (player.resources.fold < cost) {
      toast(lang === "ru" ? "Недостаточно $FOLD. Магазин ждёт." : "Not enough $FOLD. The Store awaits.", "danger");
      return;
    }
    toast(
      lang === "ru" ? `${lbl} → ур.${next}. Круче, дороже, твоё.` : `${lbl} → Lv.${next}. Stronger, pricier, yours.`,
      "acid"
    );
  }, [toast, lang, owned, player.resources.fold]);

  const value: Ctx = {
    lang, setLang, t, market, news, refreshMarket,
    view, setView, player, setPlayer,
    owned, selected, selectDevice, upgradePart, toggleEquip, equippedDevices,
    spend, applySpin, toasts, toast, helpOpen, setHelpOpen,
  };

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

export { RANKS };
