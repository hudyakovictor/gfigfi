// Bilingual system (EN / RU).
// - Generic UI labels use the `DICT` below (keyed by EN string, value = RU).
// - Satirical / flavor content lives on data objects as {en, ru} pairs
//   so RU can be re-written naturally rather than machine-translated.

export type Lang = "en" | "ru";
export type Tx = { en: string; ru: string };

export const tx = (o: Tx | string, lang: Lang): string => {
  if (typeof o === "string") return o;
  return (lang === "ru" && o.ru) ? o.ru : o.en;
};

// Reusable UI strings. Keep RU punchy & in-character (same attitude, not literal).
export const DICT: Record<string, string> = {
  // Nav
  "Command": "Командный",
  "The Fold": "The Fold",
  "Devices": "Устройства",
  "Marketplace": "Рынок",
  "Vault": "Хранилище",
  "Upgrade Bay": "Модернизация",
  "Infrastructure": "Инфраструктура",
  "Economy": "Экономика",
  "Factions": "Фракции",
  "Governance": "Управление",
  "Store": "Магазин",

  // Common
  "Buy": "Купить",
  "Sell": "Продать",
  "Bid": "Ставка",
  "Offer": "Предложение",
  "Rent": "Аренда",
  "Lease": "Лизинг",
  "Bundle": "Набор",
  "List": "Выставить",
  "Delist": "Снять",
  "Equip": "Установить",
  "Upgrade": "Улучшить",
  "Fuse": "Слить",
  "Insure": "Застраховать",
  "Lend": "Одолжить",
  "Bond": "Заложить",
  "Publish": "Опубликовать",
  "Gift": "Подарить",
  "Burn": "Сжечь",
  "Archive": "В архив",
  "Recycle": "Переработать",
  "Repair": "Починить",
  "Slot": "Слот",
  "Claim": "Забрать",
  "Details": "Подробнее",
  "Compare": "Сравнить",
  "View all": "Все",
  "Filter": "Фильтр",
  "Sort": "Сортировка",
  "Apply": "Применить",
  "Reset": "Сброс",
  "Confirm": "Подтвердить",
  "Close": "Закрыть",
  "Level": "Уровень",
  "Owner": "Владелец",
  "Price": "Цена",
  "Status": "Статус",
  "Class": "Класс",
  "Rarity": "Редкость",
  "Utility": "Полезность",
  "Season": "Сезон",
  "Faction": "Фракция",
  "Region": "Регион",
  "Last sale": "Прошлая цена",
  "Floor": "Пол (минимум)",
  "Fee": "Комиссия",
  "Royalty": "Роялти",
  "Supply": "Предложение",
  "Demand": "Спрос",
  "Liquidity": "Ликвидность",
  "Volume": "Объём",
  "Yield": "Доходность",
  "Capacity": "Мощность",
  "Efficiency": "Эффективность",
  "Power": "Энергия",
  "Bandwidth": "Пропускная",
  "Maintenance": "Обслуживание",
  "Risk": "Риск",
  "Reputation": "Репутация",
  "Influence": "Влияние",
  "Locked": "Закрыто",
  "Active": "Активно",
  "Available": "Доступно",
  "Soon": "Скоро",
  "New": "Новое",
  "Hot": "Огонь",
  "Live": "Вживую",
  "Simulated": "Симуляция",
  "Pending": "Ожидание",
  "Required": "Требуется",
  "Recommended": "Рекомендуем",
  "Featured": "В топе",
  "Trending": "В тренде",

  // Resources / economy
  "Token": "Токен",
  "Balance": "Баланс",
  "Rewards": "Награды",
  "Stake": "Стейк",
  "Unstake": "Анстейк",
  "Deposit": "Депозит",
  "Withdraw": "Вывод",
  "Emissions": "Эмиссия",
  "Sink": "Сток",
  "Faucet": "Кран",
  "Treasury": "Казна",
  "Insurance": "Страховка",

  // Misc
  "Operator": "Оператор",
  "Rank": "Ранг",
  "Prestige": "Престиж",
  "Profile": "Профиль",
  "Settings": "Настройки",
  "Notifications": "Уведомления",
  "Progression": "Прогресс",
  "Search": "Поиск",
  "All": "Все",
  "My Assets": "Мои активы",
  "World": "Мир",
  "Events": "События",
  "Shocks": "Шоки",
  "News": "Новости",
  "Alerts": "Оповещения",
  "Add funds": "Пополнить",
  "Get Premium": "Premium",
};

export function makeT(lang: Lang) {
  return (key: string): string => (lang === "ru" ? (DICT[key] ?? key) : key);
}
