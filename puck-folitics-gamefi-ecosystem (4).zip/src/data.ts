import { type Tx, type Lang, tx } from "./i18n";

/* ============================================================
   TYPES
   ============================================================ */
export type Rarity = "common" | "uncommon" | "rare" | "epic" | "legendary" | "mythic";
export type DevState =
  | "locked" | "active" | "damaged" | "overloaded" | "boosted"
  | "upgradable" | "fused" | "auctioned" | "rented" | "insured" | "bonded" | "maintenance";
export type AssetClass =
  | "operational" | "industrial" | "tactical" | "prestige" | "civic"
  | "blackmarket" | "archival" | "creator" | "seasonal" | "faction"
  | "event" | "repair" | "fusion";
export type FactionId = "builders" | "speculators" | "archivists" | "raiders";
export type Tone = "acid" | "cyan" | "gold" | "violet" | "pink" | "danger" | "ok" | "warn" | "mut";

export type PartStatus = "maxed" | "upgradable" | "damaged" | "boosted" | "locked";
export type Part = { key: string; level: number; max: number; status: PartStatus };

export type Device = {
  id: string;
  name: Tx;
  line: string;
  assetClass: AssetClass;
  rarity: Rarity;
  state: DevState;
  level: number;
  tier: Tx;          // version tag e.g. "Mk III", "Reforged"
  utility: number;   // 0-100
  value: number;     // $FOLD market value
  valueUsd: number;
  faction?: FactionId;
  season?: string;
  parts: Part[];
  note: Tx;
  owners: number;
  yieldPct?: number;
};

/* ============================================================
   PRESENTATION META (labels + tone), centralized
   ============================================================ */
export const RARITY_META: Record<Rarity, { label: Tx; tone: Tone }> = {
  common:    { label: { en: "Common", ru: "Обычный" }, tone: "mut" },
  uncommon:  { label: { en: "Uncommon", ru: "Необычный" }, tone: "ok" },
  rare:      { label: { en: "Rare", ru: "Редкий" }, tone: "cyan" },
  epic:      { label: { en: "Epic", ru: "Эпический" }, tone: "violet" },
  legendary: { label: { en: "Legendary", ru: "Легендарный" }, tone: "gold" },
  mythic:    { label: { en: "Mythic", ru: "Мифический" }, tone: "pink" },
};

export const STATE_META: Record<DevState, { label: Tx; tone: Tone }> = {
  locked:      { label: { en: "Locked", ru: "Закрыто" }, tone: "mut" },
  active:      { label: { en: "Active", ru: "Активен" }, tone: "ok" },
  damaged:     { label: { en: "Damaged", ru: "Повреждён" }, tone: "danger" },
  overloaded:  { label: { en: "Overloaded", ru: "Перегрузка" }, tone: "warn" },
  boosted:     { label: { en: "Boosted", ru: "Усилен" }, tone: "acid" },
  upgradable:  { label: { en: "Upgradable", ru: "Апгрейд" }, tone: "cyan" },
  fused:       { label: { en: "Fused", ru: "Слит" }, tone: "violet" },
  auctioned:   { label: { en: "On Auction", ru: "На аукционе" }, tone: "gold" },
  rented:      { label: { en: "Rented Out", ru: "В аренде" }, tone: "cyan" },
  insured:     { label: { en: "Insured", ru: "Застрахован" }, tone: "ok" },
  bonded:      { label: { en: "Bonded", ru: "В бонде" }, tone: "pink" },
  maintenance: { label: { en: "Maintenance", ru: "В сервисе" }, tone: "warn" },
};

export const PART_STATUS_META: Record<PartStatus, { label: Tx; tone: Tone }> = {
  maxed:      { label: { en: "Maxed", ru: "Макс." }, tone: "acid" },
  upgradable: { label: { en: "Upgrade", ru: "Апгрейд" }, tone: "cyan" },
  damaged:    { label: { en: "Damaged", ru: "Сломан" }, tone: "danger" },
  boosted:    { label: { en: "Boosted", ru: "Усилен" }, tone: "gold" },
  locked:     { label: { en: "Locked", ru: "Закрыт" }, tone: "mut" },
};

export const ASSET_CLASS_META: Record<AssetClass, { label: Tx; tone: Tone }> = {
  operational: { label: { en: "Operational", ru: "Операционный" }, tone: "cyan" },
  industrial:  { label: { en: "Industrial", ru: "Промышленный" }, tone: "gold" },
  tactical:    { label: { en: "Tactical", ru: "Тактический" }, tone: "pink" },
  prestige:    { label: { en: "Prestige", ru: "Престижный" }, tone: "violet" },
  civic:       { label: { en: "Civic", ru: "Гражданский" }, tone: "acid" },
  blackmarket: { label: { en: "Black-Market", ru: "Чёрный рынок" }, tone: "danger" },
  archival:    { label: { en: "Archival", ru: "Архивный" }, tone: "mut" },
  creator:     { label: { en: "Creator-Made", ru: "Креаторский" }, tone: "cyan" },
  seasonal:    { label: { en: "Seasonal", ru: "Сезонный" }, tone: "gold" },
  faction:     { label: { en: "Faction-Locked", ru: "Фракционный" }, tone: "violet" },
  event:       { label: { en: "Event-Reactive", ru: "Событийный" }, tone: "pink" },
  repair:      { label: { en: "Repair-Only", ru: "Только ремонт" }, tone: "warn" },
  fusion:      { label: { en: "Fusion-Only", ru: "Только слияние" }, tone: "acid" },
};

/* ============================================================
   MODULE PARTS — the 12 upgradeable subsystems
   ============================================================ */
export const MODULE_KEYS = [
  "core", "shell", "power", "sensor", "relay", "cooling",
  "defense", "media", "storage", "signal", "routing", "protection",
] as const;

export const MODULE_META: Record<string, { label: Tx; icon: string; desc: Tx }> = {
  core:       { label: { en: "Core", ru: "Ядро" }, icon: "◈", desc: { en: "Processing brain of the block.", ru: "Мозг всего блока." } },
  shell:      { label: { en: "Shell", ru: "Оболочка" }, icon: "▣", desc: { en: "Outer chassis & integrity.", ru: "Корпус и прочность." } },
  power:      { label: { en: "Power", ru: "Питание" }, icon: "⚡", desc: { en: "Energy throughput.", ru: "Пропуск энергии." } },
  sensor:     { label: { en: "Sensor", ru: "Сенсор" }, icon: "◎", desc: { en: "Reads the world around it.", ru: "Считывает мир вокруг." } },
  relay:      { label: { en: "Relay", ru: "Реле" }, icon: "⇄", desc: { en: "Links to other nodes.", ru: "Связь с узлами." } },
  cooling:    { label: { en: "Cooling", ru: "Охлаждение" }, icon: "❄", desc: { en: "Heat dissipation.", ru: "Отвод тепла." } },
  defense:    { label: { en: "Defense", ru: "Защита" }, icon: "🛡", desc: { en: "Shields against raids.", ru: "Щит от рейдов." } },
  media:      { label: { en: "Media", ru: "Медиа" }, icon: "📡", desc: { en: "Broadcasts influence.", ru: "Транслирует влияние." } },
  storage:    { label: { en: "Storage", ru: "Накопитель" }, icon: "▤", desc: { en: "Holds data & artifacts.", ru: "Хранит данные." } },
  signal:     { label: { en: "Signal", ru: "Сигнал" }, icon: "✦", desc: { en: "Sniffs market signals.", ru: "Ловит сигналы рынка." } },
  routing:    { label: { en: "Routing", ru: "Маршрут" }, icon: "⬡", desc: { en: "Directs flow of value.", ru: "Направляет ценность." } },
  protection: { label: { en: "Protection", ru: "Протект" }, icon: "✸", desc: { en: "Fail-safe & insurance layer.", ru: "Слой страховки." } },
};

const buildParts = (
  keys: string[],
  base: number,
  ov: Partial<Record<string, { level?: number; status?: PartStatus }>> = {}
): Part[] =>
  keys.map((k) => {
    const o = ov[k] || {};
    const level = o.level ?? Math.max(1, Math.min(10, base + (k === "core" ? 2 : 0)));
    const status = o.status ?? (level >= 10 ? "maxed" : "upgradable");
    return { key: k, level, max: 10, status };
  });

/* ============================================================
   FACTIONS
   ============================================================ */
export const FACTIONS: Record<FactionId, {
  id: FactionId; name: Tx; tag: Tx; icon: string; tone: Tone;
  motto: Tx; desc: Tx; play: Tx[]; rep: number;
}> = {
  builders: {
    id: "builders", name: { en: "Builders", ru: "Билдеры" }, tag: { en: "BDL", ru: "BDL" },
    icon: "🜨", tone: "cyan",
    motto: { en: "We pour the concrete everyone else trips on.", ru: "Мы льём бетон, о который все спотыкаются." },
    desc: { en: "Architects of infrastructure. They build the rails, protocols, automata and cities the rest of the world pretends were always there.", ru: "Архитекторы инфраструктуры. Строят рельсы, протоколы, автоматы и города, которые остальные делают вид, что существовали всегда." },
    play: [
      { en: "Erect nodes, vaults & routes", ru: "Строят узлы, хранилища и маршруты" },
      { en: "Earn from everyone using their infra", ru: "Доход с тех, кто юзает их инфру" },
      { en: "Slow start, compounding empire", ru: "Медленный старт, растущая империя" },
    ],
    rep: 64,
  },
  speculators: {
    id: "speculators", name: { en: "Speculators", ru: "Спекулянты" }, tag: { en: "SPC", ru: "SPC" },
    icon: "📈", tone: "gold",
    motto: { en: "Buy the rumour, sell the news to you.", ru: "Покупай на слухах, продавай тебе — на новостях." },
    desc: { en: "Riders of demand, fashion, pumps and meme-assets. They don't build value, they price it faster than you can blink.", ru: "Наездники спроса, моды, пампов и мем-активов. Они не создают ценность — они её оценивают быстрее, чем ты моргнёшь." },
    play: [
      { en: "Trade waves & meme-assets", ru: "Торгуют волны и мем-активы" },
      { en: "Front-run narrative shifts", ru: "Опережают смену нарратива" },
      { en: "Fast money, brutal drawdowns", ru: "Быстрые деньги, жестокие просадки" },
    ],
    rep: 71,
  },
  archivists: {
    id: "archivists", name: { en: "Archivists", ru: "Архивариусы" }, tag: { en: "ARC", ru: "ARC" },
    icon: "📜", tone: "violet",
    motto: { en: "Those who forget history repeat it. We won't let you forget.", ru: "Забывшие историю её повторяют. Мы не дадим забыть." },
    desc: { en: "Keepers of the industry's memory. They exhume old schemes, turn past crashes into knowledge, and profit from what everyone else wants to bury.", ru: "Хранители памяти индустрии. Раскапывают старые схемы, превращают крахи в знания и зарабатывают на том, что все хотят похоронить." },
    play: [
      { en: "Decode old exploit patterns", ru: "Разбирают старые эксплойты" },
      { en: "Convert crashes into intel", ru: "Крахи → в инсайды" },
      { en: "Slow, anti-fragile strategy", ru: "Медленная, антихрупкая стратегия" },
    ],
    rep: 58,
  },
  raiders: {
    id: "raiders", name: { en: "Raiders", ru: "Рейдеры" }, tag: { en: "RDR", ru: "RDR" },
    icon: "⚔", tone: "danger",
    motto: { en: "It's not a bug. It's a business model.", ru: "Это не баг. Это бизнес-модель." },
    desc: { en: "Hunters of exploits, grey advantages and unprotected systems. The Fold keeps them barely legal and fully necessary.", ru: "Охотники за эксплойтами, серыми преимуществами и незащищёнными системами. The Fold держит их на грани закона и абсолютно необходимыми." },
    play: [
      { en: "Find exploit windows", ru: "Ищут окна уязвимостей" },
      { en: "Raid weak nodes & bridges", ru: "Рейдят слабые узлы и мосты" },
      { en: "High risk, zero mercy", ru: "Высокий риск, ноль жалости" },
    ],
    rep: 49,
  },
};

/* ============================================================
   REGIONS of The Fold
   ============================================================ */
export const REGIONS = [
  { id: "citadel", name: { en: "Citadel of Leverage", ru: "Цитадель Рычага" }, icon: "🏙", tone: "gold" as Tone,
    danger: 78, liquidity: 92, influence: 88,
    desc: { en: "A vertical city of derivatives, elite desks and people who borrow tomorrow to pay for today.", ru: "Вертикальный город деривативов, элитных столов и тех, кто занимает у завтра, чтобы заплатить за сегодня." },
    play: { en: "Arbitrage · Derivatives · Elite Trading", ru: "Арбитраж · Деривативы · Элитный трейдинг" } },
  { id: "ashen", name: { en: "Ashen Chain", ru: "Пепельная Цепь" }, icon: "🔥", tone: "danger" as Tone,
    danger: 95, liquidity: 22, influence: 30,
    desc: { en: "A scorched plain of dead collections, rug-pull temples and the ghosts of coins that promised the moon.", ru: "Выжженная равнина мёртвых коллекций, храмов rug-pull и призраков монет, обещавших луну." },
    play: { en: "Archaeology · Rug Salvage · Cheap Artifacts", ru: "Археология · Спасение скама · Дешёвые артефакты" } },
  { id: "bridges", name: { en: "Port of Bridges", ru: "Порт Мостов" }, icon: "🌉", tone: "cyan" as Tone,
    danger: 88, liquidity: 70, influence: 55,
    desc: { en: "The cross-network hub. Money flows through here — and so do the people trying to reroute it.", ru: "Хаб между сетями. Деньги текут здесь — как и те, кто пытается их перенаправить." },
    play: { en: "Routing · Logistics · High Hack Risk", ru: "Маршрутизация · Логистика · Риск взлома" } },
  { id: "jpeg", name: { en: "JPEG Reef", ru: "Риф JPEG" }, icon: "🖼", tone: "violet" as Tone,
    danger: 40, liquidity: 64, influence: 81,
    desc: { en: "An archipelago of galleries, status and collectibles whose value is 90% vibes, 10% picture.", ru: "Архипелаг галерей, статуса и коллекционок, ценность которых — на 90% вайб и на 10% картинка." },
    play: { en: "Curation · Status · Flex Economy", ru: "Кураторство · Статус · Экономика флексa" } },
  { id: "vaultstep", name: { en: "Vaultstep Basin", ru: "Бассейн Vaultstep" }, icon: "🏦", tone: "acid" as Tone,
    danger: 52, liquidity: 83, influence: 60,
    desc: { en: "Yield country. Automated farms, vaults and strategies that quietly milk the world while it sleeps.", ru: "Край доходности. Авто-фермы, хранилища и стратегии, что потихоньку доят мир, пока он спит." },
    play: { en: "Yield · Auto-Farming · LP", ru: "Доходность · Авто-фермы · LP" } },
  { id: "miners", name: { en: "Miner's Fault", ru: "Разлом Майнеров" }, icon: "⛏", tone: "warn" as Tone,
    danger: 86, liquidity: 40, influence: 45,
    desc: { en: "An industrial rift of rigs, energy wars and people who measure the world in hashes and watts.", ru: "Промышленный разлом ферм, энергетических войн и тех, кто меряет мир хешами и ваттами." },
    play: { en: "Mining · Energy · Industrial", ru: "Майнинг · Энергия · Промышленность" } },
  { id: "forum", name: { en: "Forum Zero", ru: "Форум Зеро" }, icon: "🎙", tone: "pink" as Tone,
    danger: 60, liquidity: 50, influence: 99,
    desc: { en: "The politico-media core. Here agendas are born, rumours are minted and trust is traded like a token.", ru: "Политико-медийное ядро. Здесь рождаются повестки, чеканятся слухи, а доверие торгуется как токен." },
    play: { en: "Narrative · Diplomacy · Influence", ru: "Нарратив · Дипломатия · Влияние" } },
];

/* ============================================================
   CHARACTERS — industry archetypes (parody, not IP)
   ============================================================ */
export const CHARACTERS = [
  { id: "satoshee", name: { en: "Sato Shee", ru: "Сато Ши" }, icon: "🧩", tone: "acid" as Tone, region: "forum",
    role: { en: "The Vanished Architect", ru: "Исчезнувший Архитектор" },
    desc: { en: "Pseudonymous genesis architect. Sent the founding whitepaper, then ghosted the entire civilization. Now a religion.", ru: "Псевдонимный архитектор генезиса. Прислал белыйpaper и слился со всей цивилизацией. Теперь это религия." },
    power: 96 },
  { id: "vita", name: { en: "Vita Lick", ru: "Вита Лик" }, icon: "🧠", tone: "violet" as Tone, region: "vaultstep",
    role: { en: "The Over-Engineer", ru: "Слишком Умный Инженер" },
    desc: { en: "Idealist philosopher who builds systems so elegant nobody can operate them. Talks for 4 hours. Ships anyway.", ru: "Идеалист-философ, строит системы настолько элегантные, что никто не умеет ими пользоваться. Говорит 4 часа. Шипает всё равно." },
    power: 84 },
  { id: "trumpoid", name: { en: "Don Trumpoid", ru: "Дон Трампоид" }, icon: "🟧", tone: "gold" as Tone, region: "forum",
    role: { en: "The Volatility Magnet", ru: "Магнит Волатильности" },
    desc: { en: "Impulsive political pulse. One sentence from him moves a sector more than a halving. Tongue: very orange.", ru: "Импульсивный политический пульс. Одно его слово двигает сектор сильнее, чем халвинг. Язык: очень оранжевый." },
    power: 90 },
  { id: "flux", name: { en: "Elon Flux", ru: "Илон Флюкс" }, icon: "🚀", tone: "cyan" as Tone, region: "miners",
    role: { en: "The Meme Launcher", ru: "Запускатель Мемов" },
    desc: { en: "Techno-jester with rocket temples. A single emoji from him spawns a coin, a cult and a class-action.", ru: "Техно-шут с ракетными храмами. Одна его эмодзи рождает монету, культ и коллективный иск." },
    power: 93 },
  { id: "mirrorman", name: { en: "Sam Mirrorman", ru: "Сэм Зеркальник" }, icon: "🪞", tone: "pink" as Tone, region: "citadel",
    role: { en: "The Palace Illusionist", ru: "Иллюзионист Дворцов" },
    desc: { en: "Genius of centralized palaces made of mirrors and IOUs. Very effective. Extremely not your money.", ru: "Гений централизованных дворцов из зеркал и расписок. Очень эффективен. Совершенно не ваши деньги." },
    power: 88 },
  { id: "czarn", name: { en: "Czarn Chancellor", ru: "Чарн Канцлер" }, icon: "♟", tone: "gold" as Tone, region: "citadel",
    role: { en: "The Liquidity Master", ru: "Мастер Ликвидности" },
    desc: { en: "Grand router of capital. Knows every path money can take — and takes a small toll on all of them.", ru: "Великий маршрутизатор капитала. Знает каждую дорожку денег — и берёт небольшую пошлину со всех." },
    power: 91 },
  { id: "peg", name: { en: "Madame Peg", ru: "Мадам Пег" }, icon: "⚖", tone: "cyan" as Tone, region: "vaultstep",
    role: { en: "The Priestess of Stability", ru: "Жрица Стабильности" },
    desc: { en: "Keeper of the stablecoin temples. When she sneezes, a peg wobbles and three exchanges suspend withdrawals.", ru: "Хранительница храмов стейблкоинов. Чихнёт — и по́г шатнётся, а три биржи заморозят выводы." },
    power: 87 },
];

/* ============================================================
   SEASONS
   ============================================================ */
export const SEASONS = [
  { id: "bull", name: { en: "Bull Season", ru: "Сезон Быка" }, icon: "🐂", tone: "ok" as Tone, active: true,
    desc: { en: "The world runs hot. Memes mint millionaires overnight, influencers become prophets and cities grow faster than their foundations.", ru: "Мир на взводе. Мемы чеканят миллионеров за ночь, инфлюенсеры становятся пророками, а города растут быстрее фундаментов." } },
  { id: "bear", name: { en: "Bear Season", ru: "Сезон Медведя" }, icon: "🐻", tone: "danger" as Tone, active: false,
    desc: { en: "Efficiency wins. Infrastructure, reputation and anti-scam matter again. The tourists leave; the builders stay and get cheap.", ru: "Побеждает эффективность. Инфра, репутация и антискам снова в цене. Туристы уходят; билдеры остаются и дешевеют." } },
  { id: "rotation", name: { en: "Rotation Season", ru: "Сезон Ротации" }, icon: "🔄", tone: "gold" as Tone, active: false,
    desc: { en: "Capital and attention migrate. Yesterday's junk becomes today's critical infrastructure. Adapt or get rotated on.", ru: "Капитал и внимание мигрируют. Вчерашший мусор становится критической инфрой. Адаптируйся или по тебе проедутся." } },
  { id: "crackdown", name: { en: "Crackdown Season", ru: "Сезон Зачистки" }, icon: "🚨", tone: "warn" as Tone, active: false,
    desc: { en: "Regulators, panic and investigations. Transparency, reserves and strong alliances keep you alive. Opacity gets you subpoena'd.", ru: "Регуляторы, паника и расследования. Прозрачность, резервы и крепкие союзы спасают. Непрозрачность — это повестка в суд." } },
];

/* ============================================================
   WORLD SHOCKS — scripted events, 3 impact levels
   ============================================================ */
export const WORLD_SHOCKS = [
  { id: "exchange-freeze", name: { en: "Exchange Freeze", ru: "Заморозка Биржи" }, icon: "🧊", tone: "cyan" as Tone, chance: 18,
    vis: { en: "Withdrawal buttons grey out across the Citadel.", ru: "Кнопки вывода сереют по всей Цитадели." },
    sys: { en: "+routing cost, –contract reliability", ru: "+стоимость маршрутов, –надёжность контрактов" },
    soc: { en: "NPC panic +40%, bank-run behaviour", ru: "паника NPC +40%, поведение bank-run" } },
  { id: "stable-fracture", name: { en: "Stable Fracture", ru: "Трещина Стейбла" }, icon: "⚖", tone: "danger" as Tone, chance: 9,
    vis: { en: "Madame Peg's temple flickers. The peg wobbles.", ru: "Храм Мадам Пег мигает. По́г шатается." },
    sys: { en: "stablecoin utility depegs, yield volatility", ru: "стейблы депегаются, волатильность доходности" },
    soc: { en: "demand for insurance covers spikes", ru: "спрос на страховки взлетает" } },
  { id: "bridge-breach", name: { en: "Bridge Breach", ru: "Прорыв Моста" }, icon: "🌉", tone: "danger" as Tone, chance: 12,
    vis: { en: "A Port of Bridges corridor goes dark mid-transfer.", ru: "Коридор Порта Мостов гаснет на переводе." },
    sys: { en: "–liquidity, +raid probability", ru: "–ликвидность, +вероятность рейдов" },
    soc: { en: "insured guilds survive, others bleed", ru: "застрахованные гильдии живут, остальные текут" } },
  { id: "meme-fever", name: { en: "Meme Fever", ru: "Мем-Лихорадка" }, icon: "🐸", tone: "gold" as Tone, chance: 26,
    vis: { en: "JPEG Reef glows neon. A coin with no purpose prints 9,000%.", ru: "Риф JPEG светится неоном. Монета без смысла делает 9 000%." },
    sys: { en: "+meme-asset demand, +speculator yield", ru: "+спрос на мем-активы, +доход спекулянтов" },
    soc: { en: "rumour spread speed x3", ru: "скорость слухов x3" } },
  { id: "fork-dispute", name: { en: "Fork Dispute", ru: "Раскол Ветви" }, icon: "🔱", tone: "violet" as Tone, chance: 14,
    vis: { en: "A protocol splits in two. Both claim to be the original.", ru: "Протокол делится надвое. Каждый считает себя оригиналом." },
    sys: { en: "split liquidity, governance chaos", ru: "дробление ликвидности, хаос в управлении" },
    soc: { en: "reputation swings on loyalty", ru: "репутация качается на лояльности" } },
  { id: "whale-awakening", name: { en: "Whale Awakening", ru: "Пробуждение Кита" }, icon: "🐋", tone: "cyan" as Tone, chance: 11,
    vis: { en: "A dormant wallet from 2014 moves 40,000 units. Everyone panics for no reason.", ru: "Спящий кошелёк из 2014 двигает 40 000 единиц. Все паникуют без причины." },
    sys: { en: "+volatility, +whale-tracker value", ru: "+волатильность, +ценность кит-трекера" },
    soc: { en: "copy-trading frenzy", ru: "бешенство копи-трейдинга" } },
  { id: "presidential", name: { en: "Presidential Statement", ru: "Заявление Президента" }, icon: "🎙", tone: "pink" as Tone, chance: 16,
    vis: { en: "Don Trumpoid opens his mouth in Forum Zero.", ru: "Дон Трампоид открывает рот в Форуме Зеро." },
    sys: { en: "instant sector repricing", ru: "мгновенный репрайс сектора" },
    soc: { en: "narrative shockwave", ru: "ударная волна нарратива" } },
  { id: "jpeg-mania", name: { en: "JPEG Mania", ru: "JPEG-Мания" }, icon: "🖼", tone: "violet" as Tone, chance: 20,
    vis: { en: "Floor prices decouple from reality. Again.", ru: "Пол цен отрывается от реальности. Снова." },
    sys: { en: "+collectible demand, +status value", ru: "+спрос на коллекционки, +ценность статуса" },
    soc: { en: "flex economy overheats", ru: "экономика флексa перегрета" } },
];

/* ============================================================
   DEVICE LINES & OWNED DEVICES
   ============================================================ */
export type DeviceRole = "hq" | "income" | "intel" | "influence" | "defense";
export type EffectKind = "intel" | "influence" | "edge" | "defense" | "income" | "cred";
export type DeviceEffect = { kind: EffectKind; amount: number; text: Tx };
export type DeviceLine = {
  id: string; name: Tx; icon: string; tone: Tone; cls: AssetClass; blurb: Tx; parts: string[];
  role: DeviceRole; effect: DeviceEffect; usedIn: Tx;
};

export const ROLE_META: Record<DeviceRole, { label: Tx; icon: string; tone: Tone; short: Tx }> = {
  hq:        { label: { en: "Base / HQ", ru: "База / HQ" }, icon: "🏠", tone: "acid", short: { en: "Your seat of power", ru: "Твой центр силы" } },
  income:    { label: { en: "Income", ru: "Доход" }, icon: "💰", tone: "gold", short: { en: "Prints $FOLD passively", ru: "Печатает $FOLD пассивно" } },
  intel:     { label: { en: "Intel", ru: "Интел" }, icon: "📡", tone: "cyan", short: { en: "Read the market sharper", ru: "Читает рынок точнее" } },
  influence: { label: { en: "Influence", ru: "Влияние" }, icon: "📣", tone: "pink", short: { en: "Boost your spins", ru: "Усиливает твои спины" } },
  defense:   { label: { en: "Defense", ru: "Защита" }, icon: "🛡", tone: "ok", short: { en: "Cut losses vs shocks", ru: "Режет потери от шоков" } },
};

export const DEVICE_LINES: DeviceLine[] = [
  { id: "node", name: { en: "Node Core", ru: "Ядро Узла" }, icon: "⬢", tone: "acid", cls: "operational", role: "hq",
    blurb: { en: "Your operating seat in The Fold. Everything hangs off this.", ru: "Твоё операционное место в The Fold. Всё крепится к нему." },
    effect: { kind: "cred", amount: 0.5, text: { en: "+cred on every winning spin", ru: "+кредо за каждый выигрышный спин" } },
    usedIn: { en: "Everywhere · boosts Cred", ru: "Везде · +кредо" },
    parts: ["core", "shell", "power", "cooling", "storage", "protection"] },
  { id: "oracle", name: { en: "Signal Oracle", ru: "Сигнал-Оракул" }, icon: "✦", tone: "cyan", cls: "tactical", role: "intel",
    blurb: { en: "Feeds on live market reality. The closer to the real tape, the sharper your decisions.", ru: "Питается живой рыночной реальностью. Чем ближе к реальной ленте, тем точнее решения." },
    effect: { kind: "intel", amount: 0.12, text: { en: "+12% Intel clarity in War Room", ru: "+12% к ясности Интела в War Room" } },
    usedIn: { en: "War Room · sharpens Intel", ru: "War Room · точнее Интел" },
    parts: ["core", "sensor", "signal", "routing", "storage", "relay"] },
  { id: "whale", name: { en: "Whale Tracker", ru: "Трекер Китов" }, icon: "🐋", tone: "cyan", cls: "tactical", role: "intel",
    blurb: { en: "Watches the wallets that move the world. Then moves slightly before they do.", ru: "Следит за кошельками, что двигают мир. А потом чуть-чуть двигается до них." },
    effect: { kind: "edge", amount: 0.06, text: { en: "+6% edge (reads whale wallets)", ru: "+6% перевес (читает кошельки китов)" } },
    usedIn: { en: "War Room · +edge", ru: "War Room · +перевес" },
    parts: ["core", "sensor", "signal", "relay", "storage", "routing"] },
  { id: "fud", name: { en: "FUD Engine", ru: "Двигатель FUD" }, icon: "📡", tone: "pink", cls: "tactical", role: "influence",
    blurb: { en: "Manufactures and amplifies narratives. Optional, morally flexible, very profitable.", ru: "Производит и усиливает нарративы. По желанию, морально гибко, очень прибыльно." },
    effect: { kind: "influence", amount: 0.08, text: { en: "+8% to bear/chaos helpers", ru: "+8% к медвежьим/хаос-помощникам" } },
    usedIn: { en: "War Room · +influence", ru: "War Room · +влияние" },
    parts: ["core", "media", "signal", "relay", "routing", "protection"] },
  { id: "copium", name: { en: "Copium Synth", ru: "Синтез Копиума" }, icon: "💨", tone: "gold", cls: "creator", role: "influence",
    blurb: { en: "Synthesises morale during drawdowns. Placebo? Absolutely. Effective? Statistically.", ru: "Синтезирует боевой дух на просадках. Плацебо? Абсолютно. Работает? Статистически." },
    effect: { kind: "influence", amount: 0.06, text: { en: "+6% to safe/any helpers", ru: "+6% к безопасным помощникам" } },
    usedIn: { en: "War Room · +influence", ru: "War Room · +влияние" },
    parts: ["core", "media", "storage", "signal", "cooling", "protection"] },
  { id: "vault", name: { en: "Vault Forge", ru: "Кузница Хранилищ" }, icon: "🏦", tone: "acid", cls: "industrial", role: "income",
    blurb: { en: "Auto-compounds yield while you pretend to work. The honest money machine.", ru: "Авто-компаундит доходность, пока ты делаешь вид, что работаешь. Честный станок денег." },
    effect: { kind: "income", amount: 1.0, text: { en: "Passive $FOLD income / day", ru: "Пассивный доход $FOLD / день" } },
    usedIn: { en: "Bankroll · prints $FOLD", ru: "Банкролл · печатает $FOLD" },
    parts: ["core", "storage", "routing", "power", "cooling", "protection"] },
  { id: "rug", name: { en: "Rug Detector", ru: "Детектор Скама" }, icon: "🛡", tone: "violet", cls: "archival", role: "defense",
    blurb: { en: "Sniffs exits before they happen. Saved more fortunes than it cost.", ru: "Чует выходы до того, как они случаются. Спас больше состояний, чем стоил." },
    effect: { kind: "defense", amount: 0.12, text: { en: "-12% loss when market dumps", ru: "-12% к потерям при падении рынка" } },
    usedIn: { en: "Defense · cuts bear losses", ru: "Защита · режет потери в падении" },
    parts: ["core", "sensor", "signal", "storage", "defense", "protection"] },
  { id: "bridge", name: { en: "Bridge Relay", ru: "Мост-Реле" }, icon: "🌉", tone: "cyan", cls: "industrial", role: "defense",
    blurb: { en: "Routes value between worlds. Charges a toll. Occasionally gets raided.", ru: "Маршрутизирует ценность между мирами. Берёт пошлину. Иногда подвергается рейду." },
    effect: { kind: "defense", amount: 0.10, text: { en: "-10% all spin losses", ru: "-10% ко всем потерям в спине" } },
    usedIn: { en: "Defense · cuts all losses", ru: "Защита · режет все потери" },
    parts: ["core", "relay", "routing", "defense", "protection", "cooling"] },
];

const lineParts = (id: string) => DEVICE_LINES.find((l) => l.id === id)!.parts;

export const DEVICES: Device[] = [
  {
    id: "dev-node-01", name: { en: "Genesis Node // Hexline", ru: "Узел Генезиса // Hexline" },
    line: "node", assetClass: "operational", rarity: "legendary", state: "boosted", level: 9, tier: { en: "Mk IX · Boosted", ru: "Mk IX · Усилен" },
    utility: 92, value: 184000, valueUsd: 4320, faction: "builders", season: "bull",
    note: { en: "Your throne. One more core level and the whole district reroutes through you.", ru: "Твой трон. Ещё один уровень ядра — и весь район пойдёт через тебя." },
    owners: 1, yieldPct: 7.4,
    parts: buildParts(lineParts("node"), 8, { core: { level: 9 }, power: { status: "boosted" }, cooling: { status: "damaged" } }),
  },
  {
    id: "dev-oracle-01", name: { en: "Live Tape Oracle", ru: "Оракул Живой Ленты" },
    line: "oracle", assetClass: "tactical", rarity: "epic", state: "active", level: 6, tier: { en: "Mk VI", ru: "Mk VI" },
    utility: 81, value: 64200, valueUsd: 1508, faction: "archivists", season: "bull",
    note: { en: "Piped straight into real market reality. Spikes harder whenever BTC moves.", ru: "Подключён прямо к живой рыночной реальности. Дёргается сильнее при движении BTC." },
    owners: 1, yieldPct: 5.1,
    parts: buildParts(lineParts("oracle"), 6),
  },
  {
    id: "dev-vault-01", name: { en: "Auto-Compound Vault Forge", ru: "Кузница Авто-Компаунда" },
    line: "vault", assetClass: "industrial", rarity: "rare", state: "upgradable", level: 5, tier: { en: "Mk V", ru: "Mk V" },
    utility: 68, value: 28900, valueUsd: 679, season: "bull",
    note: { en: "Mints passive yield. The only machine here that never asks for your attention.", ru: "Чеканит пассивный доход. Единственная машина тут, что не просит внимания." },
    owners: 1, yieldPct: 9.2,
    parts: buildParts(lineParts("vault"), 5, { routing: { status: "upgradable" } }),
  },
  {
    id: "dev-rug-01", name: { en: "Exit Sniffer Mk III", ru: "Нюхач Выходов Mk III" },
    line: "rug", assetClass: "archival", rarity: "rare", state: "damaged", level: 4, tier: { en: "Mk III · Damaged", ru: "Mk III · Сломан" },
    utility: 47, value: 12400, valueUsd: 292, faction: "archivists", season: "bull",
    note: { en: "Caught a whiff of the last bridge breach and got its sensor fried. Worth fixing.", ru: "Почуял последний прорыв моста и сжёг сенсор. Стоит починить." },
    owners: 1,
    parts: buildParts(lineParts("rug"), 4, { sensor: { status: "damaged" }, core: { status: "upgradable" } }),
  },
  {
    id: "dev-fud-01", name: { en: "Narrative Cannon", ru: "Пушка Нарративов" },
    line: "fud", assetClass: "tactical", rarity: "epic", state: "rented", level: 7, tier: { en: "Mk VII · Rented", ru: "Mk VII · В аренде" },
    utility: 85, value: 51200, valueUsd: 1203, faction: "speculators", season: "bull",
    note: { en: "Currently leased to a Forum Zero think-tank. They're... enthusiastic users.", ru: "Сейчас сдана think-tank'у из Форума Зеро. Они... восторженные пользователи." },
    owners: 1, yieldPct: 6.0,
    parts: buildParts(lineParts("fud"), 7, { media: { status: "boosted" } }),
  },
  {
    id: "dev-bridge-01", name: { en: "Cross-Chain Relay", ru: "Кросс-чейн Реле" },
    line: "bridge", assetClass: "industrial", rarity: "uncommon", state: "insured", level: 3, tier: { en: "Mk III · Insured", ru: "Mk III · Застрахован" },
    utility: 54, value: 9800, valueUsd: 230, season: "bull",
    note: { en: "Insured against breaches. Smart, given where it lives.", ru: "Застрахован от прорывов. Умно, учитывая, где он стоит." },
    owners: 1, yieldPct: 4.4,
    parts: buildParts(lineParts("bridge"), 3, { protection: { status: "maxed" } }),
  },
  {
    id: "dev-copium-01", name: { en: "Copium Synth", ru: "Синтез Копиума" },
    line: "copium", assetClass: "creator", rarity: "common", state: "active", level: 2, tier: { en: "Mk II", ru: "Mk II" },
    utility: 31, value: 1900, valueUsd: 45, season: "bull",
    note: { en: "Most-used device in your vault, statistically. Make of that what you will.", ru: "Самая используемая вещь в хранилище, по статистике. Делай выводы." },
    owners: 1,
    parts: buildParts(lineParts("copium"), 2),
  },
  {
    id: "dev-whale-01", name: { en: "Leviathan Tracker", ru: "Трекер Левиафанов" },
    line: "whale", assetClass: "tactical", rarity: "rare", state: "maintenance", level: 5, tier: { en: "Mk V · Service", ru: "Mk V · Сервис" },
    utility: 63, value: 22300, valueUsd: 524, faction: "raiders", season: "bull",
    note: { en: "In for a coolant flush. Returns meaner.", ru: "На промывке охлаждения. Вернётся злее." },
    owners: 1,
    parts: buildParts(lineParts("whale"), 5, { cooling: { status: "locked" } }),
  },
  {
    id: "dev-oracle-02", name: { en: "Dust Oracle", ru: "Пыльный Оракул" },
    line: "oracle", assetClass: "operational", rarity: "common", state: "locked", level: 1, tier: { en: "Mk I · Locked", ru: "Mk I · Закрыт" },
    utility: 18, value: 600, valueUsd: 14, season: "bull",
    note: { en: "Your starter oracle. Unlocks once you survive your first world shock.", ru: "Стартовый оракул. Откроется, как переживёшь первый мировой шок." },
    owners: 1,
    parts: buildParts(lineParts("oracle"), 1, { core: { status: "locked" }, signal: { status: "locked" } }),
  },
];

/* ============================================================
   PROGRESSION — operator ranks (long-term arc)
   ============================================================ */
export const RANKS = [
  { tier: 1, name: { en: "Dust Operator", ru: "Оператор Пыли" }, xp: 0, perks: { en: "1 node, starter oracle", ru: "1 узел, стартовый оракул" } },
  { tier: 2, name: { en: "Node Runner", ru: "Раннер Узлов" }, xp: 2500, perks: { en: "Vault slots, market access", ru: "Слоты хранилища, доступ к рынку" } },
  { tier: 3, name: { en: "Vault Keeper", ru: "Хранитель Хранилищ" }, xp: 9000, perks: { en: "Insurance, guild rights", ru: "Страховка, права гильдии" } },
  { tier: 4, name: { en: "Liquidator", ru: "Ликвидатор" }, xp: 24000, perks: { en: "Bonds, lending, arb desk", ru: "Бонды, кредиты, арбитраж" } },
  { tier: 5, name: { en: "Magnate", ru: "Магнат" }, xp: 60000, perks: { en: "Council vote, infra shares", ru: "Голос в совете, доли инфры" } },
  { tier: 6, name: { en: "Architect", ru: "Архитектор" }, xp: 140000, perks: { en: "Publish events, royalties", ru: "Публикация событий, роялти" } },
  { tier: 7, name: { en: "Whale", ru: "Кит" }, xp: 320000, perks: { en: "Treasury governance", ru: "Управление казной" } },
  { tier: 8, name: { en: "Fold Sovereign", ru: "Суверен The Fold" }, xp: 900000, perks: { en: "World-shaping vetoes", ru: "Вето, меняющее мир" } },
];

/* ============================================================
   IDENTITY · PLACE · CONFLICT  (who you are / where you are / who you fight)
   ============================================================ */
export const PLAYER_NODE = {
  id: "hexline-7",
  name: { en: "Hexline-7 Relay", ru: "Реле Hexline-7" },
  regionId: "vaultstep",
  sector: { en: "Vaultstep Basin · Yield District 4", ru: "Бассейн Vaultstep · Доходный сектор 4" },
  level: 9,
  integrity: 88,
  output: 92,
  control: 64,     // your hold over the district
  defense: 71,
};

export const PLAYER_GLOBAL_RANK = 1847;
export const PLAYER_GLOBAL_TOTAL = 182043;

export const MISSION = {
  title: { en: "Hold the Line: Bridge Breach Window", ru: "Держать оборону: окно Прорыва Моста" },
  progress: 58,
  reward: 18000,
  deadline: { en: "opens in ~6h", ru: "откроется через ~6ч" },
  desc: { en: "A scripted Bridge Breach is approaching. Fortify your relay, insure your top-yield vault, and stake into the risk pool — or 0xReaper drains it first.", ru: "Приближается сценарный Прорыв Моста. Укрепи реле, застрахуй лучший хранилище и войди в риск-пул — иначе 0xРипер выкачает его первым." },
  steps: [
    { en: "Insure Bridge Relay", ru: "Застраховать Мост-Реле", done: true },
    { en: "Raise Defense Grid to Lv 4", ru: "Поднять Оборону до Ур 4", done: false },
    { en: "Stake 5,000 $FOLD in risk pool", ru: "Застейкать 5 000 $FOLD в риск-пул", done: false },
  ],
};

export type Relation = "rival" | "threat" | "ally" | "prey";
export const RIVAL_RELATION: Record<Relation, { label: Tx; tone: Tone; act: Tx }> = {
  rival:  { label: { en: "Rival",  ru: "Соперник" }, tone: "gold",   act: { en: "Challenge", ru: "Бросить вызов" } },
  threat: { label: { en: "Threat", ru: "Угроза"   }, tone: "danger", act: { en: "Counter",   ru: "Контратаковать" } },
  ally:   { label: { en: "Ally",   ru: "Союзник"  }, tone: "ok",     act: { en: "Coordinate",ru: "Координироваться" } },
  prey:   { label: { en: "Prey",   ru: "Добыча"   }, tone: "violet", act: { en: "Squeeze",   ru: "Дожать" } },
};

export const RIVALS = [
  { id: "ghost", name: { en: "The Ghost of '14", ru: "Призрак '14" }, handle: "0x00..dead", faction: "raiders" as FactionId, power: 95, net: 990000, globalRank: 41, relation: "threat" as Relation, region: "miners", note: { en: "Moves in silence. Then moves a market.", ru: "Двигается тихо. А потом двигает рынок." } },
  { id: "raidcrew", name: { en: "0xReaper", ru: "0xРипер" }, handle: "guild:RAIDCREW", faction: "raiders" as FactionId, power: 84, net: 95000, globalRank: 884, relation: "threat" as Relation, region: "bridges", note: { en: "Marked your Hexline-7 node. Blade is out.", ru: "Навёлся на твой Hexline-7. Клинок наголо." } },
  { id: "moonboy", name: { en: "MoonBoy Maxi", ru: "МунБой Макси" }, handle: "@moonboy", faction: "speculators" as FactionId, power: 78, net: 210000, globalRank: 1203, relation: "rival" as Relation, region: "citadel", note: { en: "Pumping your sector, undercutting your routes.", ru: "Пампит твой сектор, демпингует маршруты." } },
  { id: "archix", name: { en: "Archivist Nine", ru: "Архивариус IX" }, handle: "@arch9", faction: "archivists" as FactionId, power: 66, net: 140000, globalRank: 1610, relation: "ally" as Relation, region: "ashen", note: { en: "Feeds you intel on the next fork.", ru: "Сливает инсайд о следующем форке." } },
  { id: "dumpdan", name: { en: "DumpTruck Dan", ru: "ДампТрак Дэн" }, handle: "@dumpdan", faction: "speculators" as FactionId, power: 72, net: 88000, globalRank: 2104, relation: "prey" as Relation, region: "jpeg", note: { en: "Over-leveraged on JPEG Reef. One squeeze away.", ru: "Перегружен на Рифе JPEG. Одно давление — и крах." } },
];

export const FACTION_WAR = {
  power: { builders: 27, speculators: 31, archivists: 19, raiders: 23 } as Record<FactionId, number>,
  pairs: [
    { a: "builders" as FactionId, b: "raiders" as FactionId, tension: 81, label: { en: "Infrastructure vs. Exploits", ru: "Инфра против Эксплойтов" } },
    { a: "speculators" as FactionId, b: "archivists" as FactionId, tension: 47, label: { en: "Hype vs. Memory", ru: "Хайп против Памяти" } },
  ],
};

/* ============================================================
   MARKETPLACE — diverse user-to-user listings
   ============================================================ */
export type ListingType = "buy" | "auction" | "offer" | "rent" | "bundle";
export type Listing = {
  id: string; type: ListingType; kind: Tx; name: Tx; meta: Tx; rarity?: Rarity;
  class: AssetClass; faction?: FactionId; price: number; priceUsd: number;
  floor?: number; lastSale?: number; fee: number; royalty: number; bids?: number;
  utility?: number; demand: number; liquidity: number; season?: string; owner: string; tag?: Tx;
};

export const LISTINGS: Listing[] = [
  { id: "L1", type: "auction", kind: { en: "Device", ru: "Устройство" }, name: { en: "Live Tape Oracle // Gold", ru: "Оракул Живой Ленты // Золото" },
    meta: { en: "Mk VIII · Boosted", ru: "Mk VIII · Усилен" }, rarity: "mythic", class: "tactical", faction: "archivists",
    price: 410000, priceUsd: 9635, floor: 380000, lastSale: 290000, fee: 2.5, royalty: 5, bids: 23,
    utility: 97, demand: 94, liquidity: 71, season: "bull", owner: "0x4f…ea", tag: { en: "HOT", ru: "ОГОНЬ" } },
  { id: "L2", type: "buy", kind: { en: "Module", ru: "Модуль" }, name: { en: "Quantum Sensor Array", ru: "Квантовый Сенсор" },
    meta: { en: "Sensor · Lv 8", ru: "Сенсор · Ур 8" }, rarity: "epic", class: "tactical",
    price: 18800, priceUsd: 442, floor: 17500, lastSale: 16100, fee: 2, royalty: 3,
    utility: 88, demand: 81, liquidity: 90, owner: "0xab…11" },
  { id: "L3", type: "offer", kind: { en: "Blueprint", ru: "Чертёж" }, name: { en: "Bridge Breach Blueprint", ru: "Чертёж Прорыва Моста" },
    meta: { en: "Event · Limited", ru: "Событие · Лимит" }, rarity: "legendary", class: "event", faction: "raiders",
    price: 92000, priceUsd: 2162, fee: 2.5, royalty: 6, demand: 76, liquidity: 48, season: "bull", owner: "guild:NIGHTWHALE" },
  { id: "L4", type: "rent", kind: { en: "License", ru: "Лицензия" }, name: { en: "Citadel Route License", ru: "Лицензия Маршрута Цитадели" },
    meta: { en: "30-day lease", ru: "Аренда 30 дней" }, rarity: "rare", class: "civic",
    price: 4200, priceUsd: 99, fee: 1, royalty: 0, demand: 88, liquidity: 95, owner: "0xc7…be" },
  { id: "L5", type: "buy", kind: { en: "Service Contract", ru: "Сервис-Контракт" }, name: { en: "Raid Insurance Cover", ru: "Страховка от Рейдов" },
    meta: { en: "Protects 3 nodes", ru: "Защита 3 узлов" }, class: "operational",
    price: 7600, priceUsd: 179, fee: 1.5, royalty: 0, utility: 70, demand: 92, liquidity: 88, owner: "guild:BULWARK" },
  { id: "L6", type: "bundle", kind: { en: "Bundle", ru: "Набор" }, name: { en: "Bear-Proof Starter Kit", ru: "Стартер Анти-Медведь" },
    meta: { en: "6 items · -18%", ru: "6 предметов · -18%" }, class: "operational",
    price: 39900, priceUsd: 938, fee: 1, royalty: 0, utility: 64, demand: 70, liquidity: 82, owner: "vault:OFFICIAL", tag: { en: "BUNDLE", ru: "НАБОР" } },
  { id: "L7", type: "auction", kind: { en: "Cosmetic", ru: "Косметика" }, name: { en: "Golden Rug Trophy", ru: "Золотой Трофей Скама" },
    meta: { en: "From the Ashen Chain", ru: "Из Пепельной Цепи" }, rarity: "legendary", class: "prestige",
    price: 26500, priceUsd: 623, floor: 24000, lastSale: 19500, fee: 2.5, royalty: 7, bids: 8,
    utility: 12, demand: 60, liquidity: 40, owner: "0x9d…03" },
  { id: "L8", type: "buy", kind: { en: "Signal Pack", ru: "Пак Сигналов" }, name: { en: "Whale Wakeup Alerts", ru: "Алерты Пробуждения Китов" },
    meta: { en: "7-day feed", ru: "Лента на 7 дней" }, class: "operational",
    price: 3200, priceUsd: 75, fee: 1, royalty: 0, utility: 74, demand: 85, liquidity: 92, owner: "0x22…7f" },
  { id: "L9", type: "offer", kind: { en: "Creator Item", ru: "Креаторский" }, name: { en: "FUD Remix Pack v3", ru: "Пак FUD-Ремиксов v3" },
    meta: { en: "By @narrativelord", ru: "От @narrativelord" }, rarity: "epic", class: "creator",
    price: 14400, priceUsd: 338, floor: 13000, lastSale: 11200, fee: 2, royalty: 8, demand: 67, liquidity: 55, owner: "@narrativelord" },
  { id: "L10", type: "rent", kind: { en: "Data Artifact", ru: "Артефакт Данных" }, name: { en: "2014 Genesis Ledger", ru: "Реестр Генезиса 2014" },
    meta: { en: "Read-only · 14 days", ru: "Только чтение · 14 дней" }, rarity: "mythic", class: "archival", faction: "archivists",
    price: 8800, priceUsd: 207, fee: 1.5, royalty: 0, utility: 90, demand: 58, liquidity: 30, owner: "archive:ARC" },
  { id: "L11", type: "buy", kind: { en: "Fragment", ru: "Фрагмент" }, name: { en: "Peg Shard", ru: "Осколок Пега" },
    meta: { en: "3/10 to fuse", ru: "3/10 для слияния" }, rarity: "rare", class: "fusion",
    price: 2100, priceUsd: 49, fee: 1, royalty: 0, utility: 40, demand: 64, liquidity: 78, owner: "0xee…90" },
  { id: "L12", type: "buy", kind: { en: "Season Pass", ru: "Сезонный Пропуск" }, name: { en: "Bull Pass · Premium", ru: "Бычий Пропуск · Premium" },
    meta: { en: "Full season unlocks", ru: "Открыто весь сезон" }, class: "seasonal",
    price: 50000, priceUsd: 1175, fee: 0, royalty: 0, utility: 95, demand: 99, liquidity: 99, owner: "vault:OFFICIAL", tag: { en: "LIMITED", ru: "ЛИМИТ" } },
];

/* ============================================================
   ECONOMY — tokenomics, sinks, two-circuit model
   ============================================================ */
export const SINKS: { label: Tx; share: number; tone: Tone }[] = [
  { label: { en: "Infrastructure build & upkeep", ru: "Стройка и обслуживание инфры" }, share: 26, tone: "acid" },
  { label: { en: "Guild insurance pools", ru: "Страховые пулы гильдий" }, share: 18, tone: "cyan" },
  { label: { en: "Seasonal expeditions", ru: "Сезонные экспедиции" }, share: 16, tone: "gold" },
  { label: { en: "Risk pools vs. shocks", ru: "Риск-пулы от шоков" }, share: 14, tone: "pink" },
  { label: { en: "Governance staking", ru: "Стейкинг управления" }, share: 12, tone: "violet" },
  { label: { en: "Creator publish bonds", ru: "Бонды публикации креаторов" }, share: 8, tone: "ok" },
  { label: { en: "Repair fees & event launch", ru: "Ремонты и запуск событий" }, share: 6, tone: "warn" },
];

export const FAUCETS: { label: Tx; share: number; tone: Tone }[] = [
  { label: { en: "Season rewards (capped)", ru: "Сезонные награды (с потолком)" }, share: 52, tone: "acid" },
  { label: { en: "Reputation grants", ru: "Гранты за репутацию" }, share: 24, tone: "cyan" },
  { label: { en: "Expedition yield", ru: "Доход с экспедиций" }, share: 16, tone: "gold" },
  { label: { en: "Creator royalties", ru: "Роялти креаторов" }, share: 8, tone: "violet" },
];

/* ============================================================
   STORE / MONETIZATION
   ============================================================ */
export type StoreGroup = "currency" | "pass" | "booster" | "cosmetic" | "drop" | "insurance";
export const STORE_GROUPS: { id: StoreGroup; label: Tx; icon: string; tone: Tone }[] = [
  { id: "currency", label: { en: "$FOLD & Resources", ru: "$FOLD и Ресурсы" }, icon: "💎", tone: "acid" },
  { id: "pass", label: { en: "Passes & Premium", ru: "Пропуски и Premium" }, icon: "🎫", tone: "gold" },
  { id: "booster", label: { en: "Boosters", ru: "Бустеры" }, icon: "⚡", tone: "cyan" },
  { id: "cosmetic", label: { en: "Cosmetics", ru: "Косметика" }, icon: "🎨", tone: "violet" },
  { id: "drop", label: { en: "Limited Drops", ru: "Лимитированные Дропы" }, icon: "🔥", tone: "pink" },
  { id: "insurance", label: { en: "Insurance & Bonds", ru: "Страховки и Бонды" }, icon: "🛡", tone: "ok" },
];

export const STORE_ITEMS: {
  id: string; group: StoreGroup; name: Tx; sub: Tx; price: number; oldPrice?: number;
  tag?: Tx; tone: Tone; best?: boolean; perks: Tx[]; highlight?: boolean;
}[] = [
  { id: "S1", group: "currency", name: { en: "Starter Fold Pack", ru: "Стартер Пак $FOLD" }, sub: { en: "12,500 $FOLD + 2 boosts", ru: "12 500 $FOLD + 2 буста" }, price: 4.99, tone: "acid", perks: [{ en: "Best value/credit", ru: "Лучшее за монету" }] },
  { id: "S2", group: "currency", name: { en: "Operator Stash", ru: "Запас Оператора" }, sub: { en: "60,000 $FOLD + energy refill", ru: "60 000 $FOLD + энергия" }, price: 19.99, oldPrice: 24.99, tone: "gold", best: true, tag: { en: "BEST VALUE", ru: "ВЫГОДНО" }, perks: [{ en: "+20% bonus $FOLD", ru: "+20% бонус $FOLD" }, { en: "Instant energy refill", ru: "Мгновенное восстановление" }] },
  { id: "S3", group: "currency", name: { en: "Whale Vault", ru: "Хранилище Кита" }, sub: { en: "320,000 $FOLD + cosmetics", ru: "320 000 $FOLD + косметика" }, price: 99.99, tone: "pink", perks: [{ en: "VIP cosmetic pack", ru: "VIP косметика" }, { en: "Priority support", ru: "Приоритет поддержки" }] },
  { id: "S4", group: "pass", name: { en: "Bull Season Pass", ru: "Бычий Сезонный Пропуск" }, sub: { en: "Unlock all season rewards", ru: "Все награды сезона" }, price: 14.99, tone: "gold", tag: { en: "POPULAR", ru: "ХИТ" }, highlight: true, perks: [{ en: "100+ tier rewards", ru: "100+ наград по уровням" }, { en: "Exclusive seasonal devices", ru: "Сезонные устройства" }, { en: "Daily claim streaks", ru: "Ежедневные стрики" }] },
  { id: "S5", group: "pass", name: { en: "Inner Circle (Monthly)", ru: "Внутренний Круг (в мес.)" }, sub: { en: "Subscription · recurring", ru: "Подписка · регулярно" }, price: 9.99, tone: "violet", perks: [{ en: "+15% yield on all vaults", ru: "+15% доход хранилищ" }, { en: "Auto-insurance discount", ru: "Скидка на страховки" }, { en: "No ads, ever", ru: "Без рекламы, совсем" }] },
  { id: "S6", group: "booster", name: { en: "Yield Multiplier x2", ru: "Множитель Дохода x2" }, sub: { en: "24 hours", ru: "На 24 часа" }, price: 2.99, tone: "cyan", perks: [{ en: "Double vault yield", ru: "Двойной доход" }] },
  { id: "S7", group: "booster", name: { en: "Build Accelerator", ru: "Ускоритель Стройки" }, sub: { en: "Skip 12h on any upgrade", ru: "Скип 12ч на апгрейд" }, price: 1.99, tone: "cyan", perks: [{ en: "Instant completion", ru: "Мгновенное завершение" }] },
  { id: "S8", group: "cosmetic", name: { en: "Neon Node Skin: Acid", ru: "Скин Узла: Кислота" }, sub: { en: "Legendary cosmetic", ru: "Легендарная косметика" }, price: 7.99, tone: "acid", perks: [{ en: "Visible in multiplayer", ru: "Виден в мультиплеере" }] },
  { id: "S9", group: "drop", name: { en: "Genesis Founder Crate", ru: "Крейтер Генезис-Основателя" }, sub: { en: "1 of 1,000 · mythic drop", ru: "1 из 1 000 · мифик" }, price: 49.99, tone: "pink", tag: { en: "ONLY 217 LEFT", ru: "ОСТАЛОСЬ 217" }, highlight: true, perks: [{ en: "Guaranteed mythic device", ru: "Гарантированный мифик" }, { en: "Founder badge forever", ru: "Бейдж основателя навсегда" }] },
  { id: "S10", group: "insurance", name: { en: "Mega-Breach Cover", ru: "Покрытие Мега-Прорыва" }, sub: { en: "Full portfolio · 1 season", ru: "Весь портфель · 1 сезон" }, price: 11.99, tone: "ok", perks: [{ en: "Reimburses shock losses", ru: "Возвращает потери от шоков" }, { en: "Priority recovery", ru: "Приоритет восстановления" }] },
];

export const VIP_TIERS = [
  { tier: { en: "Citizen", ru: "Гражданин" }, spend: 0, perk: { en: "Base access", ru: "Базовый доступ" }, tone: "mut" as Tone, you: false },
  { tier: { en: "Operator", ru: "Оператор" }, spend: 50, perk: { en: "+5% yield", ru: "+5% доход" }, tone: "cyan" as Tone, you: false },
  { tier: { en: "Magnate", ru: "Магнат" }, spend: 250, perk: { en: "+12% yield, daily drop", ru: "+12% доход, дневной дроп" }, tone: "gold" as Tone, you: true },
  { tier: { en: "Whale", ru: "Кит" }, spend: 1000, perk: { en: "+20% yield, VIP support", ru: "+20% доход, VIP-поддержка" }, tone: "pink" as Tone, you: false },
  { tier: { en: "Fold Sovereign", ru: "Суверен The Fold" }, spend: 5000, perk: { en: "Custom cosmetics, governance weight", ru: "Своя косметика, вес в управлении" }, tone: "violet" as Tone, you: false },
];

/* ============================================================
   GOVERNANCE — proposals
   ============================================================ */
export const PROPOSALS = [
  { id: "P1", title: { en: "Cap daily faucet emissions at 4%", ru: "Потолок крана эмиссии на 4%" }, by: "guild:BULWARK", tone: "ok" as Tone, yes: 71, no: 29, quorum: true, status: { en: "Voting", ru: "Голосование" } },
  { id: "P2", title: { en: "Add 2% burn on all marketplace fees", ru: "Сжигать 2% с комиссий рынка" }, by: "@archivist_99", tone: "gold" as Tone, yes: 64, no: 36, quorum: true, status: { en: "Voting", ru: "Голосование" } },
  { id: "P3", title: { en: "Insurance payout during Stable Fracture", ru: "Выплаты страховок при Трещине Стейбла" }, by: "guild:NIGHTWHALE", tone: "cyan" as Tone, yes: 58, no: 42, quorum: false, status: { en: "Draft", ru: "Черновик" } },
  { id: "P4", title: { en: "Penalize empty-node squatting", ru: "Штраф за занятые пустые узлы" }, by: "council:BUILDERS", tone: "pink" as Tone, yes: 49, no: 51, quorum: true, status: { en: "Failing", ru: "Проваливается" } },
];

/* ============================================================
   THE SPIN — core mechanic  (you are a Power Broker, not a trader)
   NOT gambling. You don't bet blind — you BUILD AN EDGE.
   Real market data is the seed; your skill (reading the tape),
   your devices (intel) and your helpers (spin team) raise your
   win probability ABOVE a coin-flip. Losses are PARTIAL by
   default, so one bad read never wipes hard-earned $FOLD.
   This is the political heart of PUCK FOLITICS.
   ============================================================ */
export type WinWhen = "up" | "down" | "volatile" | "any";
export type CardTier = "safe" | "standard" | "wild";

export type SpinCard = {
  id: string;
  name: Tx;
  icon: string;
  tone: Tone;
  faction: FactionId;
  tag: Tx;        // "Bull" / "Bear" / "Chaos" / "Safe"
  flavour: Tx;    // satirical one-liner
  winWhen: WinWhen;
  mult: number;   // payout multiplier on a WIN (e.g. 1.8 = +80% profit)
  lossPct: number;// fraction of stake LOST on a wrong call (0.35 = lose 35%, NOT rekt)
  tier: CardTier;
};

export const SPIN_CARDS: SpinCard[] = [
  { id: "copium", name: { en: "This Is Fine", ru: "Всё Норм" }, icon: "🔥", tone: "warn", faction: "speculators",
    tag: { en: "Safe", ru: "Сейф" }, flavour: { en: "You're on fire. You deny it. Statistically comforting.", ru: "Ты горишь. Ты это отрицаешь. Статистически утешительно." },
    winWhen: "any", mult: 1.25, lossPct: 0.15, tier: "safe" },
  { id: "fundamental", name: { en: "Fundamentals", ru: "Фундаментал" }, icon: "📊", tone: "cyan", faction: "builders",
    tag: { en: "Bull", ru: "Бычья" }, flavour: { en: "Read the whitepaper nobody else did. Boring. Pays.", ru: "Прочитай whitepaper, который никто не читал. Скучно. Платит." },
    winWhen: "up", mult: 1.45, lossPct: 0.25, tier: "safe" },
  { id: "moon", name: { en: "To The Moon", ru: "На Луну" }, icon: "🚀", tone: "gold", faction: "speculators",
    tag: { en: "Bull", ru: "Бычья" }, flavour: { en: "Number go up. It's the only prayer that always worked.", ru: "Число вверх. Единственная молитва, что всегда работала." },
    winWhen: "up", mult: 1.8, lossPct: 0.35, tier: "standard" },
  { id: "fud", name: { en: "Doom Spiral", ru: "Спираль Судного Дня" }, icon: "☠", tone: "danger", faction: "raiders",
    tag: { en: "Bear", ru: "Медвежья" }, flavour: { en: "Manufacture panic, harvest the exits.", ru: "Произведи панику, собери урожай с выходов." },
    winWhen: "down", mult: 1.7, lossPct: 0.35, tier: "standard" },
  { id: "whale", name: { en: "Whale Accumulating", ru: "Кит Накапливает" }, icon: "🐋", tone: "cyan", faction: "speculators",
    tag: { en: "Bull", ru: "Бычья" }, flavour: { en: "Follow the wallet that moves the world.", ru: "Иди за кошельком, что двигает мир." },
    winWhen: "up", mult: 1.6, lossPct: 0.30, tier: "standard" },
  { id: "exit", name: { en: "Exit Liquidity", ru: "Ликвидность на Выход" }, icon: "💀", tone: "danger", faction: "raiders",
    tag: { en: "Bear", ru: "Медвежья" }, flavour: { en: "You're not the liquidity. You provide it.", ru: "Ты не ликвидность. Ты её поставляешь." },
    winWhen: "down", mult: 2.4, lossPct: 0.55, tier: "wild" },
  { id: "hopium", name: { en: "Hopium Hit", ru: "Доза Хоупиума" }, icon: "💨", tone: "violet", faction: "archivists",
    tag: { en: "Chaos", ru: "Хаос" }, flavour: { en: "Inhale the copium. Exhale the delusion. Repeat.", ru: "Вдохни копиум. Выдохни иллюзию. Повтори." },
    winWhen: "volatile", mult: 2.6, lossPct: 0.55, tier: "wild" },
  { id: "rumor", name: { en: "Trust Me Bro", ru: "Поверь Брат" }, icon: "🤝", tone: "pink", faction: "raiders",
    tag: { en: "Chaos", ru: "Хаос" }, flavour: { en: "Source: dude, trust me. High variance, high comedy.", ru: "Источник: чувак, верь мне. Высокая дисперсия, высокий Comedy." },
    winWhen: "volatile", mult: 3.2, lossPct: 0.60, tier: "wild" },
];

export const TIER_META: Record<CardTier, { label: Tx; tone: Tone }> = {
  safe:     { label: { en: "Safe", ru: "Сейф" }, tone: "ok" },
  standard: { label: { en: "Standard", ru: "Обычная" }, tone: "gold" },
  wild:     { label: { en: "Wild", ru: "Дикая" }, tone: "pink" },
};

/* ---------- INTEL: the real-market READ you learn to interpret ---------- */
export type Intel = {
  lean: "up" | "down" | "flat" | "volatile";
  confidence: number; // 0..1  how clear/clean the signal is
  strength: number;   // 0..100 momentum magnitude
  label: Tx;
  tip: Tx;            // what this means for the player
};

export function readIntel(realChg: number, vol: number, sentiment: number): Intel {
  const a = Math.abs(realChg);
  let lean: Intel["lean"] = "flat";
  if (a < 1.0 && vol > 4.2) lean = "volatile";
  else if (realChg > 1.0) lean = "up";
  else if (realChg < -1.0) lean = "down";
  else lean = "flat";

  // confidence: a clear + coordinated move (direction agrees with sentiment) = high
  const agrees = (realChg > 0 && sentiment > 50) || (realChg < 0 && sentiment < 50);
  let confidence = 0.45 + a * 0.06 + (agrees ? 0.12 : -0.06) + (a > 3 ? 0.1 : 0);
  confidence = Math.max(0.32, Math.min(0.92, confidence));
  const strength = Math.round(Math.min(100, a * 12 + vol * 6));

  const map: Record<Intel["lean"], { label: Tx; tip: Tx }> = {
    up: {
      label: { en: "Bullish momentum", ru: "Бычий моментум" },
      tip: { en: "Fresh buying. Up-cards (🚀📊🐋) get an edge here.", ru: "Свежие покупки. Бычьи карты (🚀📊🐋) тут имеют перевес." },
    },
    down: {
      label: { en: "Bearish pressure", ru: "Медвежье давление" },
      tip: { en: "Sellers in control. Down-cards (☠💀) get an edge here.", ru: "Продавцы рулят. Медвежьи карты (☠💀) тут имеют перевес." },
    },
    volatile: {
      label: { en: "Choppy / violent", ru: "Буря / волатильно" },
      tip: { en: "Big swings both ways. Chaos-cards (💨🤝) shine here.", ru: "Сильные рывки в обе стороны. Карты хаоса (💨🤝) тут в силе." },
    },
    flat: {
      label: { en: "Uncertain / drifting", ru: "Неопределённость" },
      tip: { en: "No clear trend. Safest play: This Is Fine (🔥).", ru: "Чёткого тренда нет. Самый сейф: Всё Норм (🔥)." },
    },
  };
  return { lean, confidence, strength, ...map[lean] };
}

/* ---------- HELPERS: your spin team. Tilt odds in your favour. ---------- */
export type Helper = {
  id: string; name: Tx; icon: string; tone: Tone;
  helps: WinWhen;   // which card direction it boosts
  bonus: number;    // added to win probability
  cost: number;     // in Influence points
};

export const HELPERS: Helper[] = [
  { id: "shill", name: { en: "Shill Squad", ru: "Шилл-Команда" }, icon: "📣", tone: "gold", helps: "up", bonus: 0.10, cost: 8 },
  { id: "fudcrew", name: { en: "FUD Cartel", ru: "FUD-Картель" }, icon: "🕷", tone: "danger", helps: "down", bonus: 0.10, cost: 8 },
  { id: "hype", name: { en: "Hype Engine", ru: "Хайп-Движок" }, icon: "💥", tone: "pink", helps: "volatile", bonus: 0.10, cost: 8 },
  { id: "calm", name: { en: "Calm Fund", ru: "Спокойный Фонд" }, icon: "🕊", tone: "ok", helps: "any", bonus: 0.07, cost: 6 },
];

/* ---------- EDGE: your real win probability (shown transparently) ---------- */
export type Edge = {
  prob: number;        // 0..1 win probability
  base: number;        // market-aligned base
  intelBonus: number;  // reading the tape right
  helperBonus: number; // deployed team
  aligned: boolean;    // did the player match the intel?
};

export function computeEdge(card: SpinCard, intel: Intel, activeHelpers: Helper[], deviceEdgeBonus = 0, deviceIntel = 0): Edge {
  // base probability from how the card aligns with real market continuation
  let base: number;
  const realUp = intel.lean === "up";
  const realDown = intel.lean === "down";
  const realVol = intel.lean === "volatile";
  if (card.winWhen === "up") base = realUp ? 0.60 : realDown ? 0.42 : 0.50;
  else if (card.winWhen === "down") base = realDown ? 0.60 : realUp ? 0.42 : 0.50;
  else if (card.winWhen === "volatile") base = realVol ? 0.56 : 0.42;
  else base = 0.74; // "any"

  // reading the tape right: matching card direction to intel raises odds.
  // equipped INTEL devices raise confidence (you read the tape sharper).
  const conf = Math.min(0.96, intel.confidence + deviceIntel);
  const aligned =
    (card.winWhen === "up" && realUp) ||
    (card.winWhen === "down" && realDown) ||
    (card.winWhen === "volatile" && realVol) ||
    card.winWhen === "any";
  const intelBonus = aligned ? conf * 0.16 : -0.08;

  // helpers that match the card stack
  const helperBonus = activeHelpers
    .filter((h) => h.helps === card.winWhen || h.helps === "any")
    .reduce((s, h) => s + h.bonus, 0);

  const prob = Math.max(0.15, Math.min(0.92, base + intelBonus + helperBonus + deviceEdgeBonus));
  return { prob, base, intelBonus, helperBonus, aligned };
}

/* ---------- the BREAKING signal (kept for the ticker / flavour) ---------- */
export type SpinSignal = {
  headline: Tx; asset: string; realChg: number; vol: number;
  lean: "up" | "down" | "flat"; tone: Tone;
};
export function buildSignal(btcChg: number, vol: number): SpinSignal {
  const lean: SpinSignal["lean"] = btcChg > 1.2 ? "up" : btcChg < -1.2 ? "down" : "flat";
  const tone: Tone = btcChg > 1.2 ? "ok" : btcChg < -1.2 ? "danger" : "warn";
  const c = Math.abs(btcChg).toFixed(1);
  const headline: Tx =
    btcChg > 4 ? { en: `BTC ripped +${c}%. CT is calling the top of the top of the top.`, ru: `BTC рванул +${c}%. Крипто-твит зовёт вершину вершины вершины.` }
    : btcChg > 1.2 ? { en: `BTC +${c}%. The crowd is "cautiously optimistic", which is suspicious.`, ru: `BTC +${c}%. Толпа «осторожно оптимистична», а это подозрительно.` }
    : btcChg < -4 ? { en: `BTC dumped -${c}%. The buy-the-dippers are now providing the dip.`, ru: `BTC просел -${c}%. «Скупающие просадку» теперь и создают эту просадку.` }
    : btcChg < -1.2 ? { en: `BTC -${c}%. Someone's quietly selling into your panic.`, ru: `BTC -${c}%. Кто-то тихо продаёт в твою панику.` }
    : { en: `BTC is flat. The market hasn't decided whether to panic yet.`, ru: `BTC стоит на месте. Рынок ещё не решил, паниковать или нет.` };
  return { headline, asset: "BTC", realChg: btcChg, vol, lean, tone };
}

/* ---------- RESULT ---------- */
export type SpinResult = {
  win: boolean;
  edgeProb: number;
  move: number;     // flavour move %
  delta: number;    // net $FOLD change
  lossCapped: boolean;
  credDelta: number;
  lesson: Tx;       // what the player should learn
  line: Tx;         // satirical outcome line
};

// Resolve on computed EDGE. Partial loss by default; hedge caps it further.
// lossMult: equipped DEFENSE devices multiply the loss fraction down (e.g. 0.78).
export function resolveSpin(
  card: SpinCard, stake: number, edge: Edge, hedge: boolean, lossMult = 1, rng = Math.random
): SpinResult {
  const win = rng() < edge.prob;
  // hedge: split stake into two cells → smaller win, tiny loss
  const mult = hedge ? card.mult * 0.72 : card.mult;
  let lossFrac = (hedge ? card.lossPct * 0.4 : card.lossPct) * lossMult;
  const lossCapped = lossFrac < 0.3;

  // flavour move (so the line reads naturally)
  const dir = card.winWhen === "down" ? -1 : 1;
  const move = win
    ? dir * (Math.abs(edge.base - 0.5) * 6 + 0.6 + rng() * 1.5)
    : -dir * (0.4 + rng() * 1.6);

  if (win) {
    const profit = Math.round(stake * (mult - 1));
    // cred reward is bigger when you won DESPITE low odds (real skill), smaller on easy/safe
    const credDelta = Math.round(2 + (0.85 - Math.min(edge.prob, 0.85)) * 18);
    return {
      win: true, edgeProb: edge.prob, move, delta: profit, lossCapped, credDelta,
      lesson: edge.aligned
        ? { en: "You read the tape right. Aligned cards win more often — that's the skill.", ru: "Ты правильно прочитал ленту. Совпадающие карты побеждают чаще — в этом скилл." }
        : { en: "Lucky one. But going against the market long-term burns you.", ru: "Повезло. Но играть против рынка долго — выгорит тебя." },
      line: card.winWhen === "any"
        ? { en: `The crowd bought your calm. Clean +${profit}. Barely tried.`, ru: `Толпа купила твоё спокойствие. Чисто +${profit}. Почти не старался.` }
        : { en: `Your narrative landed. Crowd followed. +${profit}.`, ru: `Твой нарратив зашёл. Толпа пошла за ним. +${profit}.` },
    };
  } else {
    const loss = Math.round(stake * lossFrac);
    const credDelta = edge.aligned ? -2 : -4; // mild; reading right but unlucky ≠ punished hard
    return {
      win: false, edgeProb: edge.prob, move, delta: -loss, lossCapped, credDelta,
      lesson: edge.aligned
        ? { en: "Right read, unlucky round. Edge held — keep at it, it pays over time.", ru: "Читал верно, раунд не повезло. Перевес на месте — продолжай, окупится." }
        : { en: "You fought the trend. Match the intel next time.", ru: "Ты шёл против тренда. В следующий раз играй по интела." },
      line: hedge
        ? { en: `Hedge saved you. Only -${loss}. Lesson logged.`, ru: `Хедж спас. Всего -${loss}. Урок записан.` }
        : { en: `Wrong call, -${loss}. But you kept most of your stack. Adapt.`, ru: `Мимо, -${loss}. Но основное осталось. Адаптируйся.` },
    };
  }
}

// AI rivals also spin — for the "the whole table is playing" feel.
export const SPIN_TABLE = [
  { name: { en: "MoonBoy Maxi", ru: "МунБой Макси" }, lean: "up" as const, icon: "📈" },
  { name: { en: "Doom Caller", ru: "Дум-Звонарь" }, lean: "down" as const, icon: "☠" },
  { name: { en: "Anon Whale", ru: "Анон-Кит" }, lean: "volatile" as const, icon: "🐋" },
  { name: { en: "Diamond Hands Dee", ru: "Даймонд Ди" }, lean: "up" as const, icon: "💎" },
];

export { tx, type Tx, type Lang };
