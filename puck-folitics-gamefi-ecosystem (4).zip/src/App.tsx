import { AppProvider, useApp } from "./store";
import { Layout } from "./components/Layout";
import { Dashboard } from "./screens/Dashboard";
import { WarRoom } from "./screens/WarRoom";
import { Fold } from "./screens/Fold";
import { Devices } from "./screens/Devices";
import { Marketplace } from "./screens/Marketplace";
import { Factions } from "./screens/Factions";
import { Store } from "./screens/Store";

function Router() {
  const { view } = useApp();
  switch (view) {
    case "command": return <Dashboard />;
    case "warroom": return <WarRoom />;
    case "fold": return <Fold />;
    case "devices": return <Devices />;
    case "marketplace": return <Marketplace />;
    case "factions": return <Factions />;
    case "store": return <Store />;
    default: return <Dashboard />;
  }
}

export default function App() {
  return (
    <AppProvider>
      <Layout>
        <Router />
      </Layout>
    </AppProvider>
  );
}
