import { type Tx } from "../i18n";

/* ============================================================
   REAL-TIME MARKET INTEGRATION  (the virality engine)
   - Live:  CoinGecko simple/price (no key, CORS)  +  alternative.me Fear&Greed
   - Fallback: simulated walk (shown honestly as "SIMULATED")
   The Fold reads REAL markets and reshapes itself accordingly:
   regime, world pressure, device yields, shock probability all derive
   from what is actually happening in crypto right now.
   ============================================================ */

export interface CoinTick {
  sym: string; name: string; price: number; chg: number; spark: number[];
}

export interface MarketData {
  live: boolean;
  source: string;
  ts: number;
  coins: CoinTick[];
  btcChg: number;
  sentiment: number;       // 0-100 internal pressure/greed
  fearGreed: { value: number; classification: string } | null;
  regime: "bull" | "bear" | "rotation" | "crackdown";
  regimeTone: "ok" | "danger" | "gold" | "warn";
  regimeLabel: Tx;
}

const COINS = [
  { id: "bitcoin", sym: "BTC", name: "Bitcoin", base: 68000 },
  { id: "ethereum", sym: "ETH", name: "Ethereum", base: 3500 },
  { id: "solana", sym: "SOL", name: "Solana", base: 168 },
  { id: "binancecoin", sym: "BNB", name: "BNB", base: 605 },
];

const clamp = (n: number, a: number, b: number) => Math.max(a, Math.min(b, n));

function buildSpark(seed: number, base: number, points = 24): number[] {
  const out: number[] = [];
  let v = base * (0.985 + (Math.sin(seed) * 0.5 + 0.5) * 0.03);
  for (let i = 0; i < points; i++) {
    v = v * (1 + (Math.sin(seed + i * 1.7) * 0.5 + (Math.random() - 0.5)) * 0.012);
    out.push(v);
  }
  return out;
}

function deriveRegime(btcChg: number): MarketData {
  let regime: MarketData["regime"];
  let regimeTone: MarketData["regimeTone"];
  let regimeLabel: Tx;
  if (btcChg > 3.5) {
    regime = "bull"; regimeTone = "ok";
    regimeLabel = { en: "Bull Regime", ru: "Бычий Режим" };
  } else if (btcChg < -3.5) {
    regime = "bear"; regimeTone = "danger";
    regimeLabel = { en: "Bear Regime", ru: "Медвежий Режим" };
  } else if (Math.abs(btcChg) < 1.2) {
    regime = "rotation"; regimeTone = "gold";
    regimeLabel = { en: "Rotation Regime", ru: "Режим Ротации" };
  } else {
    regime = btcChg < 0 ? "crackdown" : "bull";
    regimeTone = btcChg < 0 ? "warn" : "ok";
    regimeLabel = btcChg < 0
      ? { en: "Choppy / Caution", ru: "Трепет / Осторожно" }
      : { en: "Bull Regime", ru: "Бычий Режим" };
  }
  const sentiment = clamp(50 + btcChg * 7, 4, 96);
  return { regime, regimeTone, regimeLabel, sentiment, btcChg } as MarketData;
}

export async function fetchMarket(): Promise<MarketData> {
  // Try the real APIs.
  try {
    const priceUrl =
      "https://api.coingecko.com/api/v3/simple/price?ids=" +
      COINS.map((c) => c.id).join(",") +
      "&vs_currencies=usd&include_24hr_change=true";
    const [priceRes, fngRes] = await Promise.allSettled([
      fetch(priceUrl, { headers: { accept: "application/json" } }),
      fetch("https://api.alternative.me/fng/?limit=1", { headers: { accept: "application/json" } }),
    ]);

    if (priceRes.status !== "fulfilled") throw new Error("price failed");
    const priceJson = await priceRes.value.json();

    const coins: CoinTick[] = COINS.map((c, i) => {
      const node = priceJson[c.id];
      const price = node?.usd ?? c.base;
      const chg = node?.usd_24h_change ?? 0;
      return { sym: c.sym, name: c.name, price, chg, spark: buildSpark(i + Date.now() / 1e9, price) };
    });

    const btcChg = coins[0].chg;
    const base = deriveRegime(btcChg);

    let fearGreed: MarketData["fearGreed"] = null;
    if (fngRes.status === "fulfilled") {
      try {
        const fj = await fngRes.value.json();
        const d = fj?.data;
        if (d?.value) {
          fearGreed = { value: Number(d.value), classification: String(d.value_classification) };
        }
      } catch { /* ignore fng parse */ }
    }

    return {
      ...base,
      live: true,
      source: "CoinGecko + alt.me",
      ts: Date.now(),
      coins,
      fearGreed,
    };
  } catch {
    return simulateMarket();
  }
}

let simState: { prices: Record<string, number>; chg: Record<string, number> } | null = null;

export function simulateMarket(): MarketData {
  if (!simState) {
    simState = {
      prices: Object.fromEntries(COINS.map((c) => [c.sym, c.base])),
      chg: Object.fromEntries(COINS.map((c) => [c.sym, (Math.random() - 0.45) * 6])),
    };
  }
  // walk a little each refresh
  const coins: CoinTick[] = COINS.map((c, i) => {
    const drift = (Math.random() - 0.5) * 0.004;
    simState!.prices[c.sym] = simState!.prices[c.sym] * (1 + drift);
    simState!.chg[c.sym] = clamp(simState!.chg[c.sym] + (Math.random() - 0.5) * 1.4, -12, 12);
    return {
      sym: c.sym,
      name: c.name,
      price: simState!.prices[c.sym],
      chg: simState!.chg[c.sym],
      spark: buildSpark(i + Date.now() / 1e9, simState!.prices[c.sym]),
    };
  });
  const btcChg = coins[0].chg;
  const base = deriveRegime(btcChg);
  const fgVal = clamp(50 + btcChg * 6, 6, 94);
  return {
    ...base,
    live: false,
    source: "simulated feed",
    ts: Date.now(),
    coins,
    fearGreed: {
      value: Math.round(fgVal),
      classification: fgVal > 72 ? "Greed" : fgVal > 55 ? "Optimism" : fgVal > 45 ? "Neutral" : fgVal > 25 ? "Fear" : "Extreme Fear",
    },
  };
}

/* News generator: satirical headlines that reference REAL price action.
   This is the "stories people retell" virality surface. */
export function buildNews(m: MarketData): Tx[] {
  const btc = m.coins[0];
  const sign = btc.chg >= 0 ? "+" : "";
  const up = btc.chg >= 0;
  const eth = m.coins[1];
  const fg = m.fearGreed ? Math.round(m.fearGreed.value) : 50;
  const regimeWord = m.regime === "bull"
    ? { en: "the bulls are loud again", ru: "быки снова горланят" }
    : m.regime === "bear"
    ? { en: "everyone's suddenly an architect of patience", ru: "все внезапно стали архитекторами терпения" }
    : m.regime === "rotation"
    ? { en: "capital is looking for a new home", ru: "капитал ищет новый дом" }
    : { en: "nobody knows anything and that's the thesis", ru: "никто ничего не знает — вот и весь тезис" };

  return [
    {
      en: `BTC ${sign}${btc.chg.toFixed(2)}% — ${up ? "Citadel desks pop champagne early" : "Citadel desks cancel lunch and their feelings"}.`,
      ru: `BTC ${sign}${btc.chg.toFixed(2)}% — столы Цитадели ${up ? "открывают шампанское пораньше" : "отменяют ланч и собственные чувства"}.`,
    },
    {
      en: `ETH ${sign}${eth.chg.toFixed(2)}% — Vita Lick is "calm, just refactoring the universe, again."`,
      ru: `ETH ${sign}${eth.chg.toFixed(2)}% — Вита Лик «спокоен, просто переписывает вселенную, снова».`,
    },
    {
      en: `World Sentiment reads ${fg} (${m.fearGreed?.classification}). In The Fold, ${regimeWord.en}.`,
      ru: `Настроение мира: ${fg} (${m.fearGreed?.classification}). В The Fold ${regimeWord.ru}.`,
    },
    {
      en: `Whale Tracker pings a 2014 wallet. Nothing happens. Forum Zero panics for sport.`,
      ru: `Трекер китов ловит кошелёк 2014. Ничего не происходит. Форум Зеро паникует чисто от скуки.`,
    },
    {
      en: `Madame Peg denies rumors. The peg holds. The peg always holds. (The peg is fine.)`,
      ru: `Мадам Пег опровергает слухи. По́г держится. По́г всегда держится. (С по́гом всё хорошо.)`,
    },
    {
      en: `Don Trumpoid is "considering" a statement. The entire meme sector pre-pumps on vibes.`,
      ru: `Дон Трампоид «обдумывает» заявление. Весь мем-сектор пампится заранее на чистых вайбах.`,
    },
    {
      en: `Raiders spotted circling Port of Bridges. "We're just looking," they say, holding tools.`,
      ru: `Рейдеры замечены у Порта Мостов. «Мы просто смотрим», — говорят они, сжимая инструменты.`,
    },
    {
      en: `Ashen Chain archaeologists dug up a 2021 collection. It's still worthless. They framed it.`,
      ru: `Археологи Пепельной Цепи откопали коллекцию 2021. Она всё ещё ничего не стоит. Они оформили её в рамку.`,
    },
  ];
}
