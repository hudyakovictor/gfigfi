import { type ReactNode } from "react";
import { cn } from "../utils/cn";

/* ---------- tone system (full static class strings so Tailwind JIT picks them up) ---------- */
export type Tone = "acid" | "cyan" | "gold" | "violet" | "pink" | "danger" | "ok" | "warn" | "mut";
export const TONE: Record<Tone, { text: string; bg: string; soft: string; border: string; dot: string; ring: string }> = {
  acid:   { text: "text-acid",   bg: "bg-acid",   soft: "bg-acid/10",   border: "border-acid/40",   dot: "bg-acid",   ring: "ring-acid/40" },
  cyan:   { text: "text-cyan",   bg: "bg-cyan",   soft: "bg-cyan/10",   border: "border-cyan/40",   dot: "bg-cyan",   ring: "ring-cyan/40" },
  gold:   { text: "text-gold",   bg: "bg-gold",   soft: "bg-gold/10",   border: "border-gold/40",   dot: "bg-gold",   ring: "ring-gold/40" },
  violet: { text: "text-violet", bg: "bg-violet", soft: "bg-violet/10", border: "border-violet/40", dot: "bg-violet", ring: "ring-violet/40" },
  pink:   { text: "text-pink",   bg: "bg-pink",   soft: "bg-pink/10",   border: "border-pink/40",   dot: "bg-pink",   ring: "ring-pink/40" },
  danger: { text: "text-danger", bg: "bg-danger", soft: "bg-danger/10", border: "border-danger/40", dot: "bg-danger", ring: "ring-danger/40" },
  ok:     { text: "text-ok",     bg: "bg-ok",     soft: "bg-ok/10",     border: "border-ok/40",     dot: "bg-ok",     ring: "ring-ok/40" },
  warn:   { text: "text-warn",   bg: "bg-warn",   soft: "bg-warn/10",   border: "border-warn/40",   dot: "bg-warn",   ring: "ring-warn/40" },
  mut:    { text: "text-mut",    bg: "bg-mut2",   soft: "bg-white/5",   border: "border-edge",      dot: "bg-mut2",   ring: "ring-white/10" },
};

/* ---------- number formatting ---------- */
export const fmtNum = (n: number) => {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1) + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(n >= 10_000 ? 0 : 1) + "k";
  return Math.round(n).toString();
};
export const fmtUsd = (n: number) => "$" + n.toLocaleString("en-US", { maximumFractionDigits: 0 });
export const fmtPrice = (n: number) =>
  n >= 1000 ? "$" + n.toLocaleString("en-US", { maximumFractionDigits: 0 })
  : n >= 1 ? "$" + n.toFixed(2) : "$" + n.toFixed(4);

/* ---------- Panel ---------- */
export function Panel({
  children, className, tone, hover, onClick,
}: { children: ReactNode; className?: string; tone?: Tone; hover?: boolean; onClick?: () => void }) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "panel rounded-xl relative",
        tone && TONE[tone].border,
        hover && "transition-colors hover:border-edge2 cursor-pointer",
        className
      )}
    >
      {children}
    </div>
  );
}

export function SectionHead({
  title, sub, right, icon, tone = "acid",
}: { title: string; sub?: string; right?: ReactNode; icon?: ReactNode; tone?: Tone }) {
  return (
    <div className="flex items-end justify-between gap-3 mb-3">
      <div className="flex items-center gap-2.5 min-w-0">
        {icon && <span className={cn("text-lg leading-none", TONE[tone].text)}>{icon}</span>}
        <div className="min-w-0">
          <h3 className="text-[13px] font-semibold tracking-wide text-ink uppercase truncate">{title}</h3>
          {sub && <p className="text-[11px] text-mut truncate">{sub}</p>}
        </div>
      </div>
      {right}
    </div>
  );
}

/* ---------- Tags / badges ---------- */
export function Tag({
  children, tone = "mut", className, dot, glow,
}: { children: ReactNode; tone?: Tone; className?: string; dot?: boolean; glow?: boolean }) {
  return (
    <span className={cn(
      "inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider border",
      TONE[tone].soft, TONE[tone].border, TONE[tone].text, className
    )}>
      {dot && <span className={cn("w-1.5 h-1.5 rounded-full", TONE[tone].dot, glow && "blink")} />}
      {children}
    </span>
  );
}

export function Dot({ tone = "ok", glow }: { tone?: Tone; glow?: boolean }) {
  return <span className={cn("inline-block w-2 h-2 rounded-full", TONE[tone].dot, glow && "blink")} />;
}

/* ---------- Bar / progress ---------- */
export function Bar({
  value, tone = "acid", className, height = "h-1.5", showLabel,
}: { value: number; tone?: Tone; className?: string; height?: string; showLabel?: boolean }) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div className={cn("flex-1 rounded-full bg-white/5 overflow-hidden", height)}>
        <div className={cn("h-full rounded-full", TONE[tone].bg)} style={{ width: `${Math.max(2, Math.min(100, value))}%` }} />
      </div>
      {showLabel && <span className="text-[11px] tnum text-mut w-9 text-right">{Math.round(value)}</span>}
    </div>
  );
}

/* ---------- KPI ---------- */
export function KPI({
  label, value, sub, tone = "ink", icon,
}: { label: string; value: ReactNode; sub?: ReactNode; tone?: Tone | "ink"; icon?: ReactNode }) {
  return (
    <Panel className="p-3">
      <div className="flex items-center justify-between">
        <span className="text-[10px] uppercase tracking-wider text-mut">{label}</span>
        {icon && typeof tone !== "string" && <span className={cn("text-sm", TONE[tone as Tone]?.text)}>{icon}</span>}
      </div>
      <div className={cn("mt-1 text-xl font-bold tnum", tone === "ink" ? "text-ink" : TONE[tone as Tone].text)}>{value}</div>
      {sub && <div className="text-[11px] text-mut mt-0.5">{sub}</div>}
    </Panel>
  );
}

/* ---------- Buttons ---------- */
export function Btn({
  children, tone = "acid", variant = "solid", size = "md", className, onClick, disabled, full,
}: {
  children: ReactNode; tone?: Tone; variant?: "solid" | "ghost" | "outline";
  size?: "sm" | "md"; className?: string; onClick?: () => void; disabled?: boolean; full?: boolean;
}) {
  const sizes = size === "sm" ? "px-2.5 py-1 text-[11px]" : "px-3.5 py-1.5 text-xs";
  const base = "inline-flex items-center justify-center gap-1.5 rounded-lg font-semibold uppercase tracking-wide transition-all active:scale-[0.97] disabled:opacity-40 disabled:cursor-not-allowed";
  const styles =
    variant === "solid"
      ? cn(TONE[tone].bg, "text-black hover:brightness-110", tone === "gold" && "text-black")
      : variant === "outline"
      ? cn("border bg-transparent hover:bg-white/5", TONE[tone].border, TONE[tone].text)
      : cn("bg-white/5 text-ink hover:bg-white/10 border border-edge");
  return (
    <button onClick={onClick} disabled={disabled} className={cn(base, sizes, styles, full && "w-full", className)}>
      {children}
    </button>
  );
}

/* ---------- Sparkline ---------- */
export function Spark({ data, tone = "acid", w = 64, h = 22, className }: { data: number[]; tone?: Tone; w?: number; h?: number; className?: string }) {
  if (!data.length) return null;
  const min = Math.min(...data), max = Math.max(...data);
  const span = max - min || 1;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - min) / span) * (h - 2) - 1}`).join(" ");
  const c = toneColor(tone);
  return (
    <svg width={w} height={h} className={className} viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
      <polyline points={pts} fill="none" stroke={c} strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

/* ---------- Ring gauge ---------- */
export function Ring({ value, tone = "acid", size = 56, label }: { value: number; tone?: Tone; size?: number; label?: string }) {
  const r = size / 2 - 4;
  const c = 2 * Math.PI * r;
  const off = c - (Math.min(100, value) / 100) * c;
  const col = toneColor(tone);
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={4} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={col} strokeWidth={4} strokeLinecap="round" strokeDasharray={c} strokeDashoffset={off} />
      </svg>
      <div className="absolute text-center">
        <div className="text-sm font-bold tnum leading-none">{Math.round(value)}</div>
        {label && <div className="text-[8px] uppercase text-mut leading-none mt-0.5">{label}</div>}
      </div>
    </div>
  );
}

/* ---------- Tabs ---------- */
export function Tabs({ tabs, active, onChange }: { tabs: { id: string; label: string; count?: number }[]; active: string; onChange: (id: string) => void }) {
  return (
    <div className="flex gap-1 flex-wrap">
      {tabs.map((tb) => (
        <button key={tb.id} onClick={() => onChange(tb.id)}
          className={cn(
            "px-2.5 py-1 rounded-md text-[11px] font-semibold uppercase tracking-wide border transition-colors",
            active === tb.id ? "bg-acid text-black border-acid" : "bg-white/5 text-mut border-edge hover:text-ink hover:border-edge2"
          )}>
          {tb.label}
          {tb.count != null && <span className={cn("ml-1.5 text-[10px]", active === tb.id ? "text-black/60" : "text-mut2")}>{tb.count}</span>}
        </button>
      ))}
    </div>
  );
}

export function Empty({ icon = "·", title, sub }: { icon?: string; title: string; sub?: string }) {
  return (
    <div className="text-center py-8 px-4">
      <div className="text-3xl mb-2 opacity-60">{icon}</div>
      <p className="text-sm font-semibold text-ink">{title}</p>
      {sub && <p className="text-[11px] text-mut mt-1 max-w-xs mx-auto">{sub}</p>}
    </div>
  );
}

/* tone -> hex for svg strokes */
const HEX: Record<Tone, string> = {
  acid: "#c8ff3a", cyan: "#36d6ff", gold: "#ffb43a", violet: "#a78bfa",
  pink: "#ff5d8f", danger: "#ff4757", ok: "#3ddc84", warn: "#ffb43a", mut: "#565d75",
};
export const toneColor = (t: Tone) => HEX[t];
