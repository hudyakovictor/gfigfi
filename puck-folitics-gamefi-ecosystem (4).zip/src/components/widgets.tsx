import { type ReactNode } from "react";
import { cn } from "../utils/cn";
import { useApp } from "../store";
import { tx } from "../i18n";
import {
  STATE_META, DEVICE_LINES, MODULE_META,
  type Device, type Listing, type Tone,
} from "../data";
import { Panel, TONE, Bar, Btn, fmtNum, type Tone as UITone } from "./ui";

export function ScreenHeader({
  title, sub, actions, tone = "acid", icon,
}: { title: string; sub?: string; actions?: ReactNode; tone?: UITone; icon?: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 mb-4 flex-wrap">
      <div className="flex items-center gap-2.5">
        {icon && <span className={cn("text-2xl leading-none", TONE[tone].text)}>{icon}</span>}
        <div>
          <h1 className="text-xl font-bold tracking-tight text-ink leading-none">{title}</h1>
          {sub && <p className="text-[12px] text-mut mt-1">{sub}</p>}
        </div>
      </div>
      {actions && <div className="flex items-center gap-2 flex-wrap">{actions}</div>}
    </div>
  );
}

export function DeviceCard({ device, onClick, equipped }: { device: Device; onClick?: () => void; equipped?: boolean }) {
  const { lang } = useApp();
  const line = DEVICE_LINES.find((l) => l.id === device.line)!;
  const st = STATE_META[device.state];
  return (
    <Panel hover onClick={onClick} className={cn("p-2.5 flex items-center gap-2.5 relative", equipped && "ring-1 ring-acid/40")}>
      {equipped && <span className="absolute -top-1.5 -right-1.5 text-[7px] bg-acid text-black font-black px-1 py-0.5 rounded uppercase z-10">✓</span>}
      <div className={cn("relative w-10 h-10 rounded-lg flex items-center justify-center text-lg shrink-0 border", TONE[line.tone].soft, TONE[line.tone].border)} title={tx(st.label, lang)}>
        {line.icon}
        <span className={cn("absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full border-2 border-panel", TONE[st.tone].dot)} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-[12.5px] font-semibold text-ink leading-tight truncate">{tx(device.name, lang)}</div>
        <div className="flex items-center gap-1.5 mt-0.5">
          <Bar value={device.utility} tone={line.tone} height="h-1" className="flex-1" />
          <span className="text-[9px] font-mono text-mut">{device.utility}</span>
        </div>
      </div>
      <div className="text-right shrink-0">
        <div className="text-[12px] font-bold tnum text-acid leading-none">{fmtNum(device.value)}</div>
        {device.yieldPct ? <div className="text-[10px] font-mono tnum text-ok mt-0.5">+{device.yieldPct}%</div> : <div className="text-[10px] font-mono text-mut2 mt-0.5">—</div>}
      </div>
    </Panel>
  );
}

export function ListingCard({ listing, onClick }: { listing: Listing; onClick?: () => void }) {
  const { lang } = useApp();
  const typeTone: Tone =
    listing.type === "auction" ? "gold" : listing.type === "rent" ? "cyan" :
    listing.type === "offer" ? "violet" : listing.type === "bundle" ? "pink" : "acid";
  return (
    <Panel hover onClick={onClick} className="p-2.5 flex items-center gap-2.5">
      <span className={cn("w-2.5 h-2.5 rounded-full shrink-0", TONE[typeTone].dot)} />
      <div className="min-w-0 flex-1">
        <div className="text-[12.5px] font-semibold text-ink leading-tight truncate">{tx(listing.name, lang)}</div>
        <div className="flex items-center gap-1.5 mt-0.5">
          <span className="text-[9px] text-mut uppercase tracking-wide">{tx(listing.kind, lang)}</span>
          <Bar value={listing.demand} tone="gold" height="h-1" className="flex-1" />
        </div>
      </div>
      <div className="text-right shrink-0">
        <div className="text-[12px] font-bold tnum text-acid leading-none">{fmtNum(listing.price)}</div>
        {listing.bids != null ? <div className="text-[9px] text-mut font-mono mt-0.5">{listing.bids} bids</div> : <div className="text-[9px] text-mut2 font-mono mt-0.5">$FOLD</div>}
      </div>
    </Panel>
  );
}

export function ModuleGrid({ device, onUpgrade, compact }: { device: Device; onUpgrade?: (key: string) => void; compact?: boolean }) {
  const { lang, t } = useApp();
  return (
    <div className={cn("grid gap-1.5", compact ? "grid-cols-3" : "grid-cols-2 sm:grid-cols-3")}>
      {device.parts.map((p) => {
        const meta = MODULE_META[p.key];
        const pst = p.status === "maxed" ? "acid" : p.status === "upgradable" ? "cyan" : p.status === "damaged" ? "danger" : p.status === "boosted" ? "gold" : "mut";
        const pstTone = pst as UITone;
        const blocked = p.status === "locked" || p.status === "maxed";
        return (
          <div key={p.key} className={cn("rounded-lg border p-2 bg-white/[0.02]", TONE[pstTone].border)}>
            <div className="flex items-center justify-between">
              <span className="text-sm">{meta.icon}</span>
              <span className={cn("text-[9px] font-bold uppercase", TONE[pstTone].text)}>{tx(MODULE_STATUS_LBL[p.status], lang)}</span>
            </div>
            <div className="text-[11px] font-semibold text-ink mt-1">{tx(meta.label, lang)}</div>
            <div className="flex items-center justify-between mt-1">
              <span className="text-[10px] font-mono text-mut">Lv {p.level}/{p.max}</span>
              <Bar value={(p.level / p.max) * 100} tone={pstTone} height="h-1" className="w-12" />
            </div>
            {onUpgrade && !compact && (
              <Btn size="sm" tone={pstTone} variant="outline" className="mt-2 w-full"
                disabled={blocked}
                onClick={() => onUpgrade(p.key)}>
                {blocked ? (p.status === "maxed" ? t("Maxed") : t("Locked")) : t("Upgrade")}
              </Btn>
            )}
          </div>
        );
      })}
    </div>
  );
}

const MODULE_STATUS_LBL: Record<string, { en: string; ru: string }> = {
  maxed: { en: "Maxed", ru: "Макс." },
  upgradable: { en: "Upgrade", ru: "Апгрейд" },
  damaged: { en: "Damaged", ru: "Сломан" },
  boosted: { en: "Boosted", ru: "Усилен" },
  locked: { en: "Locked", ru: "Закрыт" },
};
