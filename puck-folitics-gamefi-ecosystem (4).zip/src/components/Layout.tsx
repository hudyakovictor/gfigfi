import { type ReactNode, useState } from "react";
import { cn } from "../utils/cn";
import { useApp, RANKS, type ViewId } from "../store";
import {
  Panel, TONE, type Tone, fmtNum, fmtPrice, Dot, Bar, Btn,
} from "./ui";
import { tx } from "../i18n";
import { FACTIONS } from "../data";
import { Onboarding } from "./Onboarding";

const NAV: { id: ViewId; label: string; icon: string; tone: Tone }[] = [
  { id: "command", label: "Command", icon: "⬡", tone: "acid" },
  { id: "warroom", label: "War Room", icon: "🎩", tone: "pink" },
  { id: "fold", label: "The Fold", icon: "🗺", tone: "cyan" },
  { id: "devices", label: "Devices", icon: "⬢", tone: "violet" },
  { id: "marketplace", label: "Market", icon: "🛒", tone: "gold" },
  { id: "factions", label: "Factions", icon: "⚑", tone: "pink" },
  { id: "store", label: "Store", icon: "💎", tone: "pink" },
];

function Logo() {
  return (
    <div className="flex items-center gap-2.5 px-1">
      <div className="relative w-9 h-9 rounded-lg bg-acid flex items-center justify-center text-black font-black text-lg shadow-[0_0_20px_rgba(200,255,58,0.35)]">
        P
        <span className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-pink border-2 border-base" />
      </div>
      <div className="leading-tight">
        <div className="text-[13px] font-bold tracking-tight text-ink">PUCK FOLITICS</div>
        <div className="text-[9px] uppercase tracking-[0.2em] text-acid font-mono">/ the fold</div>
      </div>
    </div>
  );
}

function NavButton({ item, active, onClick }: { item: typeof NAV[number]; active: boolean; onClick: () => void }) {
  const { t } = useApp();
  return (
    <button
      onClick={onClick}
      title={t(item.label)}
      className={cn(
        "group relative flex items-center gap-3 w-full px-2.5 py-2 rounded-lg transition-all",
        active ? "bg-white/[0.07]" : "hover:bg-white/[0.04]"
      )}
    >
      {active && <span className={cn("absolute left-0 top-1.5 bottom-1.5 w-[3px] rounded-full", TONE[item.tone].bg)} />}
      <span className={cn("text-base w-5 text-center", active ? TONE[item.tone].text : "text-mut group-hover:text-ink")}>{item.icon}</span>
      <span className={cn("text-[13px] font-medium", active ? "text-ink" : "text-mut group-hover:text-ink")}>{t(item.label)}</span>
    </button>
  );
}

function PlayerCard() {
  const { player, lang, t } = useApp();
  const f = FACTIONS[player.faction];
  const rank = RANKS.filter((r) => player.xp >= r.xp).slice(-1)[0] ?? RANKS[0];
  const next = RANKS.find((r) => r.xp > player.xp) ?? RANKS[RANKS.length - 1];
  const prog = next ? ((player.xp - rank.xp) / (next.xp - rank.xp)) * 100 : 100;
  return (
    <Panel className="p-3" tone={f.tone}>
      <div className="flex items-center gap-2.5">
        <div className={cn("relative w-9 h-9 rounded-lg flex items-center justify-center text-lg", TONE[f.tone].soft, TONE[f.tone].border, "border")}>
          {f.icon}
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-[12px] font-semibold text-ink truncate">{player.name}</div>
          <div className="text-[10px] text-mut font-mono truncate">{player.handle}</div>
        </div>
        <span className={cn("text-[9px] font-bold uppercase px-1.5 py-0.5 rounded", TONE[f.tone].soft, TONE[f.tone].text)}>{tx(f.tag, lang)}</span>
      </div>
      <div className="mt-2.5">
        <div className="flex items-center justify-between text-[10px] mb-1">
          <span className="text-mut">{t("Rank")} {rank.tier}</span>
          <span className={TONE[f.tone].text + " font-semibold"}>{tx(rank.name, lang)}</span>
        </div>
        <Bar value={prog} tone={f.tone} height="h-1" />
        <div className="flex justify-between text-[9px] text-mut mt-1 font-mono">
          <span>{fmtNum(player.xp)} XP</span>
          <span>{next ? fmtNum(next.xp) : "MAX"}</span>
        </div>
      </div>
    </Panel>
  );
}

function ResourcePill({ icon, value, tone, label }: { icon: string; value: string; tone: Tone; label: string }) {
  return (
    <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-white/[0.04] border border-edge" title={label}>
      <span className="text-[12px]">{icon}</span>
      <span className={cn("text-[12px] font-bold tnum", TONE[tone].text)}>{value}</span>
    </div>
  );
}

function TopBar({ onMenu }: { onMenu: () => void }) {
  const { player, lang, setLang, market, setView, setHelpOpen, t } = useApp();
  return (
    <header className="h-14 shrink-0 border-b border-edge bg-panel/80 backdrop-blur flex items-center gap-3 px-3 sm:px-4">
      <button onClick={onMenu} className="md:hidden text-ink text-lg px-1">☰</button>
      <div className="flex items-center gap-2">
        <Dot tone={market.regimeTone} glow />
        <span className={cn("text-[11px] font-bold uppercase tracking-wider hidden sm:inline", TONE[market.regimeTone].text)}>
          {tx(market.regimeLabel, lang)}
        </span>
      </div>

      <div className="hidden lg:flex items-center gap-1.5">
        <ResourcePill icon="💎" value={fmtNum(player.resources.fold)} tone="acid" label="$FOLD" />
        <ResourcePill icon="⚖" value={fmtNum(player.resources.peg)} tone="cyan" label="Peg" />
        <ResourcePill icon="🔋" value={`${player.resources.energy}/${player.resources.energyMax}`} tone="gold" label="Energy" />
        <ResourcePill icon="🌐" value={player.resources.influence + "%"} tone="violet" label="Influence" />
      </div>

      <div className="flex-1" />

      <button onClick={() => setHelpOpen(true)} title={t("How to play")}
        className="w-8 h-8 rounded-lg border border-edge bg-white/[0.04] text-ink hover:border-acid hover:text-acid transition-colors text-sm font-bold">
        ?
      </button>

      {/* lang toggle */}
      <div className="flex items-center rounded-lg bg-white/[0.04] border border-edge p-0.5">
        {(["en", "ru"] as const).map((l) => (
          <button key={l} onClick={() => setLang(l)}
            className={cn("px-2 py-0.5 rounded-md text-[10px] font-bold uppercase transition-colors", lang === l ? "bg-acid text-black" : "text-mut hover:text-ink")}>
            {l}
          </button>
        ))}
      </div>

      <Btn tone="pink" size="sm" onClick={() => setView("store")} className="pulse-glow">
        <span>+</span> {t("Add funds")}
      </Btn>
    </header>
  );
}

function Ticker() {
  const { market, news, lang } = useApp();
  const items = [
    ...market.coins.map((c) => `${c.sym} ${fmtPrice(c.price)} ${c.chg >= 0 ? "▲" : "▼"}${Math.abs(c.chg).toFixed(1)}%`),
    `${tx(market.regimeLabel, lang)} · Sentiment ${Math.round(market.sentiment)}`,
    ...(market.fearGreed ? [`F&G ${market.fearGreed.value} ${market.fearGreed.classification}`] : []),
    ...news.map((n) => tx(n, lang)),
  ];
  const sep = <span className="text-mut2 px-3">◆</span>;
  return (
    <div className="h-7 shrink-0 border-b border-edge bg-black/40 overflow-hidden flex items-center">
      <div className="shrink-0 px-2.5 h-full flex items-center gap-1.5 border-r border-edge bg-acid/10">
        <Dot tone={market.live ? "ok" : "warn"} glow />
        <span className={cn("text-[9px] font-bold uppercase tracking-wider font-mono", market.live ? "text-ok" : "text-warn")}>
          {market.live ? "LIVE FEED" : "SIM FEED"}
        </span>
      </div>
      <div className="overflow-hidden flex-1">
        <div className="animate-ticker whitespace-nowrap flex items-center text-[11px] font-mono">
          {[0, 1].map((dup) => (
            <span key={dup} className="flex items-center" aria-hidden={dup === 1}>
              {items.map((it, i) => (
                <span key={i} className="flex items-center text-mut">
                  <span className={cn(i < market.coins.length ? "text-ink" : "")}>{it}</span>
                  {sep}
                </span>
              ))}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function Toasts() {
  const { toasts } = useApp();
  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 w-[min(92vw,320px)]">
      {toasts.map((tt) => (
        <div key={tt.id} className={cn("panel rounded-lg px-3 py-2 text-[12px] font-medium flex items-center gap-2 animate-[flashUp_.3s] border", TONE[tt.tone as Tone]?.border)}>
          <span className={cn("w-1.5 h-1.5 rounded-full", TONE[tt.tone as Tone]?.dot)} />
          <span className="text-ink">{tt.text}</span>
        </div>
      ))}
    </div>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  const { view, setView } = useApp();
  const [drawer, setDrawer] = useState(false);
  const go = (id: ViewId) => { setView(id); setDrawer(false); };

  const sidebar = (
    <aside className="w-[224px] shrink-0 h-full bg-panel border-r border-edge flex flex-col">
      <div className="h-14 flex items-center px-3 border-b border-edge"><Logo /></div>
      <nav className="flex-1 overflow-y-auto p-2 space-y-0.5">
        {NAV.map((n) => <NavButton key={n.id} item={n} active={view === n.id} onClick={() => go(n.id)} />)}
      </nav>
      <div className="p-2 space-y-2 border-t border-edge">
        <PlayerCard />
      </div>
    </aside>
  );

  return (
    <div className="h-screen flex bg-base bg-grid overflow-hidden">
      <div className="hidden md:flex">{sidebar}</div>

      {/* mobile drawer */}
      {drawer && (
        <div className="md:hidden fixed inset-0 z-40 flex">
          <div className="absolute inset-0 bg-black/60" onClick={() => setDrawer(false)} />
          <div className="relative">{sidebar}</div>
        </div>
      )}

      <div className="flex-1 flex flex-col min-w-0">
        <TopBar onMenu={() => setDrawer(true)} />
        <Ticker />
        <main className="flex-1 overflow-y-auto">{children}</main>
      </div>
      <Toasts />
      <Onboarding />
    </div>
  );
}
