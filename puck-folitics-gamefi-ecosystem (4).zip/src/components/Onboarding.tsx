import { useEffect, useState } from "react";
import { useApp } from "../store";
import { tx } from "../i18n";
import { FACTIONS, REGIONS, PLAYER_NODE, PLAYER_GLOBAL_RANK } from "../data";
import { Btn, TONE, Bar } from "./ui";
import { cn } from "../utils/cn";

type Step = {
  tag: { en: string; ru: string };
  title: { en: string; ru: string };
  body: { en: string; ru: string };
  visual: "who" | "goal" | "loop" | "real" | "devices" | "start";
};

const STEPS: Step[] = [
  {
    tag: { en: "1 · Who you are", ru: "1 · Кто ты" },
    title: { en: "You are Operator Kade — a Builder.", ru: "Ты — Оператор Кад, Билдер." },
    body: {
      en: "You don't play as a character in a story. You're an operator running a piece of the world. You belong to the Builders faction — the people who build the rails everyone else rides on.",
      ru: "Ты не персонаж в сюжете. Ты — оператор, который держит кусочек мира. Ты в фракции Билдеров — тех, кто строит рельсы, по которым ездят остальные.",
    },
    visual: "who",
  },
  {
    tag: { en: "2 · Where you are", ru: "2 · Где ты" },
    title: { en: "You run a node in the Vaultstep Basin.", ru: "Ты держишь узел в Бассейне Vaultstep." },
    body: {
      en: "Your base is Hexline-7, a relay node in the yield district of Vaultstep Basin. This is your seat of power. Everything you own and build connects back to this node.",
      ru: "Твоя база — Hexline-7, релейный узел в доходном районе Vaultstep. Это твой центр силы. Всё, что у тебя есть, связано с этим узлом.",
    },
    visual: "who",
  },
  {
    tag: { en: "3 · The goal", ru: "3 · Цель" },
    title: { en: "Climb the global ladder. There is no 'win'.", ru: "Лезь на вершину. 'Победы' нет." },
    body: {
      en: "You start at global rank #1,847 out of 182,000+ operators. Grow your power, survive the world's chaos, beat rivals, and climb toward the top. The game never ends — it just gets more ambitious.",
      ru: "Ты начинаешь на 1 847-м месте из 182 000+ операторов. Качай силу, переживай хаос мира, побеждай соперников и лезь к вершине. Игра не кончается — просто амбиции растут.",
    },
    visual: "goal",
  },
  {
    tag: { en: "4 · What you actually DO", ru: "4 · Что ты реально делаешь" },
    title: { en: "You SPIN narratives — but it's skill, not luck.", ru: "Ты раскручиваешь нарративы — но это скилл, не удача." },
    body: {
      en: "This is the core game, and it is NOT gambling. The $FOLD you earn from your devices & node is your bankroll. Real market news hits → you READ the intel → pick a spin card that MATCHES the market → deploy helpers to tilt the odds. Read the tape right and you win 60%+. Wrong call? You lose a fraction, never everything. The better you read real markets, the richer you get.",
      ru: "Это основная игра — и это НЕ казино. $FOLD, что приносят твои девайсы и узел, — твой банкролл. Реальная новость рынка → ты ЧИТАЕШЬ инел → берёшь карту, СОВПАДАЮЩУЮ с рынком → ставишь помощников, чтобы поднять шанс. Читаешь ленту верно — побеждаешь в 60%+ случаев. Ошибся? Теряешь лишь часть, никогда не всё. Чем лучше читаешь реальный рынок — тем богаче.",
    },
    visual: "loop",
  },
  {
    tag: { en: "5 · The secret sauce", ru: "5 · Главная фишка" },
    title: { en: "The world follows REAL crypto markets.", ru: "Мир повторяет РЕАЛЬНЫЙ рынок крипты." },
    body: {
      en: "This isn't random. When real BTC pumps, your world turns Bull. When a real bridge gets hacked, a Bridge Breach hits your map. The Fear & Greed of the real market shapes your yields, raids and prices. Come back daily — the world will have moved.",
      ru: "Это не рандом. Когда реальный BTC летит вверх — твой мир становится Бычьим. Когда в реальности ломают мост — у тебя бьёт Прорыв Моста. Реальный страх и жадность рынка двигают твою доходность, рейды и цены. Заходи каждый день — мир сдвинется.",
    },
    visual: "real",
  },
  {
    tag: { en: "6 · Devices (the 'why')", ru: "6 · Девайсы (зачем они)" },
    title: { en: "Devices are your edge. Equip up to 4.", ru: "Девайсы — твой перевес. Экипируй до 4." },
    body: {
      en: "Devices aren't decoration — each has a ROLE. 🏠 Node Core = your base (+cred). 💰 Vault Forge = passive $FOLD bankroll. 📡 Signal Oracle & 🐋 Whale Tracker = read the market sharper. 📣 FUD Engine & 💨 Copium Synth = boost your spins. 🛡 Rug Detector & 🌉 Bridge Relay = cut your losses. Equip 4 and they grant real bonuses in the War Room. That's the whole point of upgrading them.",
      ru: "Девайсы — не украшение, у каждого РОЛЬ. 🏠 Node Core = база (+кредо). 💰 Vault Forge = пассивный $FOLD (банкролл). 📡 Signal Oracle и 🐋 Whale Tracker = читают рынок точнее. 📣 FUD Engine и 💨 Copium Synth = усиливают твои спины. 🛡 Rug Detector и 🌉 Bridge Relay = режут потери. Экипируй 4 — и они дадут реальные бонусы в War Room. В этом весь смысл их прокачки.",
    },
    visual: "devices",
  },
  {
    tag: { en: "7 · Your first moves", ru: "7 · Первые шаги" },
    title: { en: "Three moves to get rolling.", ru: "Три хода, чтобы начать." },
    body: {
      en: "You'll always have a clear next step on your dashboard. To start: spin your first narrative in the War Room, fix & upgrade a damaged device, and beat or squeeze the nearest rival. Let's go.",
      ru: "На дашборде всегда есть понятный следующий шаг. Для начала: раскрути первый нарратив в War Room, почини и прокачай сломанный девайс и побей или дожми ближайшего соперника. Поехали.",
    },
    visual: "start",
  },
];

const LOOP_STEPS = [
  { en: "Signal", ru: "Сигнал", tone: "cyan", d: { en: "Real market news hits", ru: "Реальная новость рынка" } },
  { en: "Spin", ru: "Спин", tone: "pink", d: { en: "Play a narrative card", ru: "Сыграй карту-нарратив" } },
  { en: "Crowd", ru: "Толпа", tone: "gold", d: { en: "Real move decides it", ru: "Реальное движение решает" } },
  { en: "Profit", ru: "Профит", tone: "acid", d: { en: "Print $FOLD + cred", ru: "Печать $FOLD + кредо" } },
  { en: "Build", ru: "Прокачка", tone: "violet", d: { en: "Upgrade & defend", ru: "Качай и защищай" } },
  { en: "Climb", ru: "Рост", tone: "ok", d: { en: "Rank rises", ru: "Ранг растёт" } },
];

export function Onboarding() {
  const { helpOpen, setHelpOpen, lang, player } = useApp();
  const [step, setStep] = useState(0);
  const [auto, setAuto] = useState(false);

  // auto-open first time
  useEffect(() => {
    try {
      if (!localStorage.getItem("pf_onboarded")) setAuto(true);
    } catch { setAuto(true); }
  }, []);
  const open = helpOpen || auto;
  const close = () => {
    setHelpOpen(false);
    setAuto(false);
    try { localStorage.setItem("pf_onboarded", "1"); } catch { /* ignore */ }
  };

  if (!open) return null;
  const s = STEPS[step];
  const f = FACTIONS[player.faction];
  const region = REGIONS.find((r) => r.id === PLAYER_NODE.regionId)!;
  const last = step === STEPS.length - 1;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-3 sm:p-6">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={close} />
      <div className="relative z-10 w-full max-w-lg panel rounded-2xl overflow-hidden" style={{ boxShadow: `0 0 60px -10px rgba(200,255,58,0.25)` }}>
        {/* progress dots */}
        <div className="flex gap-1.5 px-5 pt-4">
          {STEPS.map((_, i) => (
            <button key={i} onClick={() => setStep(i)} className={cn("h-1 rounded-full transition-all", i === step ? "w-8 bg-acid" : "w-4 bg-edge2 hover:bg-mut")} />
          ))}
        </div>

        <div className="p-5 sm:p-6">
          <div className={cn("inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.2em] px-2 py-1 rounded mb-3", TONE[f.tone].soft, TONE[f.tone].text)}>
            {tx(s.tag, lang)}
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-ink leading-tight mb-2.5">{tx(s.title, lang)}</h2>
          <p className="text-[13px] text-mut leading-relaxed mb-5">{tx(s.body, lang)}</p>

          {/* visual */}
          {s.visual === "who" && (
            <div className="rounded-xl border border-edge bg-white/[0.02] p-4 flex items-center gap-4">
              <div className={cn("w-16 h-16 rounded-xl flex items-center justify-center text-3xl border-2", TONE[f.tone].soft, TONE[f.tone].border)}>{f.icon}</div>
              <div className="min-w-0">
                <div className="text-[11px] uppercase text-mut tracking-wider">{lang === "ru" ? "Твой узел" : "Your node"}</div>
                <div className="text-[15px] font-bold text-ink">{tx(PLAYER_NODE.name, lang)}</div>
                <div className="text-[11px] text-mut">{region.icon} {tx(region.name, lang)}</div>
                <div className="mt-1.5"><Bar value={PLAYER_NODE.control} tone="acid" height="h-1" className="w-40" /></div>
              </div>
            </div>
          )}
          {s.visual === "goal" && (
            <div className="rounded-xl border border-edge bg-white/[0.02] p-4 text-center">
              <div className="text-[11px] uppercase text-mut tracking-wider">{lang === "ru" ? "Твой ранг сейчас" : "Your rank right now"}</div>
              <div className="text-4xl font-black text-acid tnum leading-none my-1">#{PLAYER_GLOBAL_RANK.toLocaleString()}</div>
              <div className="text-[11px] text-mut">{lang === "ru" ? "из 182 043 операторов. Только вверх." : "of 182,043 operators. Only one way: up."}</div>
            </div>
          )}
          {s.visual === "loop" && (
            <div className="grid grid-cols-3 gap-2">
              {LOOP_STEPS.map((l, i) => (
                <div key={l.en} className="relative">
                  <div className={cn("rounded-lg border p-2 text-center", TONE[l.tone as keyof typeof TONE]?.border, TONE[l.tone as keyof typeof TONE]?.soft)}>
                    <div className={cn("text-[12px] font-bold", TONE[l.tone as keyof typeof TONE]?.text)}>{tx(l, lang)}</div>
                    <div className="text-[9px] text-mut mt-0.5 leading-tight">{tx(l.d, lang)}</div>
                  </div>
                  {i < LOOP_STEPS.length - 1 && i % 3 !== 2 && <span className="absolute -right-1.5 top-1/2 -translate-y-1/2 text-mut2 text-[10px] z-10">›</span>}
                </div>
              ))}
            </div>
          )}
          {s.visual === "real" && (
            <div className="rounded-xl border border-edge bg-white/[0.02] p-4 space-y-2">
              {[
                { e: "📈 BTC +6%", f: { en: "→ world turns Bull, yields heat up", ru: "→ мир становится Бычьим, доход греется" }, t: "ok" },
                { e: "🌉 bridge hack", f: { en: "→ Bridge Breach hits your map", ru: "→ Прорыв Моста бьёт по карте" }, t: "danger" },
                { e: "😱 F&G = 22", f: { en: "→ raiders get bold, insurance spikes", ru: "→ рейдеры дерзеют, страховки взлетают" }, t: "warn" },
              ].map((r) => (
                <div key={r.e} className="flex items-center gap-3 text-[12px]">
                  <span className={cn("font-mono font-bold w-28 shrink-0", TONE[r.t as keyof typeof TONE]?.text)}>{r.e}</span>
                  <span className="text-mut">{tx(r.f, lang)}</span>
                </div>
              ))}
            </div>
          )}
          {s.visual === "devices" && (
            <div className="grid grid-cols-2 gap-2">
              {[
                { icon: "🏠", n: { en: "Base", ru: "База" }, d: { en: "Your seat (+cred)", ru: "Центр силы (+кредо)" }, t: "acid" },
                { icon: "💰", n: { en: "Income", ru: "Доход" }, d: { en: "Passive $FOLD", ru: "Пассивный $FOLD" }, t: "gold" },
                { icon: "📡", n: { en: "Intel", ru: "Интел" }, d: { en: "Read market sharper", ru: "Читает рынок" }, t: "cyan" },
                { icon: "📣", n: { en: "Influence", ru: "Влияние" }, d: { en: "Boost your spins", ru: "Усиливает спины" }, t: "pink" },
                { icon: "🛡", n: { en: "Defense", ru: "Защита" }, d: { en: "Cut your losses", ru: "Режет потери" }, t: "ok" },
                { icon: "⚙", n: { en: "Equip 4", ru: "Экипируй 4" }, d: { en: "Bonuses activate", ru: "Бонусы включаются" }, t: "violet" },
              ].map((it, i) => (
                <div key={i} className={cn("rounded-lg border p-2", TONE[it.t as keyof typeof TONE]?.border, TONE[it.t as keyof typeof TONE]?.soft)}>
                  <div className="flex items-center gap-1.5">
                    <span className="text-base">{it.icon}</span>
                    <span className={cn("text-[11px] font-bold", TONE[it.t as keyof typeof TONE]?.text)}>{tx(it.n, lang)}</span>
                  </div>
                  <div className="text-[9.5px] text-mut mt-0.5">{tx(it.d, lang)}</div>
                </div>
              ))}
            </div>
          )}
          {s.visual === "start" && (
            <div className="rounded-xl border border-edge bg-white/[0.02] p-3 space-y-1.5">
              {[
                { en: "Spin your first narrative in the War Room", ru: "Раскрути первый нарратив в War Room", tone: "pink", done: false },
                { en: "Fix & upgrade your damaged device", ru: "Почини и прокачай сломанный девайс", tone: "violet", done: false },
                { en: "Beat a rival to climb a rank", ru: "Побей соперника, чтобы подняться", tone: "gold", done: false },
              ].map((it, i) => (
                <div key={i} className="flex items-center gap-2.5 text-[12.5px]">
                  <span className={cn("w-5 h-5 rounded-md flex items-center justify-center text-[11px] font-bold border", TONE[it.tone as keyof typeof TONE]?.border, TONE[it.tone as keyof typeof TONE]?.soft, TONE[it.tone as keyof typeof TONE]?.text)}>{i + 1}</span>
                  <span className="text-ink">{tx(it, lang)}</span>
                </div>
              ))}
            </div>
          )}

          {/* nav */}
          <div className="flex items-center justify-between mt-6">
            <button onClick={close} className="text-[12px] text-mut hover:text-ink transition-colors">{lang === "ru" ? "Пропустить" : "Skip"}</button>
            <div className="flex gap-2">
              {step > 0 && <Btn variant="ghost" size="sm" onClick={() => setStep(step - 1)}>‹ {lang === "ru" ? "Назад" : "Back"}</Btn>}
              {!last ? (
                <Btn tone={f.tone} size="sm" onClick={() => setStep(step + 1)}>{lang === "ru" ? "Дальше" : "Next"} ›</Btn>
              ) : (
                <Btn tone={f.tone} size="sm" onClick={close}>{lang === "ru" ? "Поехали! 🚀" : "Let's play 🚀"}</Btn>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
